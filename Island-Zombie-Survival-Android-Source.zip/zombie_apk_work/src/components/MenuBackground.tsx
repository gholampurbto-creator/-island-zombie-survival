import React, { useEffect, useRef } from 'react';
import { getSpriteAtlas } from '../game/sprites';
import { ZombieType } from '../game/types';

interface MenuZombie {
  x: number;
  y: number;
  speed: number;
  type: ZombieType;
  dir: 1 | -1;
  phase: number;
}

interface Ember {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
}

export const MenuBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    const atlas = getSpriteAtlas();

    // Low-res pixel art virtual canvas (320x180) stretched crisply to fill viewport!
    const VW = 320;
    const VH = 180;
    canvas.width = VW;
    canvas.height = VH;

    const zombies: MenuZombie[] = [
      { x: 40, y: 141, speed: 9, type: 'normal', dir: 1, phase: 0 },
      { x: 185, y: 144, speed: 7, type: 'heavy', dir: -1, phase: 1.5 },
      { x: 265, y: 139, speed: 15, type: 'fast', dir: -1, phase: 2.2 },
      { x: 112, y: 146, speed: 8, type: 'mutant', dir: 1, phase: 0.8 },
      { x: 295, y: 143, speed: 10, type: 'normal', dir: -1, phase: 3.1 },
    ];

    const embers: Ember[] = Array.from({ length: 28 }, (_, i) => ({
      x: Math.random() * VW,
      y: 70 + Math.random() * 100,
      vx: -4 - Math.random() * 6,
      vy: -8 - Math.random() * 12,
      life: Math.random(),
      color: i % 3 === 0 ? '#84ff4f' : i % 2 === 0 ? '#ff922b' : '#ffd43b',
    }));

    const clouds = [
      { x: 20, y: 20, w: 68, speed: 2.2 },
      { x: 140, y: 12, w: 86, speed: 1.6 },
      { x: 240, y: 30, w: 62, speed: 2.8 },
    ];

    let lightning = 0;
    let nextLightning = 3.5;
    let rafId = 0;
    let last = performance.now();
    let t = 0;

    const draw = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      t += dt;

      nextLightning -= dt;
      if (nextLightning <= 0) {
        lightning = 0.85;
        nextLightning = 5 + Math.random() * 7;
      }
      lightning = Math.max(0, lightning - dt * 3.8);

      ctx.imageSmoothingEnabled = false;

      // 1. Stormy Apocalyptic Night Sky gradient bands (pixel art dithering aesthetic)
      const skyBands = ['#070c12', '#0a141f', '#0e1d2b', '#132836', '#183440', '#1d3c44'];
      const bandH = Math.ceil(96 / skyBands.length);
      skyBands.forEach((col, i) => {
        ctx.fillStyle = col;
        ctx.fillRect(0, i * bandH, VW, bandH + 1);
      });

      // Stars
      ctx.fillStyle = 'rgba(220, 240, 255, 0.55)';
      for (let s = 0; s < 26; s++) {
        const sx = (s * 47 + 13) % VW;
        const sy = (s * 23 + 5) % 58;
        if (Math.sin(t * 2 + s) > -0.2) ctx.fillRect(sx, sy, 1, 1);
      }

      // Eerie blood-gold full moon
      const mx = 248;
      const my = 32;
      ctx.fillStyle = 'rgba(255, 198, 128, 0.14)';
      ctx.fillRect(mx - 17, my - 17, 34, 34);
      ctx.fillStyle = '#e8c48e';
      ctx.fillRect(mx - 10, my - 10, 20, 20);
      ctx.fillStyle = '#fff0cc';
      ctx.fillRect(mx - 8, my - 8, 16, 16);
      ctx.fillStyle = '#cfa36e';
      ctx.fillRect(mx - 5, my - 3, 4, 4);
      ctx.fillRect(mx + 2, my + 2, 5, 3);

      // Drifting dark storm clouds
      for (const cl of clouds) {
        cl.x += cl.speed * dt;
        if (cl.x > VW + 20) cl.x = -cl.w - 10;
        const cx = Math.round(cl.x);
        ctx.fillStyle = lightning > 0.2 ? '#344c5c' : '#101d29';
        ctx.fillRect(cx, cl.y, cl.w, 8);
        ctx.fillRect(cx + 8, cl.y - 4, cl.w - 18, 6);
        ctx.fillStyle = lightning > 0.2 ? '#547385' : '#182b3a';
        ctx.fillRect(cx + 10, cl.y - 4, cl.w - 22, 2);
      }

      // 2. Moonlit Dark Ocean (rows 92..135)
      ctx.fillStyle = '#0a2233';
      ctx.fillRect(0, 92, VW, 44);
      ctx.fillStyle = '#0e3047';
      ctx.fillRect(0, 102, VW, 34);

      // Moon shimmer & rolling waves
      for (let wy = 95; wy < 134; wy += 4) {
        const waveShift = Math.sin(t * 1.8 + wy * 0.4) * 5;
        ctx.fillStyle = 'rgba(240, 212, 152, 0.26)';
        const mw = Math.max(6, 26 - (wy - 95) * 0.4);
        ctx.fillRect(Math.round(mx - mw / 2 + waveShift), wy, Math.round(mw), 1);

        // Ocean ripple crests
        for (let wx = 0; wx < VW; wx += 32) {
          const rx = Math.round((wx + t * (6 + (wy % 3) * 2)) % (VW + 20) - 10);
          ctx.fillStyle = 'rgba(84, 173, 199, 0.22)';
          ctx.fillRect(rx, wy + 1, 9, 1);
        }
      }

      // 3. Distant Island Mountain & Jungle Silhouette (behind shoreline)
      ctx.fillStyle = '#0b1817';
      for (let x = 0; x < VW; x += 2) {
        const ridge =
          Math.sin(x * 0.018) * 16 +
          Math.cos(x * 0.045) * 8 +
          (x > 40 && x < 275 ? 18 : 0);
        const h = Math.max(4, Math.round(14 + ridge));
        ctx.fillRect(x, 122 - h, 2, h + 12);
      }

      // Abandoned Watchtower / Ruined Cabin silhouette with flickering lantern on left ridge
      ctx.fillStyle = '#091114';
      ctx.fillRect(54, 88, 22, 24);
      ctx.fillRect(50, 84, 30, 5);
      // Glowing warm window
      const glowPulse = 0.75 + Math.sin(t * 10) * 0.25;
      ctx.fillStyle = `rgba(255, 179, 64, ${glowPulse})`;
      ctx.fillRect(62, 95, 5, 5);

      // 4. Foreground Dark Island Beach & Jungle Floor (rows 124..180)
      // Animated surf foam line
      for (let x = 0; x < VW; x += 4) {
        const surfY = 128 + Math.round(Math.sin(t * 2.2 + x * 0.06) * 2);
        ctx.fillStyle = 'rgba(170, 232, 245, 0.48)';
        ctx.fillRect(x, surfY, 4, 2);
      }

      ctx.fillStyle = '#332d22';
      ctx.fillRect(0, 130, VW, 50);
      ctx.fillStyle = '#24221a';
      ctx.fillRect(0, 142, VW, 38);
      ctx.fillStyle = '#151c16';
      ctx.fillRect(0, 155, VW, 25);

      // Wrecked boat & flickering beach fire on right side
      ctx.drawImage(atlas.props.boat_wreck, 215, 131);
      const fireH = 5 + Math.floor(Math.sin(t * 16) * 2);
      ctx.fillStyle = 'rgba(255, 120, 30, 0.24)';
      ctx.fillRect(224, 132, 22, 16);
      ctx.fillStyle = '#ff6b1c';
      ctx.fillRect(232, 142 - fireH, 6, fireH);
      ctx.fillStyle = '#ffe066';
      ctx.fillRect(233, 142 - Math.max(2, fireH - 2), 4, Math.max(2, fireH - 2));

      // Swaying tropical palms framing left & right
      const palmSway = Math.round(Math.sin(t * 1.4) * 1.5);
      ctx.drawImage(atlas.props.palm[0], 6 + palmSway, 96);
      ctx.drawImage(atlas.props.jungle_tree[0], 274 - palmSway, 100);
      ctx.drawImage(atlas.props.palm[1], 145 + palmSway, 93);
      ctx.drawImage(atlas.props.bio_sign, 108, 132);

      // 5. Shambling Animated Pixel Zombies on the misty beach!
      for (const z of zombies) {
        z.x += z.speed * z.dir * dt;
        z.phase += dt * (z.type === 'fast' ? 10 : 6);
        if (z.x > VW + 20) z.x = -20;
        if (z.x < -20) z.x = VW + 20;

        const spr = atlas.zombies[z.type].walk[Math.floor(z.phase) % 4];
        ctx.save();
        ctx.translate(Math.round(z.x), Math.round(z.y));
        if (z.dir < 0) ctx.scale(-1, 1);
        ctx.drawImage(spr, Math.round(-spr.width / 2), -spr.height);
        ctx.restore();
      }

      // 6. Rising Campfire Embers & Eerie Green Bio-Spores
      for (const e of embers) {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        e.life -= dt * 0.35;
        if (e.life <= 0 || e.y < 30 || e.x < 0) {
          e.x = e.color === '#84ff4f' ? Math.random() * VW : 230 + (Math.random() - 0.5) * 20;
          e.y = e.color === '#84ff4f' ? 135 + Math.random() * 35 : 140;
          e.life = 0.6 + Math.random() * 0.6;
        }
        ctx.globalAlpha = Math.max(0, Math.min(1, e.life));
        ctx.fillStyle = e.color;
        ctx.fillRect(Math.round(e.x), Math.round(e.y), 1, 1);
      }
      ctx.globalAlpha = 1;

      // 7. Rolling Ground Mist
      ctx.fillStyle = 'rgba(130, 175, 165, 0.08)';
      const mistShift = Math.round((t * 8) % VW);
      ctx.fillRect(mistShift - VW, 134, VW, 10);
      ctx.fillRect(mistShift, 134, VW, 10);

      // 8. Lightning flash illumination
      if (lightning > 0.02) {
        ctx.fillStyle = `rgba(210, 238, 255, ${lightning * 0.45})`;
        ctx.fillRect(0, 0, VW, VH);
      }

      // Soft dark vignette for crisp UI readability
      const vig = ctx.createRadialGradient(VW / 2, VH / 2, 45, VW / 2, VH / 2, 185);
      vig.addColorStop(0, 'rgba(6,10,14,0.08)');
      vig.addColorStop(1, 'rgba(4,8,12,0.72)');
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, VW, VH);

      rafId = requestAnimationFrame(draw);
    };

    rafId = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(rafId);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full object-cover [image-rendering:pixelated]"
    />
  );
};
