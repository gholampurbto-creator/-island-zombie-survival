import React, { useState } from 'react';
import { soundStudio } from '../game/audio';
import { t } from '../game/i18n';
import { SaveData, WeaponId } from '../game/types';
import {
  getEffectiveWeaponStats,
  getWeaponUpgradeCost,
  GRENADE_CONFIG,
  WEAPON_ORDER,
  WEAPONS,
} from '../game/weapons';
import { PixelSpritePreview } from './PixelSpritePreview';

interface WeaponShopModalProps {
  saveData: SaveData;
  inGame: boolean;
  equippedWeapon?: WeaponId;
  grenadeCount?: number;
  onUnlockWeapon: (id: WeaponId) => void;
  onUpgradeWeapon: (id: WeaponId) => void;
  onBuyAmmo?: (id: WeaponId) => void;
  onBuyGrenade?: () => void;
  onEquipWeapon?: (id: WeaponId) => void;
  onClose: () => void;
}

export const WeaponShopModal: React.FC<WeaponShopModalProps> = ({
  saveData,
  inGame,
  equippedWeapon,
  grenadeCount = 0,
  onUnlockWeapon,
  onUpgradeWeapon,
  onBuyAmmo,
  onBuyGrenade,
  onEquipWeapon,
  onClose,
}) => {
  const lang = saveData.settings.language;
  const txt = t(lang);
  const isFa = lang === 'fa';

  const [selected, setSelected] = useState<WeaponId>(equippedWeapon || 'pistol');

  const wDef = WEAPONS[selected];
  const isOwned = saveData.unlockedWeapons.includes(selected);
  const level = saveData.weaponLevels[selected] || 1;
  const stats = getEffectiveWeaponStats(selected, level);
  const nextStats = level < 5 ? getEffectiveWeaponStats(selected, level + 1) : null;
  const upgradeCost = getWeaponUpgradeCost(selected, level);

  const renderBar = (label: string, val: number, max: number, nextVal?: number, suffix = '') => {
    const pct = Math.min(100, Math.max(4, (val / max) * 100));
    const nextPct = nextVal ? Math.min(100, Math.max(4, (nextVal / max) * 100)) : pct;
    return (
      <div className="space-y-0.5">
        <div className="flex justify-between text-[11px]">
          <span className="text-slate-300">{label}</span>
          <span className="font-pixel-ui text-emerald-300">
            {val}
            {suffix}
            {nextVal !== undefined && nextVal !== val && (
              <span className="text-amber-300"> → {nextVal}{suffix}</span>
            )}
          </span>
        </div>
        <div className="h-2 bg-[#0a1014] border border-slate-700/80 relative overflow-hidden">
          {nextVal !== undefined && nextPct > pct && (
            <div
              className="absolute inset-y-0 left-0 bg-amber-400/50"
              style={{ width: `${nextPct}%` }}
            />
          )}
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-emerald-600 to-emerald-400"
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-40 bg-black/75 backdrop-blur-[2px] flex items-center justify-center p-2 sm:p-4">
      <div className="pixel-panel w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 border-b border-emerald-900/80 flex items-center justify-between gap-2 bg-[#0f191d]">
          <div className="flex items-center gap-3">
            <h2 className="font-pixel text-xs sm:text-sm text-amber-300">
              WEAPON SHOP {isFa ? `• ${txt.weaponShop}` : ''}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-2.5 py-1 bg-[#0a1114] border border-amber-600/60 flex items-center gap-1.5 text-amber-300 text-xs font-pixel-ui">
              <PixelSpritePreview target={{ kind: 'pickup', type: 'coin' }} scale={2} />
              <span>{saveData.coins}</span>
            </div>
            <button
              onClick={onClose}
              className="pixel-btn px-3 py-1 text-xs font-bold text-slate-200 cursor-pointer"
            >
              ✕ {txt.close}
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto custom-scroll p-3 sm:p-4 grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Left List: All 8 Weapons + Grenade Supply */}
          <div className="md:col-span-5 flex flex-col gap-1.5">
            {WEAPON_ORDER.map((wid) => {
              const def = WEAPONS[wid];
              const owned = saveData.unlockedWeapons.includes(wid);
              const lv = saveData.weaponLevels[wid] || 1;
              const active = selected === wid;
              const isEq = inGame && equippedWeapon === wid;

              return (
                <button
                  key={wid}
                  onClick={() => {
                    soundStudio.unlock();
                    setSelected(wid);
                  }}
                  className={`p-2 border-2 text-left flex items-center gap-2.5 transition cursor-pointer ${
                    active
                      ? 'bg-emerald-950/70 border-emerald-400'
                      : 'bg-[#10191d] border-slate-800 hover:border-slate-600'
                  }`}
                >
                  <div className="w-16 h-9 bg-[#090f12] border border-slate-800 flex items-center justify-center shrink-0">
                    <PixelSpritePreview target={{ kind: 'weapon', id: wid }} scale={2} />
                  </div>
                  <div className="flex-1 min-w-0" dir={isFa ? 'rtl' : 'ltr'}>
                    <div className="text-xs font-bold text-slate-100 truncate">
                      {isFa ? def.nameFa : def.nameEn}
                    </div>
                    <div className="flex items-center gap-2 mt-0.5 text-[10px]">
                      {owned ? (
                        <span className="text-emerald-400 font-pixel-ui">
                          LV.{lv}/5 {isEq ? `• ${txt.equipped}` : ''}
                        </span>
                      ) : (
                        <span className="text-amber-300 font-pixel-ui">
                          🔒 {def.cost} {txt.coins}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}

            {/* Tactical Frag Grenade Refill Box (in-game) */}
            {inGame && onBuyGrenade && (
              <div className="mt-1 p-2.5 bg-[#191510] border-2 border-amber-700/70 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <PixelSpritePreview target={{ kind: 'grenade' }} scale={2} />
                  <div dir={isFa ? 'rtl' : 'ltr'}>
                    <div className="text-xs font-bold text-amber-200">
                      {isFa ? 'نارنجک جنگی M67' : 'M67 Frag Grenade'}
                    </div>
                    <div className="text-[10px] text-amber-300/80 font-pixel-ui">
                      {grenadeCount} / {GRENADE_CONFIG.maxCarry}
                    </div>
                  </div>
                </div>
                <button
                  onClick={onBuyGrenade}
                  disabled={
                    saveData.coins < GRENADE_CONFIG.cost ||
                    grenadeCount >= GRENADE_CONFIG.maxCarry
                  }
                  className="pixel-btn pixel-btn-gold px-2.5 py-1.5 text-[11px] font-bold text-amber-100 cursor-pointer"
                >
                  +1 ({GRENADE_CONFIG.cost})
                </button>
              </div>
            )}
          </div>

          {/* Right Inspector: Selected Weapon Showcase, Stats & Actions */}
          <div className="md:col-span-7 bg-[#0d1519] border-2 border-slate-800 p-3.5 flex flex-col justify-between gap-3">
            <div>
              {/* Top Showcase */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <div dir={isFa ? 'rtl' : 'ltr'}>
                  <h3 className="text-sm sm:text-base font-extrabold text-amber-200">
                    {isFa ? wDef.nameFa : wDef.nameEn}
                  </h3>
                  <div className="text-[11px] text-slate-400">
                    {isFa ? wDef.nameEn : wDef.category.toUpperCase()}
                  </div>
                </div>
                <span className="px-2 py-0.5 text-[10px] font-pixel-ui bg-emerald-950 border border-emerald-600/70 text-emerald-300">
                  {isOwned ? `LV.${level} / 5` : 'LOCKED'}
                </span>
              </div>

              <div className="h-24 bg-[#080d10] border border-slate-800/90 flex items-center justify-center relative overflow-hidden mb-3">
                <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#4ade80_1px,transparent_1px)] [background-size:8px_8px]" />
                <PixelSpritePreview target={{ kind: 'weapon', id: selected }} scale={4} />
                {wDef.pierce > 0 && (
                  <span className="absolute bottom-1.5 left-2 px-1.5 py-0.5 text-[9px] font-pixel-ui bg-cyan-950/90 border border-cyan-500/60 text-cyan-200">
                    PIERCE ×{wDef.pierce + 1}
                  </span>
                )}
                {wDef.pellets > 1 && (
                  <span className="absolute bottom-1.5 left-2 px-1.5 py-0.5 text-[9px] font-pixel-ui bg-orange-950/90 border border-orange-500/60 text-orange-200">
                    PELLETS ×{wDef.pellets}
                  </span>
                )}
                {wDef.splashRadius > 0 && (
                  <span className="absolute bottom-1.5 right-2 px-1.5 py-0.5 text-[9px] font-pixel-ui bg-purple-950/90 border border-purple-500/60 text-purple-200">
                    {wDef.isFlame ? 'BURN AOE' : 'PLASMA BLAST'}
                  </span>
                )}
              </div>

              <p
                dir={isFa ? 'rtl' : 'ltr'}
                className="text-xs text-slate-300 leading-relaxed mb-3"
              >
                {isFa ? wDef.descFa : wDef.descEn}
              </p>

              {/* Stat Bars */}
              <div className="space-y-2">
                {renderBar(
                  txt.damage,
                  stats.damage * wDef.pellets,
                  260,
                  nextStats ? nextStats.damage * wDef.pellets : undefined
                )}
                {renderBar(
                  txt.fireRate,
                  stats.fireRate,
                  18,
                  nextStats ? nextStats.fireRate : undefined,
                  '/s'
                )}
                {renderBar(
                  txt.magazine,
                  stats.magSize,
                  130,
                  nextStats ? nextStats.magSize : undefined
                )}
                {renderBar(
                  txt.reloadSpeed,
                  stats.reloadTime,
                  3.0,
                  nextStats ? nextStats.reloadTime : undefined,
                  's'
                )}
                {renderBar(
                  txt.range,
                  stats.range,
                  950,
                  nextStats ? nextStats.range : undefined
                )}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-2 border-t border-slate-800 flex flex-wrap gap-2">
              {!isOwned ? (
                <button
                  onClick={() => onUnlockWeapon(selected)}
                  disabled={saveData.coins < wDef.cost}
                  className="flex-1 pixel-btn pixel-btn-gold py-2.5 px-4 text-xs sm:text-sm font-bold text-amber-100 cursor-pointer"
                >
                  {txt.unlock} — {wDef.cost} {txt.coins}
                </button>
              ) : (
                <>
                  {level < 5 ? (
                    <button
                      onClick={() => onUpgradeWeapon(selected)}
                      disabled={saveData.coins < upgradeCost}
                      className="flex-1 pixel-btn pixel-btn-gold py-2 px-3 text-xs font-bold text-amber-100 cursor-pointer"
                    >
                      ⬆ {txt.upgrade} LV.{level + 1} ({upgradeCost})
                    </button>
                  ) : (
                    <div className="flex-1 py-2 px-3 bg-emerald-950/70 border border-emerald-600/60 text-center text-xs font-pixel-ui text-emerald-300">
                      ★ {txt.maxLevel}
                    </div>
                  )}

                  {inGame && onEquipWeapon && (
                    <button
                      onClick={() => onEquipWeapon(selected)}
                      disabled={equippedWeapon === selected}
                      className="pixel-btn pixel-btn-primary py-2 px-3.5 text-xs font-bold text-white cursor-pointer"
                    >
                      {equippedWeapon === selected ? txt.equipped : txt.equip}
                    </button>
                  )}

                  {inGame && onBuyAmmo && !wDef.infiniteReserve && (
                    <button
                      onClick={() => onBuyAmmo(selected)}
                      disabled={saveData.coins < wDef.ammoPackCost}
                      className="pixel-btn py-2 px-3 text-xs font-bold text-emerald-200 cursor-pointer"
                    >
                      +{wDef.ammoPackAmount} {txt.buyAmmo} ({wDef.ammoPackCost})
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
