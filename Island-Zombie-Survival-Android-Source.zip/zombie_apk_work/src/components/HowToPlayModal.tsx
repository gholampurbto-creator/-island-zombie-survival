import React, { useState } from 'react';
import { t, ZOMBIE_INFO, ZONE_INFO } from '../game/i18n';
import { Language, ZombieType, ZoneId } from '../game/types';
import { PixelSpritePreview } from './PixelSpritePreview';

interface HowToPlayModalProps {
  language: Language;
  onClose: () => void;
}

const ALL_ZONES: ZoneId[] = [
  'beach',
  'jungle',
  'houses',
  'hospital',
  'military',
  'ammo_depot',
  'caves',
  'virus_zone',
];

const ALL_ZOMBIES: ZombieType[] = ['normal', 'fast', 'heavy', 'mutant', 'giant'];

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ language, onClose }) => {
  const txt = t(language);
  const isFa = language === 'fa';
  const [tab, setTab] = useState<'controls' | 'zones' | 'zombies'>('controls');

  return (
    <div className="fixed inset-0 z-40 bg-black/75 backdrop-blur-[2px] flex items-center justify-center p-2 sm:p-4">
      <div className="pixel-panel w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 border-b border-emerald-900/80 flex items-center justify-between bg-[#0f191d]">
          <h2 className="font-pixel text-xs sm:text-sm text-amber-300">
            HOW TO PLAY {isFa ? `• ${txt.howToPlay}` : ''}
          </h2>
          <button
            onClick={onClose}
            className="pixel-btn px-3 py-1 text-xs font-bold text-slate-200 cursor-pointer"
          >
            ✕ {txt.close}
          </button>
        </div>

        {/* Tabs */}
        <div className="px-4 pt-3 flex gap-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setTab('controls')}
            className={`pixel-btn px-3 py-1.5 text-xs font-bold cursor-pointer ${
              tab === 'controls' ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
            }`}
          >
            🎮 {isFa ? 'کنترل‌ها و بقا' : 'Controls & Tips'}
          </button>
          <button
            onClick={() => setTab('zones')}
            className={`pixel-btn px-3 py-1.5 text-xs font-bold cursor-pointer ${
              tab === 'zones' ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
            }`}
          >
            🗺 {txt.islandZones}
          </button>
          <button
            onClick={() => setTab('zombies')}
            className={`pixel-btn px-3 py-1.5 text-xs font-bold cursor-pointer ${
              tab === 'zombies' ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
            }`}
          >
            🧟 {txt.zombieTypes}
          </button>
        </div>

        {/* Content */}
        <div
          dir={isFa ? 'rtl' : 'ltr'}
          className="flex-1 overflow-y-auto custom-scroll p-4 space-y-4"
        >
          {tab === 'controls' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-[#0e171b] border border-slate-800 p-3.5 space-y-2">
                <h3 className="text-xs font-bold text-emerald-300">💻 {txt.controlsDesktop}</h3>
                <ul className="space-y-1.5 text-xs text-slate-200">
                  <li>
                    <span className="font-pixel-ui text-amber-300">WASD / Arrows</span> —{' '}
                    {isFa ? 'حرکت به چهار و هشت جهت' : 'Move in all directions'}
                  </li>
                  <li>
                    <span className="font-pixel-ui text-amber-300">SHIFT</span> —{' '}
                    {isFa ? 'دویدن سریع (مصرف استقامت)' : 'Sprint (uses stamina)'}
                  </li>
                  <li>
                    <span className="font-pixel-ui text-amber-300">MOUSE + LEFT CLICK</span> —{' '}
                    {isFa ? 'نشانه‌گیری ۳۶۰ درجه و شلیک' : '360° Aim & Shoot'}
                  </li>
                  <li>
                    <span className="font-pixel-ui text-amber-300">R</span> —{' '}
                    {isFa ? 'تعویض خشاب' : 'Reload weapon'}
                  </li>
                  <li>
                    <span className="font-pixel-ui text-amber-300">G / RIGHT CLICK</span> —{' '}
                    {isFa ? 'پرتاب نارنجک جنگی' : 'Throw Frag Grenade'}
                  </li>
                  <li>
                    <span className="font-pixel-ui text-amber-300">Q / E / 1-8 / WHEEL</span> —{' '}
                    {isFa ? 'تعویض اسلحه' : 'Switch owned weapons'}
                  </li>
                  <li>
                    <span className="font-pixel-ui text-amber-300">F</span> —{' '}
                    {isFa ? 'باز کردن جعبه‌های تجهیزات (یا شلیک به آن‌ها)' : 'Open supply crates (or shoot them)'}
                  </li>
                  <li>
                    <span className="font-pixel-ui text-amber-300">B / ESC</span> —{' '}
                    {isFa ? 'فروشگاه اسلحه / توقف بازی' : 'Weapon Shop / Pause Menu'}
                  </li>
                </ul>
              </div>

              <div className="bg-[#0e171b] border border-slate-800 p-3.5 space-y-2">
                <h3 className="text-xs font-bold text-cyan-300">📱 {txt.controlsMobile}</h3>
                <ul className="space-y-1.5 text-xs text-slate-200">
                  <li>
                    •{' '}
                    {isFa
                      ? 'جوی‌استیک چپ: حرکت و با کشیدن تا لبه بیرونی، دویدن سریع!'
                      : 'Left Joystick: Move smoothly; push outer rim to Sprint!'}
                  </li>
                  <li>
                    •{' '}
                    {isFa
                      ? 'جوی‌استیک راست: نشانه‌گیری و شلیک همزمان + دکمه‌های اختصاصی شلیک، خشاب و نارنجک.'
                      : 'Right Aim Pad: Aim & fire seamlessly + dedicated Reload, Frag & Weapon Switch buttons.'}
                  </li>
                  <li>
                    •{' '}
                    {isFa
                      ? 'برای تجربه ایده‌آل در اندروید، گوشی را در حالت افقی (Landscape) نگه دارید.'
                      : 'Designed for crisp Android & iOS Landscape play!'}
                  </li>
                </ul>

                <div className="mt-3 pt-2 border-t border-slate-800">
                  <h4 className="text-xs font-bold text-amber-300 mb-1">🔥 {txt.survivalTips}</h4>
                  <ul className="space-y-1 text-[11px] text-slate-300 leading-relaxed">
                    <li>
                      •{' '}
                      {isFa
                        ? 'به بشکه‌های قرمز رنگ شلیک کنید تا با انفجار زنجیره‌ای گله زامبی‌ها را نابود کنید!'
                        : 'Shoot red explosive barrels to wipe out pursuing zombie packs in chain blasts!'}
                    </li>
                    <li>
                      •{' '}
                      {isFa
                        ? 'هر ۵ موج یک زامبی غول‌پیکر (Boss) ظاهر می‌شود؛ قبل از آن اسلحه خود را در فروشگاه ارتقا دهید.'
                        : 'Every 5th wave spawns a Giant Titan Boss—upgrade weapons in the Shop between waves!'}
                    </li>
                    <li>
                      •{' '}
                      {isFa
                        ? 'در بیمارستان بسته‌های سلامتی بیشتر و در انبار مهمات فشنگ فراوان پیدا می‌کنید.'
                        : 'Visit the Hospital for Medkits, Ammo Depot for munitions, and Caves for gold!'}
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {tab === 'zones' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {ALL_ZONES.map((zid) => {
                const z = ZONE_INFO[zid];
                return (
                  <div
                    key={zid}
                    className="bg-[#0e171b] border border-slate-800 p-3 flex flex-col gap-1"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-3 h-3 shrink-0 border border-black"
                        style={{ backgroundColor: z.accent }}
                      />
                      <span className="text-xs font-bold text-slate-100">
                        {isFa ? z.nameFa : z.nameEn}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      {isFa ? z.descFa : z.descEn}
                    </p>
                    <div className="text-[10px] font-bold text-amber-300 mt-0.5">
                      ★ {isFa ? z.lootHintFa : z.lootHintEn}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'zombies' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {ALL_ZOMBIES.map((zt) => {
                const info = ZOMBIE_INFO[zt];
                return (
                  <div
                    key={zt}
                    className="bg-[#0e171b] border border-slate-800 p-3 flex items-center gap-3"
                  >
                    <div className="w-16 h-16 bg-[#080e11] border border-slate-800 flex items-center justify-center shrink-0">
                      <PixelSpritePreview
                        target={{ kind: 'zombie', type: zt }}
                        scale={zt === 'giant' ? 2 : 3}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold" style={{ color: info.color }}>
                        {isFa ? info.nameFa : info.nameEn}
                      </div>
                      <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                        {isFa ? info.descFa : info.descEn}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
