import React from 'react';
import { CHARACTER_ORDER, CHARACTERS } from '../game/characters';
import { t } from '../game/i18n';
import { CharacterId, SaveData } from '../game/types';
import { PixelSpritePreview } from './PixelSpritePreview';

interface CharacterModalProps {
  saveData: SaveData;
  onSelectCharacter: (id: CharacterId) => void;
  onUnlockCharacter: (id: CharacterId) => void;
  onClose: () => void;
}

export const CharacterModal: React.FC<CharacterModalProps> = ({
  saveData,
  onSelectCharacter,
  onUnlockCharacter,
  onClose,
}) => {
  const lang = saveData.settings.language;
  const txt = t(lang);
  const isFa = lang === 'fa';

  return (
    <div className="fixed inset-0 z-40 bg-black/75 backdrop-blur-[2px] flex items-center justify-center p-2 sm:p-4">
      <div className="pixel-panel w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        <div className="px-4 py-3 border-b border-emerald-900/80 flex items-center justify-between bg-[#0f191d]">
          <h2 className="font-pixel text-xs sm:text-sm text-cyan-300">
            CHARACTER {isFa ? `• ${txt.selectSurvivor}` : ''}
          </h2>
          <div className="flex items-center gap-3">
            <div className="px-2.5 py-1 bg-[#0a1114] border border-amber-600/60 flex items-center gap-1.5 text-amber-300 text-xs font-pixel-ui">
              <PixelSpritePreview target={{ kind: 'pickup', type: 'coin' }} scale={2} />
              <span>{saveData.coins}</span>
            </div>
            <button
              onClick={onClose}
              className="pixel-btn px-3 py-1 text-xs font-bold text-slate-200 cursor-pointer"
            >
              ✕ {txt.close}
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scroll p-3 sm:p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
          {CHARACTER_ORDER.map((cid) => {
            const ch = CHARACTERS[cid];
            const owned = saveData.unlockedCharacters.includes(cid);
            const selected = saveData.selectedCharacter === cid;

            return (
              <div
                key={cid}
                className={`p-3.5 border-2 flex flex-col justify-between gap-3 ${
                  selected
                    ? 'bg-emerald-950/60 border-emerald-400'
                    : 'bg-[#0e171b] border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-20 h-24 bg-[#080f12] border border-slate-700/80 flex items-center justify-center shrink-0">
                    <PixelSpritePreview target={{ kind: 'character', id: cid }} scale={3} />
                  </div>
                  <div className="flex-1 min-w-0" dir={isFa ? 'rtl' : 'ltr'}>
                    <div className="text-sm font-extrabold text-amber-200">
                      {isFa ? ch.nameFa : ch.nameEn}
                    </div>
                    <div className="text-xs text-cyan-300/90 mt-0.5">
                      {isFa ? ch.roleFa : ch.roleEn}
                    </div>
                    <p className="text-[11px] text-slate-300 mt-1.5 leading-relaxed">
                      {isFa ? ch.perkFa : ch.perkEn}
                    </p>
                  </div>
                </div>

                {/* Compact Stat Chips */}
                <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] font-pixel-ui">
                  <div className="bg-[#091014] border border-slate-800 py-1">
                    <div className="text-slate-400">HP</div>
                    <div className="text-emerald-300 font-bold">{100 + ch.maxHpBonus}</div>
                  </div>
                  <div className="bg-[#091014] border border-slate-800 py-1">
                    <div className="text-slate-400">SPD</div>
                    <div className="text-cyan-300 font-bold">+{Math.round(ch.speedBonus * 100)}%</div>
                  </div>
                  <div className="bg-[#091014] border border-slate-800 py-1">
                    <div className="text-slate-400">DMG</div>
                    <div className="text-orange-300 font-bold">+{Math.round(ch.damageBonus * 100)}%</div>
                  </div>
                  <div className="bg-[#091014] border border-slate-800 py-1">
                    <div className="text-slate-400">RLD</div>
                    <div className="text-amber-300 font-bold">+{Math.round(ch.reloadBonus * 100)}%</div>
                  </div>
                </div>

                {owned ? (
                  <button
                    onClick={() => onSelectCharacter(cid)}
                    disabled={selected}
                    className={`pixel-btn py-2 text-xs font-bold cursor-pointer ${
                      selected ? 'border-emerald-400 text-emerald-300' : 'pixel-btn-primary text-white'
                    }`}
                  >
                    {selected ? `✓ ${txt.selected}` : txt.select}
                  </button>
                ) : (
                  <button
                    onClick={() => onUnlockCharacter(cid)}
                    disabled={saveData.coins < ch.cost}
                    className="pixel-btn pixel-btn-gold py-2 text-xs font-bold text-amber-100 cursor-pointer"
                  >
                    🔒 {txt.unlock} ({ch.cost} {txt.coins})
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
