import React, { useState } from 'react';
import { t } from '../game/i18n';
import { GameSettings, TouchMode } from '../game/types';

interface SettingsModalProps {
  settings: GameSettings;
  onChange: (updated: GameSettings) => void;
  onResetSave: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onChange,
  onResetSave,
  onClose,
}) => {
  const txt = t(settings.language);
  const isFa = settings.language === 'fa';
  const [confirmReset, setConfirmReset] = useState(false);

  const patch = <K extends keyof GameSettings>(key: K, val: GameSettings[K]) => {
    onChange({ ...settings, [key]: val });
  };

  const renderSlider = (label: string, key: 'masterVolume' | 'sfxVolume' | 'musicVolume' | 'ambienceVolume') => (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-slate-200">{label}</span>
        <span className="font-pixel-ui text-emerald-300">{Math.round(settings[key] * 100)}%</span>
      </div>
      <input
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={settings[key]}
        onChange={(e) => patch(key, parseFloat(e.target.value))}
        className="w-full accent-emerald-400 cursor-pointer"
      />
    </div>
  );

  return (
    <div className="fixed inset-0 z-40 bg-black/75 backdrop-blur-[2px] flex items-center justify-center p-2 sm:p-4">
      <div className="pixel-panel w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden">
        <div className="px-4 py-3 border-b border-emerald-900/80 flex items-center justify-between bg-[#0f191d]">
          <h2 className="font-pixel text-xs sm:text-sm text-emerald-300">
            SETTINGS {isFa ? `• ${txt.settings}` : ''}
          </h2>
          <button
            onClick={onClose}
            className="pixel-btn px-3 py-1 text-xs font-bold text-slate-200 cursor-pointer"
          >
            ✕ {txt.close}
          </button>
        </div>

        <div
          dir={isFa ? 'rtl' : 'ltr'}
          className="flex-1 overflow-y-auto custom-scroll p-4 space-y-4"
        >
          {/* Language */}
          <div className="bg-[#0e171b] border border-slate-800 p-3 flex items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-200">{txt.language}</span>
            <div className="flex gap-2">
              <button
                onClick={() => patch('language', 'fa')}
                className={`pixel-btn px-3 py-1 text-xs font-bold cursor-pointer ${
                  settings.language === 'fa' ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
                }`}
              >
                فارسی
              </button>
              <button
                onClick={() => patch('language', 'en')}
                className={`pixel-btn px-3 py-1 text-xs font-pixel-ui font-bold cursor-pointer ${
                  settings.language === 'en' ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
                }`}
              >
                English
              </button>
            </div>
          </div>

          {/* Audio Controls */}
          <div className="bg-[#0e171b] border border-slate-800 p-3 space-y-2.5">
            <div className="text-xs font-bold text-amber-300 mb-1">🔊 {txt.audio}</div>
            {renderSlider(txt.masterVol, 'masterVolume')}
            {renderSlider(txt.sfxVol, 'sfxVolume')}
            {renderSlider(txt.musicVol, 'musicVolume')}
            {renderSlider(txt.ambienceVol, 'ambienceVolume')}
          </div>

          {/* Touch Controls Mode */}
          <div className="bg-[#0e171b] border border-slate-800 p-3 space-y-2">
            <div className="text-xs font-bold text-cyan-300">🎮 {txt.controls}</div>
            <div className="grid grid-cols-3 gap-2">
              {(['auto', 'on', 'off'] as TouchMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => patch('touchMode', mode)}
                  className={`pixel-btn py-1.5 text-[11px] font-bold cursor-pointer ${
                    settings.touchMode === mode ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
                  }`}
                >
                  {mode === 'auto' ? txt.touchAuto : mode === 'on' ? txt.touchOn : txt.touchOff}
                </button>
              ))}
            </div>
          </div>

          {/* Graphics & HUD Toggles */}
          <div className="bg-[#0e171b] border border-slate-800 p-3 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-200">{txt.graphics}</span>
              <div className="flex gap-2">
                {(['high', 'medium'] as const).map((q) => (
                  <button
                    key={q}
                    onClick={() => patch('quality', q)}
                    className={`pixel-btn px-3 py-1 text-xs cursor-pointer ${
                      settings.quality === q ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
                    }`}
                  >
                    {q === 'high' ? txt.high : txt.medium}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-200">{txt.screenShake}</span>
              <button
                onClick={() => patch('screenShake', !settings.screenShake)}
                className={`pixel-btn px-3 py-1 text-xs font-bold cursor-pointer ${
                  settings.screenShake ? 'border-emerald-400 text-emerald-300' : 'text-slate-400'
                }`}
              >
                {settings.screenShake ? 'ON' : 'OFF'}
              </button>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-200">{txt.minimap}</span>
              <button
                onClick={() => patch('showMinimap', !settings.showMinimap)}
                className={`pixel-btn px-3 py-1 text-xs font-bold cursor-pointer ${
                  settings.showMinimap ? 'border-emerald-400 text-emerald-300' : 'text-slate-400'
                }`}
              >
                {settings.showMinimap ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>

          {/* Danger Zone: Reset Save */}
          <div className="pt-1 flex justify-end">
            <button
              onClick={() => {
                if (!confirmReset) {
                  setConfirmReset(true);
                  return;
                }
                onResetSave();
                setConfirmReset(false);
              }}
              className="pixel-btn px-3.5 py-1.5 text-xs font-bold border-red-700/80 text-red-300 hover:border-red-400 cursor-pointer"
            >
              {confirmReset ? `⚠ ${txt.resetConfirm}` : `🗑 ${txt.resetSave}`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
