import React from 'react';
import { CHARACTERS } from '../game/characters';
import { t, ZONE_INFO } from '../game/i18n';
import { Language, SaveData } from '../game/types';
import { PixelSpritePreview } from './PixelSpritePreview';

interface MainMenuProps {
  saveData: SaveData;
  onPlay: () => void;
  onContinue: () => void;
  onOpenShop: () => void;
  onOpenCharacter: () => void;
  onOpenSettings: () => void;
  onOpenHowToPlay: () => void;
  onExit: () => void;
  onToggleLanguage: (lang: Language) => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  saveData,
  onPlay,
  onContinue,
  onOpenShop,
  onOpenCharacter,
  onOpenSettings,
  onOpenHowToPlay,
  onExit,
  onToggleLanguage,
}) => {
  const lang = saveData.settings.language;
  const txt = t(lang);
  const isFa = lang === 'fa';
  const charDef = CHARACTERS[saveData.selectedCharacter];
  const hasSavedRun = Boolean(saveData.activeRun);

  return (
    <div className="relative z-10 w-full h-full flex flex-col justify-between p-3 sm:p-6 overflow-y-auto custom-scroll">
      {/* Top Bar: Survivor Stats & Language Switcher */}
      <div className="w-full max-w-5xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="pixel-panel px-3 py-1.5 flex items-center gap-3 text-xs sm:text-sm">
          <div className="flex items-center gap-1.5 text-amber-300 font-bold">
            <PixelSpritePreview target={{ kind: 'pickup', type: 'coin' }} scale={2} />
            <span className="font-pixel-ui">{saveData.coins}</span>
          </div>
          <div className="w-px h-4 bg-emerald-900/80" />
          <div className="flex items-center gap-1 text-emerald-300">
            <span className="opacity-75">{txt.bestWave}:</span>
            <span className="font-pixel-ui font-bold">{saveData.bestWave}</span>
          </div>
          <div className="w-px h-4 bg-emerald-900/80 hidden sm:block" />
          <div className="hidden sm:flex items-center gap-1 text-red-300">
            <span className="opacity-75">{txt.totalKills}:</span>
            <span className="font-pixel-ui font-bold">{saveData.totalKills}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onToggleLanguage('fa')}
            className={`pixel-btn px-2.5 py-1 text-xs font-bold cursor-pointer ${
              isFa ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
            }`}
          >
            فارسی
          </button>
          <button
            onClick={() => onToggleLanguage('en')}
            className={`pixel-btn px-2.5 py-1 text-xs font-pixel-ui font-bold cursor-pointer ${
              !isFa ? 'border-emerald-400 text-emerald-200' : 'text-slate-400'
            }`}
          >
            EN
          </button>
        </div>
      </div>

      {/* Main Content Grid: Title + Survivor Badge & 7 Tactical Menu Buttons */}
      <div className="w-full max-w-5xl mx-auto my-auto py-3 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        {/* Left/Center Title Showcase */}
        <div className="md:col-span-7 flex flex-col items-center md:items-start text-center md:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1 mb-2 bg-red-950/80 border border-red-600/60 text-red-200 text-[10px] sm:text-xs font-pixel-ui tracking-wider">
            <span className="w-2 h-2 bg-red-500 animate-pulse" />
            <span>BIOHAZARD QUARANTINE ZONE • SECTOR 09</span>
          </div>

          <h1 className="font-pixel text-xl sm:text-3xl lg:text-4xl leading-snug tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-amber-200 via-orange-400 to-red-600 drop-shadow-[0_4px_0_rgba(12,6,6,0.95)]">
            ISLAND ZOMBIE
            <br />
            SURVIVAL
          </h1>

          <p
            dir={isFa ? 'rtl' : 'ltr'}
            className="mt-2 text-xs sm:text-sm text-emerald-100/90 max-w-md drop-shadow-[0_2px_2px_rgba(0,0,0,0.95)]"
          >
            {isFa
              ? 'در جزیره‌ای متروکه و زامبی‌زده زنده بمانید؛ جنگل، ساحل، بیمارستان، پایگاه نظامی، غارها و منطقه آلوده را کشف کنید!'
              : 'Survive endless undead waves across 8 hand-crafted pixel regions: dense jungle, beaches, hospital, military base, caves & bio-zone.'}
          </p>

          {/* Active Survivor Card */}
          <div className="mt-3 pixel-panel px-3.5 py-2.5 flex items-center gap-3 max-w-sm w-full">
            <div className="w-12 h-14 bg-[#0d171c] border border-emerald-800/70 flex items-center justify-center shrink-0">
              <PixelSpritePreview target={{ kind: 'character', id: charDef.id }} scale={2} />
            </div>
            <div className="flex-1 min-w-0" dir={isFa ? 'rtl' : 'ltr'}>
              <div className="text-xs font-bold text-amber-300 truncate">
                {isFa ? charDef.nameFa : charDef.nameEn}
              </div>
              <div className="text-[11px] text-emerald-300/80 truncate">
                {isFa ? charDef.roleFa : charDef.roleEn}
              </div>
              <div className="text-[10px] text-slate-300/85 mt-0.5 line-clamp-1">
                {isFa ? charDef.perkFa : charDef.perkEn}
              </div>
            </div>
          </div>
        </div>

        {/* Right: All 7 Apocalyptic Pixel Menu Buttons */}
        <div className="md:col-span-5 pixel-panel p-3 sm:p-4 flex flex-col gap-2">
          {/* 1. PLAY */}
          <button
            onClick={onPlay}
            className="pixel-btn pixel-btn-primary px-4 py-2.5 flex items-center justify-between cursor-pointer group"
          >
            <span className="font-pixel text-xs sm:text-sm text-amber-100 tracking-wide">
              ▶ PLAY
            </span>
            {isFa && <span className="text-xs font-bold text-amber-200">{txt.play}</span>}
          </button>

          {/* 2. CONTINUE */}
          <button
            onClick={onContinue}
            disabled={!hasSavedRun}
            className="pixel-btn pixel-btn-gold px-4 py-2 flex items-center justify-between cursor-pointer"
          >
            <div className="flex flex-col items-start">
              <span className="font-pixel text-[11px] sm:text-xs text-amber-100">
                CONTINUE
              </span>
              <span className="text-[10px] text-amber-200/80">
                {hasSavedRun && saveData.activeRun
                  ? `${isFa ? 'موج' : 'Wave'} ${saveData.activeRun.wave} • ${
                      isFa
                        ? ZONE_INFO[saveData.activeRun.zone].nameFa
                        : ZONE_INFO[saveData.activeRun.zone].nameEn
                    }`
                  : txt.noSavedRun}
              </span>
            </div>
            {isFa && <span className="text-xs font-bold text-amber-100">{txt.continue}</span>}
          </button>

          {/* 3 & 4: WEAPON SHOP + CHARACTER */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onOpenShop}
              className="pixel-btn px-3 py-2 flex flex-col items-center justify-center gap-0.5 cursor-pointer"
            >
              <span className="font-pixel-ui text-xs text-emerald-200">WEAPON SHOP</span>
              {isFa && <span className="text-[11px] text-emerald-400/90">{txt.weaponShop}</span>}
            </button>

            <button
              onClick={onOpenCharacter}
              className="pixel-btn px-3 py-2 flex flex-col items-center justify-center gap-0.5 cursor-pointer"
            >
              <span className="font-pixel-ui text-xs text-cyan-200">CHARACTER</span>
              {isFa && <span className="text-[11px] text-cyan-400/90">{txt.character}</span>}
            </button>
          </div>

          {/* 5 & 6: SETTINGS + HOW TO PLAY */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onOpenSettings}
              className="pixel-btn px-3 py-2 flex flex-col items-center justify-center gap-0.5 cursor-pointer"
            >
              <span className="font-pixel-ui text-xs text-slate-200">SETTINGS</span>
              {isFa && <span className="text-[11px] text-slate-400">{txt.settings}</span>}
            </button>

            <button
              onClick={onOpenHowToPlay}
              className="pixel-btn px-3 py-2 flex flex-col items-center justify-center gap-0.5 cursor-pointer"
            >
              <span className="font-pixel-ui text-xs text-amber-200">HOW TO PLAY</span>
              {isFa && <span className="text-[11px] text-amber-400/90">{txt.howToPlay}</span>}
            </button>
          </div>

          {/* 7. EXIT */}
          <button
            onClick={onExit}
            className="pixel-btn px-4 py-1.5 flex items-center justify-between text-slate-300 hover:text-red-300 hover:border-red-500/70 cursor-pointer"
          >
            <span className="font-pixel-ui text-xs">EXIT</span>
            {isFa && <span className="text-xs">{txt.exit}</span>}
          </button>
        </div>
      </div>

      {/* Bottom Footer Hint */}
      <div className="w-full max-w-5xl mx-auto flex items-center justify-between text-[10px] sm:text-xs text-slate-400/90">
        <span className="font-pixel-ui">HTML5 CANVAS • 2D PIXEL SURVIVAL ENGINE</span>
        <span dir={isFa ? 'rtl' : 'ltr'}>
          {isFa ? 'سازگار با موبایل (لمسی افقی) و کامپیوتر' : 'Desktop (WASD + Mouse) & Mobile Landscape Touch'}
        </span>
      </div>
    </div>
  );
};
