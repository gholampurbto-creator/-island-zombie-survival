import React, { useEffect, useRef } from 'react';
import { getSpriteAtlas } from '../game/sprites';
import { CharacterId, WeaponId, ZombieType } from '../game/types';

type PreviewTarget =
  | { kind: 'weapon'; id: WeaponId }
  | { kind: 'grenade' }
  | { kind: 'character'; id: CharacterId; animate?: boolean }
  | { kind: 'zombie'; type: ZombieType; animate?: boolean }
  | { kind: 'pickup'; type: 'medkit' | 'ammo' | 'coin' | 'scrap' };

interface Props {
  target: PreviewTarget;
  scale?: number;
  className?: string;
}

export const PixelSpritePreview: React.FC<Props> = ({ target, scale = 3, className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const atlas = getSpriteAtlas();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frameIdx = 0;
    let timer: number | null = null;

    const getSource = (f: number): HTMLCanvasElement => {
      if (target.kind === 'weapon') return atlas.weapons[target.id];
      if (target.kind === 'grenade') return atlas.grenade;
      if (target.kind === 'character') {
        const frames = atlas.characters[target.id].walk;
        return frames[f % frames.length];
      }
      if (target.kind === 'zombie') {
        const frames = atlas.zombies[target.type].walk;
        return frames[f % frames.length];
      }
      if (target.type === 'coin') {
        return atlas.pickups.coin[f % atlas.pickups.coin.length];
      }
      return atlas.pickups[target.type];
    };

    const draw = () => {
      const spr = getSource(frameIdx);
      const w = spr.width * scale;
      const h = spr.height * scale;
      if (canvas.width !== w || canvas.height !== h) {
        canvas.width = w;
        canvas.height = h;
      }
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, w, h);
      ctx.drawImage(spr, 0, 0, w, h);
    };

    draw();

    const shouldAnimate =
      (target.kind === 'character' && target.animate !== false) ||
      (target.kind === 'zombie' && target.animate !== false) ||
      (target.kind === 'pickup' && target.type === 'coin');

    if (shouldAnimate) {
      timer = window.setInterval(() => {
        frameIdx = (frameIdx + 1) % 4;
        draw();
      }, 190);
    }

    return () => {
      if (timer !== null) window.clearInterval(timer);
    };
  }, [target, scale]);

  return (
    <canvas
      ref={canvasRef}
      className={`inline-block [image-rendering:pixelated] ${className}`}
    />
  );
};
