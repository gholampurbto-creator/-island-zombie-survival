import React, { useEffect, useRef, useState } from 'react';
import { t, ZONE_INFO } from '../game/i18n';
import { HudSnapshot, Language, TouchMode, WeaponId } from '../game/types';
import { WEAPON_ORDER, WEAPONS } from '../game/weapons';
import { PixelSpritePreview } from './PixelSpritePreview';

interface GameHUDProps {
  hud: HudSnapshot;
  language: Language;
  touchMode: TouchMode;
  onSwitchWeapon: (id: WeaponId) => void;
  onCycleWeapon: (dir: number) => void;
  onReload: () => void;
  onThrowGrenade: () => void;
  onOpenShop: () => void;
  onPause: () => void;
  onSkipIntermission: () => void;
  onOpenCrate: () => void;
  onTouchMove: (x: number, y: number, sprint: boolean) => void;
  onTouchAim: (x: number, y: number, active: boolean, firing: boolean) => void;
  onTouchFireButton: (pressed: boolean) => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  hud,
  language,
  touchMode,
  onSwitchWeapon,
  onCycleWeapon,
  onReload,
  onThrowGrenade,
  onOpenShop,
  onPause,
  onSkipIntermission,
  onOpenCrate,
  onTouchMove,
  onTouchAim,
  onTouchFireButton,
}) => {
  const txt = t(language);
  const isFa = language === 'fa';
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  // Virtual joystick visual knob offsets
  const [moveKnob, setMoveKnob] = useState({ x: 0, y: 0, active: false });
  const [aimKnob, setAimKnob] = useState({ x: 0, y: 0, active: false });
  const movePointerId = useRef<number | null>(null);
  const aimPointerId = useRef<number | null>(null);
  const movePadRef = useRef<HTMLDivElement | null>(null);
  const aimPadRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const check = () => {
      const coarse =
        'ontouchstart' in window ||
        navigator.maxTouchPoints > 0 ||
        window.matchMedia('(pointer: coarse)').matches;
      setIsTouchDevice(coarse);
    };
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const showTouchControls =
    touchMode === 'on' || (touchMode === 'auto' && isTouchDevice);

  const hpPct = Math.max(0, Math.min(100, (hud.hp / Math.max(1, hud.maxHp)) * 100));
  const stamPct = Math.max(0, Math.min(100, (hud.stamina / Math.max(1, hud.maxStamina)) * 100));
  const zoneInfo = ZONE_INFO[hud.zone];
  const weaponDef = WEAPONS[hud.equippedWeapon];

  const handleMovePointer = (e: React.PointerEvent, phase: 'down' | 'move' | 'up') => {
    e.stopPropagation();
    const el = movePadRef.current;
    if (!el) return;
    if (phase === 'down') {
      movePointerId.current = e.pointerId;
      el.setPointerCapture(e.pointerId);
    }
    if (movePointerId.current !== e.pointerId) return;
    if (phase === 'up') {
      movePointerId.current = null;
      setMoveKnob({ x: 0, y: 0, active: false });
      onTouchMove(0, 0, false);
      return;
    }
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.4;
    let dx = e.clientX - cx;
    let dy = e.clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    const nx = dx / maxR;
    const ny = dy / maxR;
    setMoveKnob({ x: dx, y: dy, active: true });
    onTouchMove(nx, ny, dist >= maxR * 0.85);
  };

  const handleAimPointer = (e: React.PointerEvent, phase: 'down' | 'move' | 'up') => {
    e.stopPropagation();
    const el = aimPadRef.current;
    if (!el) return;
    if (phase === 'down') {
      aimPointerId.current = e.pointerId;
      el.setPointerCapture(e.pointerId);
    }
    if (aimPointerId.current !== e.pointerId) return;
    if (phase === 'up') {
      aimPointerId.current = null;
      setAimKnob({ x: 0, y: 0, active: false });
      onTouchAim(0, 0, false, false);
      return;
    }
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const maxR = rect.width * 0.4;
    let dx = e.clientX - cx;
    let dy = e.clientY - cy;
    const dist = Math.hypot(dx, dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    const nx = dx / maxR;
    const ny = dy / maxR;
    setAimKnob({ x: dx, y: dy, active: true });
    onTouchAim(nx, ny, dist > 5, dist > maxR * 0.3);
  };

  const ownedWeapons = WEAPON_ORDER.filter((w) => hud.unlockedWeapons.includes(w));

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-2 sm:p-3">
      {/* =================================================
          TOP BAR: HP/STAMINA | WAVE + BOSS | COINS & ACTIONS
          ================================================= */}
      <div className="flex items-start justify-between gap-2">
        {/* Top-Left: Health, Stamina, Zone & Kills */}
        <div className="flex flex-col gap-1.5 max-w-[230px] sm:max-w-[265px] w-full">
          <div className="pixel-panel px-2.5 py-2 space-y-1.5">
            {/* HP Bar */}
            <div className="flex items-center justify-between text-[10px] sm:text-xs font-pixel-ui">
              <span className={hpPct <= 30 ? 'text-red-400 animate-pulse' : 'text-emerald-300'}>
                ❤ HP
              </span>
              <span className="text-slate-100">
                {hud.hp} / {hud.maxHp}
              </span>
            </div>
            <div className="h-3 bg-[#090e12] border border-slate-700 p-[1px]">
              <div
                className={`h-full transition-all duration-100 ${
                  hpPct > 55
                    ? 'bg-gradient-to-r from-emerald-600 to-emerald-400'
                    : hpPct > 28
                    ? 'bg-gradient-to-r from-amber-600 to-amber-400'
                    : 'bg-gradient-to-r from-red-700 to-red-500 animate-pulse'
                }`}
                style={{ width: `${hpPct}%` }}
              />
            </div>

            {/* Stamina Bar */}
            <div className="h-1.5 bg-[#090e12] border border-slate-800">
              <div
                className="h-full bg-cyan-400 transition-all duration-75"
                style={{ width: `${stamPct}%` }}
              />
            </div>

            {/* Compact Stats Row: Kills, Coins, Zone */}
            <div className="flex items-center justify-between pt-0.5 text-[10px] sm:text-[11px] font-pixel-ui">
              <span className="text-red-300" title="Kills">
                ☠ {hud.kills}
              </span>
              <span className="text-amber-300 flex items-center gap-1" title="Coins">
                <PixelSpritePreview target={{ kind: 'pickup', type: 'coin' }} scale={2} />
                {hud.coins}
              </span>
              <span className="text-slate-300">PTS {hud.score}</span>
            </div>
          </div>

          {/* Current Zone Pill */}
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#0b1317]/90 border border-slate-700/80 text-[10px] sm:text-xs self-start">
            <span className="w-2 h-2 shrink-0" style={{ backgroundColor: zoneInfo.accent }} />
            <span className="font-bold text-slate-100 truncate">
              {isFa ? zoneInfo.nameFa : zoneInfo.nameEn}
            </span>
          </div>

          {hud.inToxicSludge && (
            <div className="px-2 py-0.5 bg-lime-950/90 border border-lime-400 text-lime-200 text-[10px] font-bold animate-pulse self-start">
              ☣ {txt.toxicWarning}
            </div>
          )}
        </div>

        {/* Top-Center: Wave Tracker + Intermission + Boss Health Bar */}
        <div className="flex flex-col items-center gap-1.5 flex-1 max-w-md mx-auto">
          <div className="pixel-panel px-3 py-1.5 flex items-center gap-2.5 sm:gap-3.5 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="font-pixel text-[10px] sm:text-xs text-amber-300">
                {txt.wave} {hud.wave}
              </span>
            </div>
            <div className="w-px h-4 bg-slate-700" />
            {hud.inIntermission ? (
              <div className="flex items-center gap-2 pointer-events-auto">
                <span className="text-emerald-300 font-bold text-[11px] sm:text-xs">
                  {txt.intermission} {hud.intermissionSeconds}s
                </span>
                <button
                  onClick={onSkipIntermission}
                  className="pixel-btn pixel-btn-primary px-2 py-0.5 text-[10px] font-bold text-white cursor-pointer"
                >
                  ▶
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1 text-red-300 font-pixel-ui text-[11px]">
                <span>🧟</span>
                <span>{hud.waveZombiesRemaining}</span>
              </div>
            )}
          </div>

          {/* Boss HP Bar */}
          {hud.boss && (
            <div className="w-full max-w-xs sm:max-w-sm pixel-panel px-2.5 py-1.5 border-red-500 animate-danger-glow">
              <div className="flex justify-between text-[10px] font-bold text-red-300 mb-1">
                <span>☠ {isFa ? hud.boss.nameFa : hud.boss.nameEn}</span>
                <span className="font-pixel-ui">
                  {hud.boss.hp} / {hud.boss.maxHp}
                </span>
              </div>
              <div className="h-2.5 bg-[#120709] border border-red-700">
                <div
                  className="h-full bg-gradient-to-r from-red-700 via-red-500 to-orange-400 transition-all duration-100"
                  style={{ width: `${(hud.boss.hp / Math.max(1, hud.boss.maxHp)) * 100}%` }}
                />
              </div>
            </div>
          )}

          {/* Event / Zone Banner */}
          {hud.statusBanner && (
            <div
              className="px-3 py-1 bg-[#090f14]/92 border-2 text-center text-[11px] sm:text-xs font-bold shadow-lg"
              style={{
                borderColor: hud.statusBanner.color,
                color: hud.statusBanner.color,
              }}
            >
              {isFa ? hud.statusBanner.textFa : hud.statusBanner.textEn}
            </div>
          )}
        </div>

        {/* Top-Right: Shop & Pause Quick Buttons (above Minimap!) */}
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button
            onClick={onOpenShop}
            className="pixel-btn pixel-btn-gold px-2.5 py-1.5 text-[11px] sm:text-xs font-bold text-amber-100 cursor-pointer"
          >
            🛒 {txt.shop}
          </button>
          <button
            onClick={onPause}
            className="pixel-btn px-2.5 py-1.5 text-[11px] sm:text-xs font-bold text-slate-100 cursor-pointer"
          >
            ⏸
          </button>
        </div>
      </div>

      {/* =================================================
          BOTTOM BAR: WEAPON PANEL + AMMO + ACTION BUTTONS + TOUCH PADS
          ================================================= */}
      <div className="flex items-end justify-between gap-2 relative">
        {/* Left Touch Movement Joystick (when touch controls enabled) */}
        {showTouchControls ? (
          <div className="pointer-events-auto flex flex-col items-start gap-2 mb-1 ml-1">
            <div
              ref={movePadRef}
              onPointerDown={(e) => handleMovePointer(e, 'down')}
              onPointerMove={(e) => handleMovePointer(e, 'move')}
              onPointerUp={(e) => handleMovePointer(e, 'up')}
              onPointerCancel={(e) => handleMovePointer(e, 'up')}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-slate-900/55 border-2 border-emerald-400/50 relative flex items-center justify-center touch-none"
            >
              <div className="w-10 h-10 rounded-full border border-emerald-500/30" />
              <div
                className="w-12 h-12 rounded-full bg-emerald-500/75 border-2 border-emerald-200 shadow-lg absolute pointer-events-none"
                style={{
                  transform: `translate(${moveKnob.x}px, ${moveKnob.y}px)`,
                }}
              />
              <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[9px] font-pixel-ui text-emerald-300/80">
                MOVE
              </span>
            </div>
          </div>
        ) : (
          /* Desktop Quick Weapon Strip on Bottom-Left */
          <div className="pointer-events-auto hidden md:flex items-center gap-1 pixel-panel p-1.5">
            {ownedWeapons.map((wid, idx) => {
              const active = wid === hud.equippedWeapon;
              return (
                <button
                  key={wid}
                  onClick={() => onSwitchWeapon(wid)}
                  title={isFa ? WEAPONS[wid].nameFa : WEAPONS[wid].nameEn}
                  className={`px-1.5 py-1 border relative flex flex-col items-center cursor-pointer transition ${
                    active
                      ? 'bg-emerald-950/90 border-emerald-400'
                      : 'bg-[#0b1317] border-slate-800 hover:border-slate-600 opacity-80'
                  }`}
                >
                  <span className="absolute top-0 left-1 text-[8px] font-pixel-ui text-slate-400">
                    {idx + 1}
                  </span>
                  <PixelSpritePreview target={{ kind: 'weapon', id: wid }} scale={1.6} />
                </button>
              );
            })}
          </div>
        )}

        {/* Center-Bottom: Contextual Open Crate + Current Weapon, Ammo, Reload, Grenade & Switch Controls */}
        <div className="pointer-events-auto mx-auto flex flex-col items-center gap-1.5">
          {hud.nearbyCrate && (
            <button
              onClick={onOpenCrate}
              className="pixel-btn pixel-btn-gold px-3 py-1 text-[11px] font-bold text-amber-100 animate-bounce cursor-pointer"
            >
              📦 {isFa ? 'باز کردن جعبه (F)' : 'OPEN CRATE (F)'}
            </button>
          )}
          <div className="pixel-panel px-2.5 sm:px-3.5 py-2 flex items-center gap-2 sm:gap-3">
            {/* Switch Weapon Button */}
            <button
              onClick={() => onCycleWeapon(1)}
              className="pixel-btn px-2 py-1.5 text-[10px] font-pixel-ui text-emerald-200 cursor-pointer flex flex-col items-center leading-tight"
              title="Switch Weapon (Q/E)"
            >
              <span>⇄</span>
              <span className="text-[8px] text-emerald-400">
                {ownedWeapons.indexOf(hud.equippedWeapon) + 1}/{ownedWeapons.length}
              </span>
            </button>

            {/* Weapon Icon & Name */}
            <div className="flex items-center gap-2">
              <div className="w-12 h-8 sm:w-14 sm:h-9 bg-[#090f12] border border-slate-800 flex items-center justify-center shrink-0">
                <PixelSpritePreview target={{ kind: 'weapon', id: hud.equippedWeapon }} scale={2} />
              </div>
              <div className="min-w-[78px] sm:min-w-[105px]">
                <div className="text-[10px] sm:text-xs font-bold text-amber-200 truncate max-w-[115px]">
                  {isFa ? weaponDef.nameFa : weaponDef.nameEn}
                </div>
                {hud.reloading ? (
                  <div className="mt-1">
                    <div className="text-[9px] font-pixel-ui text-amber-300">{txt.reloading}</div>
                    <div className="h-1.5 bg-slate-900 border border-amber-500/60 mt-0.5">
                      <div
                        className="h-full bg-amber-400"
                        style={{ width: `${Math.round(hud.reloadProgress * 100)}%` }}
                      />
                    </div>
                  </div>
                ) : (
                  <div className="font-pixel-ui text-xs sm:text-sm text-slate-100">
                    <span className={hud.mag <= Math.ceil(hud.magSize * 0.25) ? 'text-red-400' : 'text-emerald-300'}>
                      {hud.mag}
                    </span>
                    <span className="text-slate-500 mx-0.5">/</span>
                    <span className="text-slate-300 text-[11px]">
                      {hud.infiniteReserve ? '∞' : hud.reserve}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Reload Button */}
            <button
              onClick={onReload}
              className="pixel-btn px-2.5 py-1.5 text-[10px] sm:text-xs font-bold text-amber-200 cursor-pointer"
              title="Reload (R)"
            >
              ⟳ {txt.reload}
            </button>

            {/* Grenade Button */}
            <button
              onClick={onThrowGrenade}
              disabled={hud.grenades <= 0}
              className="pixel-btn pixel-btn-primary px-2.5 py-1.5 flex items-center gap-1 text-[10px] sm:text-xs font-bold text-white cursor-pointer"
              title="Frag Grenade (G / Right Click)"
            >
              <PixelSpritePreview target={{ kind: 'grenade' }} scale={1.5} />
              <span className="font-pixel-ui">{hud.grenades}</span>
            </button>
          </div>
        </div>

        {/* Right Touch Controls: Aim & Fire Joystick + Dedicated Fire Button */}
        {showTouchControls ? (
          <div className="pointer-events-auto flex items-end gap-2 mb-1 mr-1">
            <button
              onPointerDown={(e) => {
                e.stopPropagation();
                onTouchFireButton(true);
              }}
              onPointerUp={(e) => {
                e.stopPropagation();
                onTouchFireButton(false);
              }}
              onPointerCancel={() => onTouchFireButton(false)}
              onPointerLeave={() => onTouchFireButton(false)}
              className="w-14 h-14 rounded-full bg-red-700/80 active:bg-red-500 border-2 border-red-300 text-white font-pixel text-[10px] shadow-lg flex items-center justify-center touch-none cursor-pointer"
            >
              FIRE
            </button>

            <div
              ref={aimPadRef}
              onPointerDown={(e) => handleAimPointer(e, 'down')}
              onPointerMove={(e) => handleAimPointer(e, 'move')}
              onPointerUp={(e) => handleAimPointer(e, 'up')}
              onPointerCancel={(e) => handleAimPointer(e, 'up')}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-red-950/50 border-2 border-red-400/60 relative flex items-center justify-center touch-none"
            >
              <div className="w-10 h-10 rounded-full border border-red-400/35" />
              <div
                className="w-12 h-12 rounded-full bg-red-500/80 border-2 border-amber-200 shadow-lg absolute pointer-events-none"
                style={{
                  transform: `translate(${aimKnob.x}px, ${aimKnob.y}px)`,
                }}
              />
              <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[9px] font-pixel-ui text-red-300/90">
                AIM+FIRE
              </span>
            </div>
          </div>
        ) : (
          <div className="hidden md:block text-[10px] text-slate-300/75 bg-black/55 border border-slate-800 px-2 py-1 font-pixel-ui">
            WASD • SHIFT • R • G • B • Q/E
          </div>
        )}
      </div>
    </div>
  );
};
