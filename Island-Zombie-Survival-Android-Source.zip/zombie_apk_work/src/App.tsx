import { useCallback, useEffect, useRef, useState } from 'react';
import { CharacterModal } from './components/CharacterModal';
import { GameHUD } from './components/GameHUD';
import { HowToPlayModal } from './components/HowToPlayModal';
import { MainMenu } from './components/MainMenu';
import { MenuBackground } from './components/MenuBackground';
import { PixelSpritePreview } from './components/PixelSpritePreview';
import { SettingsModal } from './components/SettingsModal';
import { WeaponShopModal } from './components/WeaponShopModal';
import { soundStudio } from './game/audio';
import { CHARACTERS } from './game/characters';
import { IslandSurvivalEngine } from './game/engine';
import { t } from './game/i18n';
import { loadSaveData, persistSaveData, resetAllSaveData } from './game/storage';
import {
  CharacterId,
  GameSettings,
  HudSnapshot,
  Language,
  SaveData,
  ScreenState,
  WeaponId,
} from './game/types';
import { getWeaponUpgradeCost, GRENADE_CONFIG, WEAPONS } from './game/weapons';

interface GameOverStats {
  wave: number;
  kills: number;
  score: number;
  timeSurvived: number;
}

export function App() {
  const [saveData, setSaveData] = useState<SaveData>(() => loadSaveData());
  const [screen, setScreen] = useState<ScreenState>('menu');
  const [inGameModal, setInGameModal] = useState<
    'none' | 'pause' | 'shop' | 'settings' | 'howtoplay'
  >('none');
  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [gameOverStats, setGameOverStats] = useState<GameOverStats | null>(null);
  const [runRequest, setRunRequest] = useState<{ mode: 'new' | 'continue'; id: number } | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<IslandSurvivalEngine | null>(null);
  const saveDataRef = useRef<SaveData>(saveData);
  const screenRef = useRef<ScreenState>(screen);
  const inGameModalRef = useRef(inGameModal);

  saveDataRef.current = saveData;
  screenRef.current = screen;
  inGameModalRef.current = inGameModal;

  const isPlayingSession = screen === 'playing' || screen === 'gameover';
  const lang = saveData.settings.language;
  const txt = t(lang);
  const isFa = lang === 'fa';

  // Sync audio volumes on load and settings change
  useEffect(() => {
    soundStudio.updateSettings(saveData.settings);
    if (engineRef.current) {
      engineRef.current.syncSaveData(saveData);
    }
  }, [saveData]);

  // Unlock Web Audio cleanly on very first interaction anywhere
  useEffect(() => {
    const unlockOnce = () => {
      soundStudio.unlock();
      if (screenRef.current === 'menu') {
        soundStudio.setMusicMode('menu');
        soundStudio.updateAmbienceSpatial(80, false, false);
      }
      window.removeEventListener('pointerdown', unlockOnce);
      window.removeEventListener('keydown', unlockOnce);
    };
    window.addEventListener('pointerdown', unlockOnce);
    window.addEventListener('keydown', unlockOnce);
    return () => {
      window.removeEventListener('pointerdown', unlockOnce);
      window.removeEventListener('keydown', unlockOnce);
    };
  }, []);

  // Mutate and persist SaveData safely
  const updateSave = useCallback((mutator: (prev: SaveData) => SaveData) => {
    setSaveData((prev) => {
      const next = mutator(prev);
      persistSaveData(next);
      return next;
    });
  }, []);

  // Ensure Engine instance exists when canvas is mounted
  const ensureEngine = useCallback((): IslandSurvivalEngine | null => {
    if (engineRef.current) return engineRef.current;
    if (!canvasRef.current) return null;

    const eng = new IslandSurvivalEngine(canvasRef.current, saveDataRef.current, {
      onHudUpdate: (snapshot) => setHud(snapshot),
      onSaveProgress: (mutator) => updateSave(mutator),
      onGameOver: (stats) => {
        setGameOverStats(stats);
        setInGameModal('none');
        setScreen('gameover');
      },
      onToggleShop: () => {
        if (screenRef.current !== 'playing') return;
        if (inGameModalRef.current === 'shop') {
          setInGameModal('none');
          engineRef.current?.setPaused(false);
        } else {
          setInGameModal('shop');
          engineRef.current?.setPaused(true);
        }
      },
      onTogglePause: () => {
        if (screenRef.current !== 'playing') return;
        if (inGameModalRef.current === 'none') {
          setInGameModal('pause');
          engineRef.current?.setPaused(true);
        } else {
          setInGameModal('none');
          engineRef.current?.setPaused(false);
        }
      },
    });
    engineRef.current = eng;
    return eng;
  }, [updateSave]);

  // Clean up engine on unmount
  useEffect(() => {
    return () => {
      engineRef.current?.destroy();
      engineRef.current = null;
      soundStudio.setMusicMode('none');
    };
  }, []);

  // Deterministically boot or restart the engine right after React commits the <canvas>
  useEffect(() => {
    if (!runRequest || screen !== 'playing') return;
    const eng = ensureEngine();
    if (!eng) return;
    if (runRequest.mode === 'continue') {
      eng.resumeSavedRun(saveDataRef.current);
    } else {
      eng.startNewRun(saveDataRef.current);
    }
  }, [runRequest, screen, ensureEngine]);

  // ======================================================
  // GAME LAUNCH & NAVIGATION HANDLERS
  // ======================================================
  const startFreshRun = () => {
    soundStudio.unlock();
    setGameOverStats(null);
    setInGameModal('none');
    setScreen('playing');
    setRunRequest({ mode: 'new', id: Date.now() });
  };

  const continueSavedRun = () => {
    if (!saveData.activeRun) return;
    soundStudio.unlock();
    setGameOverStats(null);
    setInGameModal('none');
    setScreen('playing');
    setRunRequest({ mode: 'continue', id: Date.now() });
  };

  const saveAndReturnToMenu = () => {
    const eng = engineRef.current;
    if (eng && screen === 'playing') {
      const snapshot = eng.getActiveRunSnapshot();
      updateSave((prev) => ({
        ...prev,
        activeRun: snapshot,
      }));
      eng.stop();
      eng.destroy();
      engineRef.current = null;
    }
    setInGameModal('none');
    setHud(null);
    setGameOverStats(null);
    setScreen('menu');
    soundStudio.setMusicMode('menu');
    soundStudio.updateAmbienceSpatial(80, false, false);
  };

  const handleExitApp = () => {
    soundStudio.setMusicMode('none');
    persistSaveData(saveData);
    setScreen('exit');
  };

  // ======================================================
  // WEAPON SHOP & CHARACTER HANDLERS
  // ======================================================
  const handleUnlockWeapon = (id: WeaponId) => {
    const def = WEAPONS[id];
    if (saveData.coins < def.cost || saveData.unlockedWeapons.includes(id)) return;
    soundStudio.unlock();
    soundStudio.playPickup('buy');
    updateSave((prev) => ({
      ...prev,
      coins: prev.coins - def.cost,
      unlockedWeapons: [...prev.unlockedWeapons, id],
    }));
    if (engineRef.current && screen === 'playing') {
      setTimeout(() => engineRef.current?.equipWeapon(id), 20);
    }
  };

  const handleUpgradeWeapon = (id: WeaponId) => {
    const curLv = saveData.weaponLevels[id] || 1;
    if (curLv >= 5) return;
    const cost = getWeaponUpgradeCost(id, curLv);
    if (saveData.coins < cost) return;
    soundStudio.unlock();
    soundStudio.playPickup('buy');
    updateSave((prev) => ({
      ...prev,
      coins: prev.coins - cost,
      weaponLevels: {
        ...prev.weaponLevels,
        [id]: curLv + 1,
      },
    }));
  };

  const handleBuyAmmo = (id: WeaponId) => {
    const def = WEAPONS[id];
    if (def.infiniteReserve || saveData.coins < def.ammoPackCost) return;
    soundStudio.unlock();
    soundStudio.playPickup('ammo');
    updateSave((prev) => ({ ...prev, coins: prev.coins - def.ammoPackCost }));
    engineRef.current?.grantShopAmmo(id, def.ammoPackAmount);
  };

  const handleBuyGrenade = () => {
    if (saveData.coins < GRENADE_CONFIG.cost) return;
    if (!engineRef.current?.grantShopGrenade(1)) return;
    soundStudio.unlock();
    soundStudio.playPickup('buy');
    updateSave((prev) => ({ ...prev, coins: prev.coins - GRENADE_CONFIG.cost }));
  };

  const handleSelectCharacter = (id: CharacterId) => {
    if (!saveData.unlockedCharacters.includes(id)) return;
    soundStudio.unlock();
    soundStudio.playPickup('ammo');
    updateSave((prev) => ({ ...prev, selectedCharacter: id }));
  };

  const handleUnlockCharacter = (id: CharacterId) => {
    const ch = CHARACTERS[id];
    if (saveData.coins < ch.cost || saveData.unlockedCharacters.includes(id)) return;
    soundStudio.unlock();
    soundStudio.playPickup('buy');
    updateSave((prev) => ({
      ...prev,
      coins: prev.coins - ch.cost,
      unlockedCharacters: [...prev.unlockedCharacters, id],
      selectedCharacter: id,
    }));
  };

  const handleUpdateSettings = (updated: GameSettings) => {
    soundStudio.unlock();
    updateSave((prev) => ({ ...prev, settings: updated }));
  };

  const handleToggleLanguage = (newLang: Language) => {
    soundStudio.unlock();
    updateSave((prev) => ({
      ...prev,
      settings: { ...prev.settings, language: newLang },
    }));
  };

  const handleResetSave = () => {
    const fresh = resetAllSaveData();
    setSaveData(fresh);
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="relative w-screen h-[100dvh] overflow-hidden bg-[#090e12] select-none">
      {/* Live Animated Zombie Island Backdrop when in Main Menu / Modals / Exit */}
      {!isPlayingSession && <MenuBackground />}

      {/* Subtle Retro Scanlines Overlay */}
      <div className="fixed inset-0 z-[5] pixel-scanlines opacity-30" />

      {/* ======================================================
          MAIN MENU SCREEN
          ====================================================== */}
      {screen === 'menu' && (
        <MainMenu
          saveData={saveData}
          onPlay={startFreshRun}
          onContinue={continueSavedRun}
          onOpenShop={() => {
            soundStudio.unlock();
            setScreen('shop');
          }}
          onOpenCharacter={() => {
            soundStudio.unlock();
            setScreen('character');
          }}
          onOpenSettings={() => {
            soundStudio.unlock();
            setScreen('settings');
          }}
          onOpenHowToPlay={() => {
            soundStudio.unlock();
            setScreen('howtoplay');
          }}
          onExit={handleExitApp}
          onToggleLanguage={handleToggleLanguage}
        />
      )}

      {/* Menu Sub-Screens */}
      {screen === 'shop' && (
        <WeaponShopModal
          saveData={saveData}
          inGame={false}
          onUnlockWeapon={handleUnlockWeapon}
          onUpgradeWeapon={handleUpgradeWeapon}
          onClose={() => setScreen('menu')}
        />
      )}

      {screen === 'character' && (
        <CharacterModal
          saveData={saveData}
          onSelectCharacter={handleSelectCharacter}
          onUnlockCharacter={handleUnlockCharacter}
          onClose={() => setScreen('menu')}
        />
      )}

      {screen === 'settings' && (
        <SettingsModal
          settings={saveData.settings}
          onChange={handleUpdateSettings}
          onResetSave={handleResetSave}
          onClose={() => setScreen('menu')}
        />
      )}

      {screen === 'howtoplay' && (
        <HowToPlayModal language={lang} onClose={() => setScreen('menu')} />
      )}

      {/* ======================================================
          EXIT / SURVIVOR CAMP STAND-BY SCREEN
          ====================================================== */}
      {screen === 'exit' && (
        <div className="relative z-20 w-full h-full flex items-center justify-center p-4">
          <div
            dir={isFa ? 'rtl' : 'ltr'}
            className="pixel-panel max-w-md w-full p-6 text-center space-y-4"
          >
            <div className="flex justify-center">
              <div className="w-20 h-24 bg-[#091014] border-2 border-emerald-800/80 flex items-center justify-center">
                <PixelSpritePreview
                  target={{ kind: 'character', id: saveData.selectedCharacter }}
                  scale={3}
                />
              </div>
            </div>
            <h2 className="font-pixel text-sm sm:text-base text-amber-300">{txt.exitTitle}</h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{txt.exitMessage}</p>

            <div className="grid grid-cols-3 gap-2 text-center bg-[#0a1115] border border-slate-800 p-2.5 text-xs">
              <div>
                <div className="text-slate-400 text-[10px]">{txt.bestWave}</div>
                <div className="font-pixel-ui text-emerald-300 font-bold">{saveData.bestWave}</div>
              </div>
              <div>
                <div className="text-slate-400 text-[10px]">{txt.totalKills}</div>
                <div className="font-pixel-ui text-red-300 font-bold">{saveData.totalKills}</div>
              </div>
              <div>
                <div className="text-slate-400 text-[10px]">{txt.coins}</div>
                <div className="font-pixel-ui text-amber-300 font-bold">{saveData.coins}</div>
              </div>
            </div>

            <button
              onClick={() => {
                soundStudio.unlock();
                soundStudio.setMusicMode('menu');
                setScreen('menu');
              }}
              className="w-full pixel-btn pixel-btn-primary py-2.5 text-xs sm:text-sm font-bold text-amber-100 cursor-pointer"
            >
              ▶ {txt.returnToGame}
            </button>
          </div>
        </div>
      )}

      {/* ======================================================
          ACTIVE GAMEPLAY CANVAS & TACTICAL HUD
          ====================================================== */}
      {isPlayingSession && (
        <div className="relative w-full h-full">
          <canvas
            ref={canvasRef}
            className="block w-full h-full cursor-crosshair"
          />

          {hud && screen === 'playing' && (
            <GameHUD
              hud={hud}
              language={lang}
              touchMode={saveData.settings.touchMode}
              onSwitchWeapon={(id) => engineRef.current?.equipWeapon(id)}
              onCycleWeapon={(dir) => engineRef.current?.cycleWeapon(dir)}
              onReload={() => engineRef.current?.triggerReload()}
              onThrowGrenade={() => engineRef.current?.triggerGrenade()}
              onOpenShop={() => {
                setInGameModal('shop');
                engineRef.current?.setPaused(true);
              }}
              onPause={() => {
                setInGameModal('pause');
                engineRef.current?.setPaused(true);
              }}
              onSkipIntermission={() => engineRef.current?.skipIntermission()}
              onOpenCrate={() => engineRef.current?.openNearbyCrate()}
              onTouchMove={(x, y, sprint) => engineRef.current?.setTouchMove(x, y, sprint)}
              onTouchAim={(x, y, active, firing) =>
                engineRef.current?.setTouchAim(x, y, active, firing)
              }
              onTouchFireButton={(pressed) => engineRef.current?.setTouchFireButton(pressed)}
            />
          )}

          {/* In-Game Pause Menu */}
          {screen === 'playing' && inGameModal === 'pause' && (
            <div className="fixed inset-0 z-40 bg-black/70 backdrop-blur-[2px] flex items-center justify-center p-4">
              <div className="pixel-panel w-full max-w-sm p-5 space-y-3 text-center">
                <h2 className="font-pixel text-base text-amber-300">
                  {txt.pause}
                </h2>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => {
                      setInGameModal('none');
                      engineRef.current?.setPaused(false);
                    }}
                    className="pixel-btn pixel-btn-primary py-2.5 text-xs sm:text-sm font-bold text-white cursor-pointer"
                  >
                    ▶ {txt.resume}
                  </button>
                  <button
                    onClick={() => setInGameModal('shop')}
                    className="pixel-btn pixel-btn-gold py-2 text-xs font-bold text-amber-100 cursor-pointer"
                  >
                    🛒 {txt.weaponShop}
                  </button>
                  <button
                    onClick={() => setInGameModal('settings')}
                    className="pixel-btn py-2 text-xs font-bold text-slate-200 cursor-pointer"
                  >
                    ⚙ {txt.settings}
                  </button>
                  <button
                    onClick={() => setInGameModal('howtoplay')}
                    className="pixel-btn py-2 text-xs font-bold text-cyan-200 cursor-pointer"
                  >
                    📖 {txt.howToPlay}
                  </button>
                  <button
                    onClick={startFreshRun}
                    className="pixel-btn py-2 text-xs font-bold text-orange-300 cursor-pointer"
                  >
                    ↻ {txt.restartRun}
                  </button>
                  <button
                    onClick={saveAndReturnToMenu}
                    className="pixel-btn py-2 text-xs font-bold text-slate-300 cursor-pointer"
                  >
                    💾 {txt.saveAndMenu}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* In-Game Weapon Shop */}
          {screen === 'playing' && inGameModal === 'shop' && (
            <WeaponShopModal
              saveData={saveData}
              inGame={true}
              equippedWeapon={hud?.equippedWeapon}
              grenadeCount={engineRef.current?.getGrenadeCount() ?? hud?.grenades ?? 0}
              onUnlockWeapon={handleUnlockWeapon}
              onUpgradeWeapon={handleUpgradeWeapon}
              onBuyAmmo={handleBuyAmmo}
              onBuyGrenade={handleBuyGrenade}
              onEquipWeapon={(id) => engineRef.current?.equipWeapon(id)}
              onClose={() => {
                setInGameModal('none');
                engineRef.current?.setPaused(false);
              }}
            />
          )}

          {/* In-Game Settings */}
          {screen === 'playing' && inGameModal === 'settings' && (
            <SettingsModal
              settings={saveData.settings}
              onChange={handleUpdateSettings}
              onResetSave={handleResetSave}
              onClose={() => setInGameModal('pause')}
            />
          )}

          {/* In-Game How To Play */}
          {screen === 'playing' && inGameModal === 'howtoplay' && (
            <HowToPlayModal language={lang} onClose={() => setInGameModal('pause')} />
          )}

          {/* Game Over Overlay */}
          {screen === 'gameover' && gameOverStats && (
            <div className="fixed inset-0 z-40 bg-red-950/65 backdrop-blur-[3px] flex items-center justify-center p-4">
              <div
                dir={isFa ? 'rtl' : 'ltr'}
                className="pixel-panel border-red-600 max-w-md w-full p-5 space-y-4 text-center"
              >
                <div className="font-pixel text-base sm:text-lg text-red-400 drop-shadow-[0_3px_0_#1a0505]">
                  {txt.gameOver}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-[#0b1216] border border-slate-800 p-2.5">
                    <div className="text-slate-400 text-[11px]">{txt.survivedTo}</div>
                    <div className="font-pixel text-base text-amber-300 mt-1">
                      {gameOverStats.wave}
                    </div>
                  </div>
                  <div className="bg-[#0b1216] border border-slate-800 p-2.5">
                    <div className="text-slate-400 text-[11px]">{txt.killsThisRun}</div>
                    <div className="font-pixel text-base text-red-400 mt-1">
                      {gameOverStats.kills}
                    </div>
                  </div>
                  <div className="bg-[#0b1216] border border-slate-800 p-2.5">
                    <div className="text-slate-400 text-[11px]">{txt.scoreEarned}</div>
                    <div className="font-pixel-ui text-sm text-emerald-300 font-bold mt-1">
                      {gameOverStats.score}
                    </div>
                  </div>
                  <div className="bg-[#0b1216] border border-slate-800 p-2.5">
                    <div className="text-slate-400 text-[11px]">
                      {isFa ? 'مدت زمان بقا' : 'Time Survived'}
                    </div>
                    <div className="font-pixel-ui text-sm text-cyan-300 font-bold mt-1">
                      {formatTime(gameOverStats.timeSurvived)}
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-2 pt-1">
                  <button
                    onClick={startFreshRun}
                    className="pixel-btn pixel-btn-primary py-2.5 text-xs sm:text-sm font-bold text-white cursor-pointer"
                  >
                    ▶ {txt.tryAgain}
                  </button>
                  <button
                    onClick={() => {
                      engineRef.current?.stop();
                      engineRef.current?.destroy();
                      engineRef.current = null;
                      setHud(null);
                      setGameOverStats(null);
                      setScreen('shop');
                      soundStudio.setMusicMode('menu');
                    }}
                    className="pixel-btn pixel-btn-gold py-2 text-xs font-bold text-amber-100 cursor-pointer"
                  >
                    🛒 {txt.weaponShop}
                  </button>
                  <button
                    onClick={saveAndReturnToMenu}
                    className="pixel-btn py-2 text-xs font-bold text-slate-200 cursor-pointer"
                  >
                    ⌂ {txt.backToMenu}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default App;
