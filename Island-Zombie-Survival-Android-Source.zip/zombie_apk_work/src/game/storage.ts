import { ActiveRunSave, GameSettings, SaveData, WeaponId } from './types';
import { WEAPON_ORDER } from './weapons';

const STORAGE_KEY = 'island_zombie_survival_save_v1';

export function createDefaultSettings(): GameSettings {
  return {
    language: 'fa',
    masterVolume: 0.8,
    sfxVolume: 0.85,
    musicVolume: 0.55,
    ambienceVolume: 0.65,
    touchMode: 'auto',
    quality: 'high',
    screenShake: true,
    showMinimap: true,
  };
}

export function createDefaultSaveData(): SaveData {
  const weaponLevels = {} as Record<WeaponId, number>;
  for (const w of WEAPON_ORDER) {
    weaponLevels[w] = 1;
  }

  return {
    version: 1,
    coins: 60,
    scrap: 0,
    unlockedWeapons: ['pistol'],
    weaponLevels,
    unlockedCharacters: ['marcus'],
    selectedCharacter: 'marcus',
    bestWave: 0,
    bestScore: 0,
    totalKills: 0,
    settings: createDefaultSettings(),
    activeRun: null,
  };
}

export function loadSaveData(): SaveData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultSaveData();
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    const defaults = createDefaultSaveData();

    const weaponLevels = { ...defaults.weaponLevels, ...(parsed.weaponLevels || {}) };
    for (const w of WEAPON_ORDER) {
      if (!weaponLevels[w] || weaponLevels[w] < 1) weaponLevels[w] = 1;
    }

    const unlockedWeapons: WeaponId[] = Array.isArray(parsed.unlockedWeapons)
      ? Array.from(new Set(['pistol', ...parsed.unlockedWeapons])) as WeaponId[]
      : ['pistol'];

    return {
      ...defaults,
      ...parsed,
      weaponLevels,
      unlockedWeapons,
      unlockedCharacters:
        Array.isArray(parsed.unlockedCharacters) && parsed.unlockedCharacters.length > 0
          ? Array.from(new Set(['marcus', ...parsed.unlockedCharacters]))
          : ['marcus'],
      settings: {
        ...defaults.settings,
        ...(parsed.settings || {}),
      },
      activeRun: parsed.activeRun ?? null,
    };
  } catch {
    return createDefaultSaveData();
  }
}

export function persistSaveData(data: SaveData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Ignore storage quota errors gracefully
  }
}

export function saveActiveRun(data: SaveData, run: ActiveRunSave | null): SaveData {
  const updated: SaveData = {
    ...data,
    activeRun: run,
  };
  persistSaveData(updated);
  return updated;
}

export function resetAllSaveData(): SaveData {
  const fresh = createDefaultSaveData();
  persistSaveData(fresh);
  return fresh;
}
