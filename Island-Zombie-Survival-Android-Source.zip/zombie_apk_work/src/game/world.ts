import { Building, Rect, WorldProp, ZoneId } from './types';

export const WORLD_SIZE = 3200;
export const TILE_SIZE = 16;
export const CHUNK_SIZE = 800;
export const CHUNKS_PER_AXIS = WORLD_SIZE / CHUNK_SIZE; // 4x4 = 16 chunks

export interface ToxicPool {
  x: number;
  y: number;
  radius: number;
}

export interface IslandWorld {
  width: number;
  height: number;
  buildings: Building[];
  props: WorldProp[];
  toxicPools: ToxicPool[];
  staticWalls: Rect[];
  terrainChunks: HTMLCanvasElement[][];
  minimapCanvas: HTMLCanvasElement;
  spawnPoint: { x: number; y: number };
  getZoneAt: (x: number, y: number) => ZoneId;
  getTerrainKindAt: (x: number, y: number) => 'deep_water' | 'shallow_water' | 'sand' | 'grass' | 'concrete' | 'stone' | 'virus' | 'wood';
  isWalkable: (x: number, y: number) => boolean;
  isInCaveArea: (x: number, y: number) => boolean;
  getDistanceToOcean: (x: number, y: number) => number;
}

// Deterministic fast PRNG for rich organic island detail
function createRng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function hash2D(x: number, y: number): number {
  const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123;
  return n - Math.floor(n);
}

// Organic island coastline radius function centered at (1600, 1600)
export function getCoastRadiusAtAngle(angle: number): number {
  return (
    1260 +
    Math.sin(angle * 3 + 0.5) * 75 +
    Math.cos(angle * 5 - 0.8) * 48 +
    Math.sin(angle * 7 + 1.4) * 28
  );
}

export function getSignedCoastDistance(x: number, y: number): number {
  const cx = WORLD_SIZE / 2;
  const cy = WORLD_SIZE / 2;
  const dx = x - cx;
  const dy = y - cy;
  const dist = Math.hypot(dx, dy);
  const angle = Math.atan2(dy, dx);
  return getCoastRadiusAtAngle(angle) - dist; // > 0 inland, <= 0 ocean
}

export function queryZoneAt(x: number, y: number): ZoneId {
  const coastDist = getSignedCoastDistance(x, y);
  if (coastDist < 185) return 'beach';

  // Specific handcrafted zone rectangles / polygons on the island
  if (x >= 760 && x <= 1360 && y >= 680 && y <= 1250) return 'hospital';
  if (x >= 1390 && x <= 2030 && y >= 580 && y <= 1200) return 'military';
  if (x >= 2040 && x <= 2580 && y >= 760 && y <= 1350) return 'ammo_depot';
  if (x >= 2090 && x <= 2700 && y >= 1360 && y <= 1950) return 'caves';
  if (x >= 1910 && x <= 2580 && y >= 1960 && y <= 2550) return 'virus_zone';
  if (x >= 620 && x <= 1260 && y >= 1270 && y <= 2040) return 'houses';

  return 'jungle';
}

function createBuilding(
  id: string,
  zone: ZoneId,
  x: number,
  y: number,
  w: number,
  h: number,
  doorSide: 'south' | 'north' | 'east' | 'west',
  doorWidth: number,
  floorType: Building['floorType'],
  roofColor: string,
  roofTrim: string,
  opts?: { labelEn?: string; labelFa?: string; hasCross?: boolean; hasHazard?: boolean }
): Building {
  const wt = 14;
  const walls: Rect[] = [];

  const addSplitWall = (
    wx: number,
    wy: number,
    ww: number,
    wh: number,
    horizontal: boolean,
    hasDoor: boolean
  ) => {
    if (!hasDoor) {
      walls.push({ x: wx, y: wy, w: ww, h: wh });
      return;
    }
    if (horizontal) {
      const seg = Math.floor((ww - doorWidth) / 2);
      walls.push({ x: wx, y: wy, w: seg, h: wh });
      walls.push({ x: wx + seg + doorWidth, y: wy, w: ww - seg - doorWidth, h: wh });
    } else {
      const seg = Math.floor((wh - doorWidth) / 2);
      walls.push({ x: wx, y: wy, w: ww, h: seg });
      walls.push({ x: wx, y: wy + seg + doorWidth, w: ww, h: wh - seg - doorWidth });
    }
  };

  addSplitWall(x, y, w, wt, true, doorSide === 'north');
  addSplitWall(x, y + h - wt, w, wt, true, doorSide === 'south');
  addSplitWall(x, y + wt, wt, h - wt * 2, false, doorSide === 'west');
  addSplitWall(x + w - wt, y + wt, wt, h - wt * 2, false, doorSide === 'east');

  return {
    id,
    zone,
    x,
    y,
    w,
    h,
    wallThickness: wt,
    doorSide,
    doorWidth,
    roofColor,
    roofTrim,
    floorType,
    walls,
    ...opts,
  };
}

function pointNearRect(px: number, py: number, r: Rect, pad: number): boolean {
  return (
    px >= r.x - pad &&
    px <= r.x + r.w + pad &&
    py >= r.y - pad &&
    py <= r.y + r.h + pad
  );
}

// Check if a point lies on one of the dirt roads connecting island landmarks
function isOnDirtRoad(x: number, y: number): boolean {
  const segments: [number, number, number, number, number][] = [
    // South Beach Pier -> Central Jungle Crossroads
    [1600, 2740, 1600, 1520, 34],
    // Central Crossroads -> Military Base
    [1600, 1520, 1700, 1020, 30],
    // Crossroads -> Abandoned Houses (West)
    [1600, 1620, 960, 1620, 28],
    // Houses -> Hospital (North-West)
    [980, 1620, 1060, 1060, 26],
    // Military Base -> Hospital
    [1660, 1020, 1090, 1020, 26],
    // Military Base -> Ammo Depot
    [1720, 1020, 2260, 1060, 26],
    // Crossroads -> Caves (East)
    [1600, 1620, 2240, 1640, 26],
    // Crossroads -> Virus Zone (South-East)
    [1600, 1800, 2180, 2180, 24],
  ];

  for (const [x1, y1, x2, y2, width] of segments) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const lenSq = dx * dx + dy * dy;
    const t = Math.max(0, Math.min(1, ((x - x1) * dx + (y - y1) * dy) / lenSq));
    const px = x1 + t * dx;
    const py = y1 + t * dy;
    const dist = Math.hypot(x - px, y - py);
    if (dist <= width) return true;
  }
  return false;
}

export function generateIslandWorld(): IslandWorld {
  const rng = createRng(20260719);
  const buildings: Building[] = [];
  const props: WorldProp[] = [];
  const toxicPools: ToxicPool[] = [];
  const staticWalls: Rect[] = [];

  // ======================================================
  // 1. HANDCRAFTED LANDMARK BUILDINGS ACROSS THE ISLAND
  // ======================================================
  // Abandoned Village Houses (West)
  buildings.push(
    createBuilding(
      'house_1',
      'houses',
      780,
      1380,
      160,
      128,
      'south',
      48,
      'wood',
      '#6b4832',
      '#472e1f'
    ),
    createBuilding(
      'house_2',
      'houses',
      1020,
      1410,
      152,
      120,
      'south',
      48,
      'wood',
      '#594133',
      '#3b2a20'
    ),
    createBuilding(
      'house_3',
      'houses',
      760,
      1720,
      176,
      136,
      'north',
      50,
      'wood',
      '#633f2c',
      '#3d2418'
    ),
    createBuilding(
      'house_4',
      'houses',
      1010,
      1760,
      148,
      124,
      'west',
      46,
      'wood',
      '#524034',
      '#362921'
    )
  );

  // Abandoned Hospital (North-West)
  buildings.push(
    createBuilding(
      'hospital_main',
      'hospital',
      880,
      820,
      320,
      208,
      'south',
      64,
      'hospital',
      '#b8c7c4',
      '#7b8f8c',
      { labelEn: 'HOSPITAL', labelFa: 'بیمارستان', hasCross: true }
    ),
    createBuilding(
      'hospital_wing',
      'hospital',
      1215,
      860,
      115,
      140,
      'south',
      46,
      'hospital',
      '#aab8b6',
      '#6d7f7d'
    )
  );

  // Old Military Base Command Bunker & Barracks (North)
  buildings.push(
    createBuilding(
      'mil_command',
      'military',
      1520,
      680,
      230,
      150,
      'south',
      58,
      'concrete',
      '#535e4f',
      '#353d32',
      { labelEn: 'MILITARY HQ', labelFa: 'پایگاه نظامی' }
    ),
    createBuilding(
      'mil_armory',
      'military',
      1800,
      710,
      165,
      135,
      'west',
      52,
      'concrete',
      '#4a5448',
      '#2e362c'
    )
  );

  // Ammo Depot Reinforced Bunkers (North-East)
  buildings.push(
    createBuilding(
      'depot_main',
      'ammo_depot',
      2160,
      880,
      230,
      165,
      'south',
      58,
      'bunker',
      '#5c5743',
      '#3a372a',
      { labelEn: 'AMMO DEPOT', labelFa: 'انبار مهمات', hasHazard: true }
    ),
    createBuilding(
      'depot_shed',
      'ammo_depot',
      2140,
      1130,
      140,
      110,
      'east',
      46,
      'bunker',
      '#524d3b',
      '#333025'
    )
  );

  // Cave Enclosure Rock Chamber Walls (East) — wide cavern opening facing West!
  buildings.push(
    createBuilding(
      'cave_chamber',
      'caves',
      2280,
      1480,
      300,
      280,
      'west',
      92,
      'stone',
      '#333845',
      '#20242e',
      { labelEn: 'CAVERN', labelFa: 'غار تاریک' }
    )
  );

  for (const b of buildings) {
    staticWalls.push(...b.walls);
  }

  let propCounter = 0;
  const addProp = (
    type: WorldProp['type'],
    x: number,
    y: number,
    radius: number,
    solid: boolean,
    blocksBullets: boolean,
    variant = 0,
    hp?: number
  ) => {
    props.push({
      id: `prop_${propCounter++}`,
      type,
      x,
      y,
      radius,
      solid,
      blocksBullets,
      variant,
      hp,
      maxHp: hp,
      zone: queryZoneAt(x, y),
    });
  };

  // ======================================================
  // 2. ZONE-SPECIFIC HANDCRAFTED PROPS & INTERIORS
  // ======================================================

  // Hospital interior beds + entrance lanterns + medical crates
  addProp('bed', 925, 868, 14, true, false);
  addProp('bed', 980, 868, 14, true, false);
  addProp('bed', 1105, 868, 14, true, false);
  addProp('bed', 1155, 868, 14, true, false);
  addProp('crate', 1040, 860, 12, true, true, 0, 35);
  addProp('crate', 1270, 910, 12, true, true, 0, 35);
  addProp('lantern', 985, 1042, 6, true, false);
  addProp('lantern', 1095, 1042, 6, true, false);

  // Abandoned Houses crates & warm lanterns
  addProp('crate', 830, 1435, 12, true, true, 0, 35);
  addProp('crate', 1095, 1455, 12, true, true, 0, 35);
  addProp('crate', 840, 1795, 12, true, true, 0, 35);
  addProp('crate', 1095, 1815, 12, true, true, 0, 35);
  addProp('lantern', 960, 1545, 6, true, false);
  addProp('lantern', 955, 1690, 6, true, false);
  addProp('barrel', 1185, 1665, 10, true, true, 0, 28);

  // Military Base sandbags, jeeps, explosive barrels, crates, lanterns
  addProp('sandbag', 1525, 1070, 15, true, false);
  addProp('sandbag', 1570, 1070, 15, true, false);
  addProp('sandbag', 1785, 1070, 15, true, false);
  addProp('sandbag', 1830, 1070, 15, true, false);
  addProp('sandbag', 1465, 920, 15, true, false);
  addProp('jeep', 1500, 965, 22, true, true);
  addProp('jeep', 1875, 950, 22, true, true);
  addProp('barrel', 1605, 875, 10, true, true, 0, 28);
  addProp('barrel', 1760, 910, 10, true, true, 0, 28);
  addProp('barrel', 1850, 1030, 10, true, true, 0, 28);
  addProp('crate', 1575, 745, 12, true, true, 0, 40);
  addProp('crate', 1690, 745, 12, true, true, 0, 40);
  addProp('crate', 1895, 775, 12, true, true, 0, 40);
  addProp('lantern', 1580, 845, 6, true, false);
  addProp('lantern', 1705, 845, 6, true, false);

  // Ammo Depot crates, barrels & hazard lanterns
  addProp('crate', 2215, 940, 12, true, true, 0, 40);
  addProp('crate', 2275, 940, 12, true, true, 0, 40);
  addProp('crate', 2335, 940, 12, true, true, 0, 40);
  addProp('crate', 2195, 1185, 12, true, true, 0, 40);
  addProp('barrel', 2125, 1020, 10, true, true, 0, 28);
  addProp('barrel', 2380, 1085, 10, true, true, 0, 28);
  addProp('barrel', 2320, 1185, 10, true, true, 0, 28);
  addProp('barrel', 2435, 995, 10, true, true, 0, 28);
  addProp('lantern', 2225, 1065, 6, true, false);
  addProp('lantern', 2330, 1065, 6, true, false);

  // Dark Caves crystals, stalagmites & gold crates
  addProp('crystal', 2345, 1540, 10, true, true);
  addProp('crystal', 2515, 1560, 10, true, true);
  addProp('crystal', 2495, 1705, 10, true, true);
  addProp('crystal', 2350, 1710, 10, true, true);
  addProp('crystal', 2210, 1525, 10, true, true);
  addProp('crystal', 2215, 1730, 10, true, true);
  addProp('stalagmite', 2410, 1585, 11, true, true);
  addProp('stalagmite', 2450, 1665, 11, true, true);
  addProp('crate', 2520, 1625, 12, true, true, 0, 45);
  addProp('crate', 2450, 1530, 12, true, true, 0, 45);

  // Virus Contaminated Zone toxic pools, bio signs, dead trees, barrels & rare crates
  const poolCoords: [number, number, number][] = [
    [2085, 2110, 52],
    [2260, 2225, 62],
    [2140, 2365, 48],
    [2375, 2095, 46],
    [2395, 2320, 54],
  ];
  for (const [px, py, pr] of poolCoords) {
    toxicPools.push({ x: px, y: py, radius: pr });
  }
  addProp('bio_sign', 1975, 2045, 8, true, false);
  addProp('bio_sign', 2015, 2220, 8, true, false);
  addProp('bio_sign', 2215, 2015, 8, true, false);
  addProp('barrel', 2170, 2175, 10, true, true, 0, 28);
  addProp('barrel', 2310, 2145, 10, true, true, 0, 28);
  addProp('crate', 2205, 2090, 12, true, true, 0, 45);
  addProp('crate', 2315, 2275, 12, true, true, 0, 45);

  // Beach shipwrecks & landing supplies near South Beach
  addProp('boat_wreck', 1430, 2720, 20, true, true);
  addProp('boat_wreck', 2040, 2650, 20, true, true);
  addProp('boat_wreck', 515, 1980, 20, true, true);
  addProp('crate', 1525, 2150, 12, true, true, 0, 30);
  addProp('crate', 1675, 2140, 12, true, true, 0, 30);
  addProp('barrel', 1550, 1890, 10, true, true, 0, 28);
  addProp('barrel', 1680, 1720, 10, true, true, 0, 28);
  addProp('lantern', 1548, 2050, 6, true, false);
  addProp('lantern', 1652, 2050, 6, true, false);

  // ======================================================
  // 3. ORGANIC PROCEDURAL FOLIAGE, ROCKS & NATURAL COVER
  // ======================================================
  const canPlaceProp = (x: number, y: number, minDist: number): boolean => {
    // Keep player spawn clearing open
    if (Math.hypot(x - 1600, y - 2060) < 130) return false;
    // Keep helipad clear
    if (Math.hypot(x - 1680, y - 960) < 95) return false;
    // Keep roads navigable
    if (isOnDirtRoad(x, y)) return false;
    // Keep away from buildings & doorways
    for (const b of buildings) {
      if (pointNearRect(x, y, b, 34)) return false;
    }
    // Keep away from toxic pools
    for (const tp of toxicPools) {
      if (Math.hypot(x - tp.x, y - tp.y) < tp.radius + 18) return false;
    }
    // Keep spaced from existing props
    for (const p of props) {
      if (Math.hypot(x - p.x, y - p.y) < minDist + p.radius) return false;
    }
    return true;
  };

  for (let i = 0; i < 620; i++) {
    const x = 220 + rng() * (WORLD_SIZE - 440);
    const y = 220 + rng() * (WORLD_SIZE - 440);
    const coastDist = getSignedCoastDistance(x, y);
    if (coastDist < 48) continue;

    const zone = queryZoneAt(x, y);
    if (!canPlaceProp(x, y, 28)) continue;

    if (zone === 'beach') {
      if (coastDist > 75 && rng() < 0.6) {
        addProp('palm', x, y, 11, true, true, rng() < 0.5 ? 0 : 1);
      } else if (rng() < 0.25) {
        addProp('rock', x, y, 12, true, true, rng() < 0.5 ? 0 : 1);
      }
    } else if (zone === 'jungle') {
      const r = rng();
      if (r < 0.36) {
        addProp('jungle_tree', x, y, 13, true, true, rng() < 0.5 ? 0 : 1);
      } else if (r < 0.62) {
        addProp('palm', x, y, 11, true, true, rng() < 0.5 ? 0 : 1);
      } else if (r < 0.78) {
        addProp('bush', x, y, 9, false, false, rng() < 0.5 ? 0 : 1);
      } else if (r < 0.91) {
        addProp('fern', x, y, 6, false, false);
      } else {
        addProp('rock', x, y, 12, true, true, rng() < 0.5 ? 0 : 1);
      }
    } else if (zone === 'houses') {
      const r = rng();
      if (r < 0.35) addProp('palm', x, y, 11, true, true, rng() < 0.5 ? 0 : 1);
      else if (r < 0.65) addProp('bush', x, y, 9, false, false, rng() < 0.5 ? 0 : 1);
      else if (r < 0.8) addProp('fern', x, y, 6, false, false);
    } else if (zone === 'hospital') {
      if (rng() < 0.35) addProp('bush', x, y, 9, false, false, 0);
      else if (rng() < 0.55) addProp('jungle_tree', x, y, 13, true, true, 0);
    } else if (zone === 'military') {
      if (rng() < 0.22) addProp('rock', x, y, 11, true, true, 1);
    } else if (zone === 'ammo_depot') {
      if (rng() < 0.22) addProp('rock', x, y, 11, true, true, 0);
      else if (rng() < 0.34) addProp('bush', x, y, 9, false, false, 1);
    } else if (zone === 'caves') {
      const r = rng();
      if (r < 0.45) addProp('stalagmite', x, y, 11, true, true);
      else if (r < 0.78) addProp('rock', x, y, 12, true, true, rng() < 0.5 ? 0 : 1);
      else addProp('crystal', x, y, 10, true, true);
    } else if (zone === 'virus_zone') {
      const r = rng();
      if (r < 0.55) addProp('dead_tree', x, y, 11, true, true);
      else if (r < 0.8) addProp('rock', x, y, 12, true, true, 1);
    }
  }

  // Scatter a few extra loot crates across the jungle and beach
  for (let i = 0; i < 12; i++) {
    const x = 450 + rng() * (WORLD_SIZE - 900);
    const y = 450 + rng() * (WORLD_SIZE - 900);
    if (getSignedCoastDistance(x, y) > 95 && canPlaceProp(x, y, 36)) {
      addProp('crate', x, y, 12, true, true, 0, 35);
    }
  }

  // ======================================================
  // 4. PRE-RENDER CHUNKED PIXEL-ART TERRAIN (4x4 = 16 CHUNKS)
  // ======================================================
  const terrainChunks: HTMLCanvasElement[][] = [];
  for (let cy = 0; cy < CHUNKS_PER_AXIS; cy++) {
    const row: HTMLCanvasElement[] = [];
    for (let cx = 0; cx < CHUNKS_PER_AXIS; cx++) {
      const canvas = document.createElement('canvas');
      canvas.width = CHUNK_SIZE;
      canvas.height = CHUNK_SIZE;
      const ctx = canvas.getContext('2d')!;
      ctx.imageSmoothingEnabled = false;
      renderTerrainChunk(ctx, cx * CHUNK_SIZE, cy * CHUNK_SIZE, buildings, toxicPools);
      row.push(canvas);
    }
    terrainChunks.push(row);
  }

  // ======================================================
  // 5. PRE-RENDER TACTICAL MINIMAP CANVAS (160x160)
  // ======================================================
  const minimapCanvas = buildMinimapCanvas(buildings, toxicPools);

  const getTerrainKindAt = (x: number, y: number) => {
    const cd = getSignedCoastDistance(x, y);
    if (cd < -42) return 'deep_water';
    if (cd < 12) return 'shallow_water';
    if (cd < 175) return 'sand';
    const z = queryZoneAt(x, y);
    if (z === 'military' || z === 'ammo_depot' || z === 'hospital') return 'concrete';
    if (z === 'caves') return 'stone';
    if (z === 'virus_zone') return 'virus';
    for (const b of buildings) {
      if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) {
        return b.floorType === 'wood' ? 'wood' : 'concrete';
      }
    }
    return 'grass';
  };

  return {
    width: WORLD_SIZE,
    height: WORLD_SIZE,
    buildings,
    props,
    toxicPools,
    staticWalls,
    terrainChunks,
    minimapCanvas,
    spawnPoint: { x: 1600, y: 2060 },
    getZoneAt: queryZoneAt,
    getTerrainKindAt,
    isWalkable: (x: number, y: number) => getSignedCoastDistance(x, y) > -34,
    isInCaveArea: (x: number, y: number) => queryZoneAt(x, y) === 'caves',
    getDistanceToOcean: (x: number, y: number) => Math.max(0, getSignedCoastDistance(x, y)),
  };
}

function renderTerrainChunk(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  buildings: Building[],
  toxicPools: ToxicPool[]
) {
  const step = 8; // 8px crisp pixel-art terrain texels
  for (let ly = 0; ly < CHUNK_SIZE; ly += step) {
    const wy = oy + ly;
    for (let lx = 0; lx < CHUNK_SIZE; lx += step) {
      const wx = ox + lx;
      const n = hash2D(wx >> 3, wy >> 3);
      const n2 = hash2D((wx >> 4) + 17, (wy >> 4) + 31);
      const coastDist = getSignedCoastDistance(wx, wy);

      let color = '#134263';
      if (coastDist < -90) {
        color = n < 0.2 ? '#0e3552' : n > 0.85 ? '#164d73' : '#123e5e';
      } else if (coastDist < -32) {
        color = n < 0.25 ? '#1a5f82' : n > 0.8 ? '#23779c' : '#1e6b8f';
      } else if (coastDist < 14) {
        // Turquoise tropical shallows
        color = n < 0.28 ? '#3196ad' : n > 0.8 ? '#4bb3c4' : '#3ca4b8';
      } else if (coastDist < 42) {
        // Wet shoreline sand
        color = n < 0.3 ? '#bda06a' : '#c9ac75';
      } else if (coastDist < 178 + (n2 - 0.5) * 32) {
        // Golden tropical beach sand
        color = n < 0.18 ? '#cfb178' : n > 0.84 ? '#e6cc93' : '#dbc086';
      } else {
        const zone = queryZoneAt(wx, wy);
        if (zone === 'military') {
          // Cracked military asphalt / concrete pad
          color = n < 0.16 ? '#4e5652' : n > 0.86 ? '#677069' : '#5b635e';
        } else if (zone === 'ammo_depot') {
          color = n < 0.18 ? '#575343' : n > 0.84 ? '#6e6a56' : '#635f4d';
        } else if (zone === 'hospital') {
          // Overgrown stone courtyard around hospital
          color = n < 0.2 ? '#596b59' : n > 0.75 ? '#707d73' : '#637367';
        } else if (zone === 'caves') {
          // Dark volcanic slate rock floor
          color = n < 0.22 ? '#343945' : n > 0.84 ? '#4d5466' : '#404654';
        } else if (zone === 'virus_zone') {
          // Blighted sickly dark earth & moss
          color = n < 0.22 ? '#313d26' : n > 0.84 ? '#4a5934' : '#3c4a2d';
        } else if (zone === 'houses') {
          color = n < 0.22 ? '#3f6336' : n > 0.82 ? '#587d44' : '#4a703c';
        } else {
          // Rich dense tropical jungle grass
          color = n < 0.2 ? '#2c5e31' : n > 0.82 ? '#44823d' : '#377036';
        }

        // Dirt roads weaving across interior
        if (isOnDirtRoad(wx, wy) && zone !== 'military') {
          color = n < 0.25 ? '#7d6241' : n > 0.82 ? '#9c7c54' : '#8c6e49';
        }
      }

      ctx.fillStyle = color;
      ctx.fillRect(lx, ly, step, step);

      // Subtle pixel-art micro details (pebbles, blades of grass, cracks, toxic spores)
      if (coastDist > 16 && n > 0.92) {
        if (coastDist < 170) {
          ctx.fillStyle = '#f2e1b6'; // shell speck
          ctx.fillRect(lx + 2, ly + 3, 2, 2);
        } else {
          const z = queryZoneAt(wx, wy);
          if (z === 'jungle' || z === 'houses') {
            ctx.fillStyle = '#60a64b'; // grass tuft
            ctx.fillRect(lx + 2, ly + 2, 2, 4);
            ctx.fillRect(lx + 5, ly + 3, 2, 3);
          } else if (z === 'virus_zone') {
            ctx.fillStyle = '#79d93b'; // bio spore speck
            ctx.fillRect(lx + 3, ly + 3, 2, 2);
          } else if (z === 'military' || z === 'ammo_depot') {
            ctx.fillStyle = '#3a403d'; // tarmac crack
            ctx.fillRect(lx + 1, ly + 4, 5, 1);
          }
        }
      }
    }
  }

  // Draw South Wooden Beach Pier if overlapping this chunk
  const pierX = 1572;
  const pierY = 2760;
  const pierW = 56;
  const pierH = 195;
  if (
    pierX + pierW >= ox &&
    pierX <= ox + CHUNK_SIZE &&
    pierY + pierH >= oy &&
    pierY <= oy + CHUNK_SIZE
  ) {
    const px = pierX - ox;
    const py = pierY - oy;
    ctx.fillStyle = '#1f160f';
    ctx.fillRect(px - 2, py, pierW + 4, pierH);
    for (let y = 0; y < pierH; y += 8) {
      ctx.fillStyle = y % 16 === 0 ? '#855934' : '#734b2b';
      ctx.fillRect(px, py + y, pierW, 6);
      ctx.fillStyle = '#472d18';
      ctx.fillRect(px, py + y + 6, pierW, 2);
    }
    // Pier posts
    ctx.fillStyle = '#3b2513';
    for (let y = 8; y < pierH; y += 36) {
      ctx.fillRect(px - 2, py + y, 8, 8);
      ctx.fillRect(px + pierW - 6, py + y, 8, 8);
    }
  }

  // Draw Military Helipad ("H") at (1680, 960)
  const hx = 1680 - ox;
  const hy = 960 - oy;
  if (hx > -100 && hx < CHUNK_SIZE + 100 && hy > -100 && hy < CHUNK_SIZE + 100) {
    ctx.fillStyle = '#444b47';
    ctx.fillRect(hx - 64, hy - 64, 128, 128);
    ctx.strokeStyle = '#d9b541';
    ctx.lineWidth = 4;
    ctx.strokeRect(hx - 56, hy - 56, 112, 112);
    // Bold pixel H
    ctx.fillStyle = '#d9b541';
    ctx.fillRect(hx - 24, hy - 30, 10, 60);
    ctx.fillRect(hx + 14, hy - 30, 10, 60);
    ctx.fillRect(hx - 24, hy - 5, 48, 10);
  }

  // Draw Hazard Stripes in Ammo Depot yard
  const dx = 2160 - ox;
  const dy = 1052 - oy;
  if (dx > -260 && dx < CHUNK_SIZE + 40 && dy > -40 && dy < CHUNK_SIZE + 40) {
    for (let sx = 0; sx < 230; sx += 16) {
      ctx.fillStyle = (sx / 16) % 2 === 0 ? '#d9a926' : '#1d2021';
      ctx.fillRect(dx + sx, dy, 16, 10);
    }
  }

  // Draw Toxic Biohazard Sludge Pools
  for (const pool of toxicPools) {
    const px = pool.x - ox;
    const py = pool.y - oy;
    if (px + pool.radius < 0 || px - pool.radius > CHUNK_SIZE || py + pool.radius < 0 || py - pool.radius > CHUNK_SIZE) {
      continue;
    }
    const r = pool.radius;
    for (let y = -r; y <= r; y += 4) {
      for (let x = -r; x <= r; x += 4) {
        const d = Math.hypot(x, y);
        const wobble = Math.sin(Math.atan2(y, x) * 5 + pool.x) * 5;
        if (d < r + wobble) {
          if (d < r * 0.45) ctx.fillStyle = '#89ff3b';
          else if (d < r * 0.78) ctx.fillStyle = '#4fb825';
          else ctx.fillStyle = '#2c661c';
          ctx.fillRect(px + x, py + y, 4, 4);
        }
      }
    }
  }

  // Draw Building Interior Floors into terrain chunks
  for (const b of buildings) {
    if (
      b.x + b.w < ox ||
      b.x > ox + CHUNK_SIZE ||
      b.y + b.h < oy ||
      b.y > oy + CHUNK_SIZE
    ) {
      continue;
    }
    const bx = b.x - ox;
    const by = b.y - oy;

    if (b.floorType === 'wood') {
      for (let y = 0; y < b.h; y += 8) {
        ctx.fillStyle = y % 16 === 0 ? '#785437' : '#69482e';
        ctx.fillRect(bx, by + y, b.w, 7);
        ctx.fillStyle = '#472f1d';
        ctx.fillRect(bx, by + y + 7, b.w, 1);
      }
    } else if (b.floorType === 'hospital') {
      for (let y = 0; y < b.h; y += 16) {
        for (let x = 0; x < b.w; x += 16) {
          ctx.fillStyle = ((x + y) / 16) % 2 === 0 ? '#d8e6e3' : '#c6d6d3';
          ctx.fillRect(bx + x, by + y, 16, 16);
        }
      }
      // Red cross tiled in center of hospital floor
      if (b.hasCross) {
        const cx = bx + Math.floor(b.w / 2);
        const cy = by + Math.floor(b.h / 2);
        ctx.fillStyle = '#d93848';
        ctx.fillRect(cx - 8, cy - 26, 16, 52);
        ctx.fillRect(cx - 26, cy - 8, 52, 16);
      }
    } else if (b.floorType === 'concrete' || b.floorType === 'bunker') {
      ctx.fillStyle = b.floorType === 'bunker' ? '#49473d' : '#58615d';
      ctx.fillRect(bx, by, b.w, b.h);
      ctx.fillStyle = 'rgba(0,0,0,0.12)';
      for (let y = 0; y < b.h; y += 24) ctx.fillRect(bx, by + y, b.w, 2);
      for (let x = 0; x < b.w; x += 24) ctx.fillRect(bx + x, by, 2, b.h);
    } else if (b.floorType === 'stone') {
      ctx.fillStyle = '#252933';
      ctx.fillRect(bx, by, b.w, b.h);
      for (let y = 0; y < b.h; y += 16) {
        for (let x = 0; x < b.w; x += 16) {
          if (hash2D(x + b.x, y + b.y) > 0.65) {
            ctx.fillStyle = '#313645';
            ctx.fillRect(bx + x, by + y, 12, 10);
          }
        }
      }
    }
  }
}

function buildMinimapCanvas(buildings: Building[], toxicPools: ToxicPool[]): HTMLCanvasElement {
  const size = 160;
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  const scale = WORLD_SIZE / size;

  for (let py = 0; py < size; py++) {
    for (let px = 0; px < size; px++) {
      const wx = px * scale;
      const wy = py * scale;
      const cd = getSignedCoastDistance(wx, wy);
      if (cd < -35) ctx.fillStyle = '#0e3552';
      else if (cd < 12) ctx.fillStyle = '#2a7f9c';
      else if (cd < 178) ctx.fillStyle = '#d4b87c';
      else {
        const z = queryZoneAt(wx, wy);
        if (z === 'jungle') ctx.fillStyle = '#2f6632';
        else if (z === 'houses') ctx.fillStyle = '#6b5c3e';
        else if (z === 'hospital') ctx.fillStyle = '#9bb5b0';
        else if (z === 'military') ctx.fillStyle = '#5c665d';
        else if (z === 'ammo_depot') ctx.fillStyle = '#7a6f47';
        else if (z === 'caves') ctx.fillStyle = '#3c4252';
        else if (z === 'virus_zone') ctx.fillStyle = '#476929';
        else ctx.fillStyle = '#2f6632';
      }
      ctx.fillRect(px, py, 1, 1);
    }
  }

  // Toxic pools bright dots
  ctx.fillStyle = '#84ff4f';
  for (const tp of toxicPools) {
    ctx.fillRect(Math.round(tp.x / scale) - 2, Math.round(tp.y / scale) - 2, 4, 4);
  }

  // Building footprints
  for (const b of buildings) {
    ctx.fillStyle = b.hasCross ? '#e63946' : b.hasHazard ? '#f5b82e' : '#d6d0c4';
    ctx.fillRect(
      Math.round(b.x / scale),
      Math.round(b.y / scale),
      Math.max(3, Math.round(b.w / scale)),
      Math.max(3, Math.round(b.h / scale))
    );
  }

  return c;
}
