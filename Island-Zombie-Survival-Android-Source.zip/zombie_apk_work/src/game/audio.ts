import { GameSettings, WeaponId, ZombieType } from './types';

type MusicMode = 'none' | 'menu' | 'intermission' | 'combat' | 'boss';

class SoundStudio {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private ambienceGain: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;

  // Ambience nodes
  private oceanGain: GainNode | null = null;
  private jungleGain: GainNode | null = null;
  private ambienceStarted = false;

  // Music scheduler
  private musicMode: MusicMode = 'none';
  private musicTimer: number | null = null;
  private musicStep = 0;

  // Rate limiters
  private lastZombieSfx = 0;
  private lastFlameSfx = 0;
  private lastBirdChirp = 0;

  private settings: Pick<
    GameSettings,
    'masterVolume' | 'sfxVolume' | 'musicVolume' | 'ambienceVolume'
  > = {
    masterVolume: 0.8,
    sfxVolume: 0.85,
    musicVolume: 0.55,
    ambienceVolume: 0.65,
  };

  public unlock(): void {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.musicGain = this.ctx.createGain();
      this.ambienceGain = this.ctx.createGain();

      this.sfxGain.connect(this.masterGain);
      this.musicGain.connect(this.masterGain);
      this.ambienceGain.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);

      this.createNoiseBuffer();
      this.applyVolumes();
      this.startAmbienceLoop();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public updateSettings(
    s: Pick<GameSettings, 'masterVolume' | 'sfxVolume' | 'musicVolume' | 'ambienceVolume'>
  ): void {
    this.settings = { ...s };
    this.applyVolumes();
  }

  private applyVolumes(): void {
    if (!this.ctx || !this.masterGain || !this.sfxGain || !this.musicGain || !this.ambienceGain) {
      return;
    }
    const now = this.ctx.currentTime;
    this.masterGain.gain.setTargetAtTime(this.settings.masterVolume, now, 0.04);
    this.sfxGain.gain.setTargetAtTime(this.settings.sfxVolume, now, 0.04);
    this.musicGain.gain.setTargetAtTime(this.settings.musicVolume * 0.42, now, 0.06);
    this.ambienceGain.gain.setTargetAtTime(this.settings.ambienceVolume * 0.45, now, 0.08);
  }

  private createNoiseBuffer(): void {
    if (!this.ctx) return;
    const len = this.ctx.sampleRate * 2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    // Pink-ish noise for natural explosions, surf, and gunfire
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.997 * b0 + white * 0.029;
      b1 = 0.985 * b1 + white * 0.032;
      b2 = 0.950 * b2 + white * 0.048;
      data[i] = Math.max(-1, Math.min(1, (b0 + b1 + b2 + white * 0.42)));
    }
    this.noiseBuffer = buf;
  }

  // ======================================================
  // CONTINUOUS OCEAN WAVES & JUNGLE WIND AMBIENCE
  // ======================================================
  private startAmbienceLoop(): void {
    if (!this.ctx || !this.noiseBuffer || !this.ambienceGain || this.ambienceStarted) return;
    this.ambienceStarted = true;

    // 1. Ocean waves (lowpass filtered looping noise with slow LFO swell)
    const oceanSrc = this.ctx.createBufferSource();
    oceanSrc.buffer = this.noiseBuffer;
    oceanSrc.loop = true;

    const oceanFilter = this.ctx.createBiquadFilter();
    oceanFilter.type = 'lowpass';
    oceanFilter.frequency.value = 340;

    const oceanLfo = this.ctx.createOscillator();
    oceanLfo.frequency.value = 0.14; // gentle ~7s wave roll
    const oceanLfoGain = this.ctx.createGain();
    oceanLfoGain.gain.value = 210;
    oceanLfo.connect(oceanLfoGain);
    oceanLfoGain.connect(oceanFilter.frequency);

    this.oceanGain = this.ctx.createGain();
    this.oceanGain.gain.value = 0.16;

    oceanSrc.connect(oceanFilter);
    oceanFilter.connect(this.oceanGain);
    this.oceanGain.connect(this.ambienceGain);

    oceanSrc.start();
    oceanLfo.start();

    // 2. Tropical jungle breeze (bandpass canopy rustle)
    const jungleSrc = this.ctx.createBufferSource();
    jungleSrc.buffer = this.noiseBuffer;
    jungleSrc.loop = true;

    const jungleFilter = this.ctx.createBiquadFilter();
    jungleFilter.type = 'bandpass';
    jungleFilter.frequency.value = 920;
    jungleFilter.Q.value = 1.4;

    this.jungleGain = this.ctx.createGain();
    this.jungleGain.gain.value = 0.07;

    jungleSrc.connect(jungleFilter);
    jungleFilter.connect(this.jungleGain);
    this.jungleGain.connect(this.ambienceGain);
    jungleSrc.start();
  }

  public updateAmbienceSpatial(distanceToOcean: number, inCave: boolean, activeGameplay: boolean): void {
    if (!this.ctx || !this.oceanGain || !this.jungleGain) return;
    const now = this.ctx.currentTime;
    if (!activeGameplay) {
      // Dark island shore breeze on main menu
      this.oceanGain.gain.setTargetAtTime(0.22, now, 0.3);
      this.jungleGain.gain.setTargetAtTime(0.05, now, 0.3);
      return;
    }

    const coastProximity = Math.max(0, 1 - distanceToOcean / 650);
    const oceanLevel = inCave ? 0.03 : 0.06 + coastProximity * 0.34;
    const jungleLevel = inCave ? 0.02 : 0.06 + (1 - coastProximity) * 0.1;

    this.oceanGain.gain.setTargetAtTime(oceanLevel, now, 0.25);
    this.jungleGain.gain.setTargetAtTime(jungleLevel, now, 0.25);

    // Occasional subtle tropical bird / jungle cicada chirp
    if (!inCave && coastProximity < 0.7 && performance.now() - this.lastBirdChirp > 6500) {
      if (Math.random() < 0.015) {
        this.lastBirdChirp = performance.now();
        this.playJungleChirp();
      }
    }
  }

  private playJungleChirp(): void {
    if (!this.ctx || !this.ambienceGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    const base = 1800 + Math.random() * 900;
    osc.frequency.setValueAtTime(base, now);
    osc.frequency.exponentialRampToValueAtTime(base * 1.35, now + 0.06);
    osc.frequency.exponentialRampToValueAtTime(base * 0.88, now + 0.14);
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.045, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(g);
    g.connect(this.ambienceGain);
    osc.start(now);
    osc.stop(now + 0.18);
  }

  // ======================================================
  // PROCEDURAL WEAPON GUNSHOTS
  // ======================================================
  public playShoot(weapon: WeaponId): void {
    if (!this.ctx || !this.sfxGain || !this.noiseBuffer) return;
    const now = this.ctx.currentTime;

    if (weapon === 'flamethrower') {
      if (performance.now() - this.lastFlameSfx < 90) return;
      this.lastFlameSfx = performance.now();
      this.playNoiseBurst(0.14, 750, 260, 'bandpass', 0.28);
      return;
    }

    if (weapon === 'plasma') {
      const osc = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc2.type = 'triangle';
      osc.frequency.setValueAtTime(1180, now);
      osc.frequency.exponentialRampToValueAtTime(150, now + 0.22);
      osc2.frequency.setValueAtTime(520, now);
      osc2.frequency.exponentialRampToValueAtTime(65, now + 0.24);
      g.gain.setValueAtTime(0.32, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.connect(g);
      osc2.connect(g);
      g.connect(this.sfxGain);
      osc.start(now);
      osc2.start(now);
      osc.stop(now + 0.26);
      osc2.stop(now + 0.26);
      this.playNoiseBurst(0.08, 2800, 900, 'highpass', 0.16);
      return;
    }

    switch (weapon) {
      case 'pistol':
        this.playPunchTone(240, 68, 0.09, 'triangle', 0.28);
        this.playNoiseBurst(0.085, 2200, 650, 'bandpass', 0.34);
        break;
      case 'shotgun':
        this.playPunchTone(145, 36, 0.24, 'sawtooth', 0.45);
        this.playNoiseBurst(0.24, 1500, 220, 'lowpass', 0.56);
        // Subtle pump click after shot
        setTimeout(() => this.playMechanicalClick(420, 0.08), 190);
        break;
      case 'smg':
        this.playPunchTone(310, 95, 0.055, 'square', 0.18);
        this.playNoiseBurst(0.055, 2600, 900, 'bandpass', 0.26);
        break;
      case 'rifle':
        this.playPunchTone(205, 55, 0.11, 'sawtooth', 0.3);
        this.playNoiseBurst(0.11, 1950, 480, 'bandpass', 0.38);
        break;
      case 'sniper':
        this.playPunchTone(190, 32, 0.3, 'sawtooth', 0.52);
        this.playNoiseBurst(0.34, 3200, 340, 'lowpass', 0.58);
        setTimeout(() => this.playMechanicalClick(650, 0.1), 280);
        break;
      case 'lmg':
        this.playPunchTone(170, 52, 0.095, 'sawtooth', 0.33);
        this.playNoiseBurst(0.095, 1600, 400, 'lowpass', 0.42);
        break;
    }
  }

  public playReload(): void {
    if (!this.ctx || !this.sfxGain) return;
    this.playMechanicalClick(520, 0.12);
    setTimeout(() => this.playMechanicalClick(740, 0.12), 180);
  }

  public playEmptyClick(): void {
    this.playMechanicalClick(920, 0.09);
  }

  public playExplosion(): void {
    if (!this.ctx || !this.sfxGain || !this.noiseBuffer) return;
    this.playPunchTone(115, 22, 0.55, 'sawtooth', 0.65);
    this.playNoiseBurst(0.62, 1100, 120, 'lowpass', 0.72);
  }

  public playFootstep(terrain: string): void {
    if (!this.ctx || !this.sfxGain || !this.noiseBuffer) return;
    if (terrain === 'shallow_water') {
      this.playNoiseBurst(0.09, 1400, 650, 'bandpass', 0.16);
    } else if (terrain === 'sand') {
      this.playNoiseBurst(0.055, 1100, 400, 'bandpass', 0.09);
    } else if (terrain === 'concrete' || terrain === 'stone' || terrain === 'wood') {
      this.playPunchTone(160 + Math.random() * 40, 75, 0.035, 'triangle', 0.09);
    } else {
      // Grass / jungle brush
      this.playNoiseBurst(0.045, 1900, 700, 'highpass', 0.075);
    }
  }

  public playZombieSound(type: ZombieType, isDeath = false): void {
    if (!this.ctx || !this.sfxGain) return;
    const nowMs = performance.now();
    if (!isDeath && nowMs - this.lastZombieSfx < 340) return;
    if (!isDeath) this.lastZombieSfx = nowMs;

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const g = this.ctx.createGain();
    filter.type = 'lowpass';

    if (isDeath) {
      osc.type = 'sawtooth';
      const f0 = type === 'giant' ? 95 : type === 'fast' ? 250 : 145;
      osc.frequency.setValueAtTime(f0, now);
      osc.frequency.exponentialRampToValueAtTime(38, now + 0.19);
      filter.frequency.value = 600;
      g.gain.setValueAtTime(0.18, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.21);
      osc.connect(filter);
      filter.connect(g);
      g.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.22);
      return;
    }

    if (type === 'giant') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(92, now);
      osc.frequency.linearRampToValueAtTime(58, now + 0.48);
      filter.frequency.value = 340;
      g.gain.setValueAtTime(0.32, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.52);
      osc.connect(filter);
      filter.connect(g);
      g.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.54);
    } else if (type === 'fast') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(380, now);
      osc.frequency.exponentialRampToValueAtTime(210, now + 0.16);
      filter.frequency.value = 1100;
      g.gain.setValueAtTime(0.13, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.connect(filter);
      filter.connect(g);
      g.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.19);
    } else if (type === 'mutant') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(270, now);
      osc.frequency.linearRampToValueAtTime(490, now + 0.12);
      osc.frequency.exponentialRampToValueAtTime(140, now + 0.25);
      filter.frequency.value = 1200;
      g.gain.setValueAtTime(0.16, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
      osc.connect(filter);
      filter.connect(g);
      g.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.27);
    } else {
      osc.type = 'sawtooth';
      const base = type === 'heavy' ? 88 : 122 + Math.random() * 28;
      osc.frequency.setValueAtTime(base, now);
      osc.frequency.linearRampToValueAtTime(base * 0.72, now + 0.28);
      filter.frequency.value = 420;
      g.gain.setValueAtTime(0.13, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc.connect(filter);
      filter.connect(g);
      g.connect(this.sfxGain);
      osc.start(now);
      osc.stop(now + 0.32);
    }
  }

  public playPlayerHurt(): void {
    if (!this.ctx || !this.sfxGain) return;
    this.playPunchTone(185, 65, 0.16, 'sawtooth', 0.34);
    this.playNoiseBurst(0.1, 800, 300, 'lowpass', 0.24);
  }

  public playPickup(kind: 'coin' | 'medkit' | 'ammo' | 'crate' | 'buy'): void {
    if (!this.ctx || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    if (kind === 'crate') {
      this.playNoiseBurst(0.16, 950, 220, 'bandpass', 0.35);
      this.playPunchTone(160, 70, 0.1, 'square', 0.18);
      return;
    }

    const notes =
      kind === 'coin'
        ? [880, 1175]
        : kind === 'medkit'
        ? [523, 659, 784]
        : kind === 'buy'
        ? [587, 880, 1175]
        : [380, 540];

    notes.forEach((freq, i) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = kind === 'ammo' ? 'square' : 'triangle';
      const t0 = now + i * 0.055;
      osc.frequency.setValueAtTime(freq, t0);
      g.gain.setValueAtTime(0.18, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.11);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t0);
      osc.stop(t0 + 0.12);
    });
  }

  public playWaveHorn(isBoss: boolean): void {
    if (!this.ctx || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    const freqs = isBoss ? [110, 103.8, 82.4] : [220, 261.6, 329.6];
    freqs.forEach((f, idx) => {
      if (!this.ctx || !this.sfxGain) return;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = isBoss ? 'sawtooth' : 'triangle';
      const t0 = now + idx * 0.16;
      osc.frequency.setValueAtTime(f, t0);
      g.gain.setValueAtTime(0.001, t0);
      g.gain.linearRampToValueAtTime(0.24, t0 + 0.04);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + 0.45);
      osc.connect(g);
      g.connect(this.sfxGain);
      osc.start(t0);
      osc.stop(t0 + 0.47);
    });
  }

  private playPunchTone(
    fStart: number,
    fEnd: number,
    dur: number,
    type: OscillatorType,
    vol: number
  ): void {
    if (!this.ctx || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(fStart, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, fEnd), now + dur);
    g.gain.setValueAtTime(vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + dur + 0.02);
  }

  private playNoiseBurst(
    dur: number,
    fStart: number,
    fEnd: number,
    filterType: BiquadFilterType,
    vol: number
  ): void {
    if (!this.ctx || !this.sfxGain || !this.noiseBuffer) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.setValueAtTime(fStart, now);
    filter.frequency.exponentialRampToValueAtTime(Math.max(60, fEnd), now + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.sfxGain);
    src.start(now, Math.random() * 0.8, dur + 0.02);
  }

  private playMechanicalClick(freq: number, vol: number): void {
    if (!this.ctx || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.4, now + 0.04);
    g.gain.setValueAtTime(vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.045);
    osc.connect(g);
    g.connect(this.sfxGain);
    osc.start(now);
    osc.stop(now + 0.05);
  }

  // ======================================================
  // DYNAMIC RETRO MUSIC SEQUENCER (MENU / COMBAT / BOSS)
  // ======================================================
  public setMusicMode(mode: MusicMode): void {
    if (this.musicMode === mode) return;
    this.musicMode = mode;
    if (this.musicTimer !== null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    if (mode === 'none') return;

    this.musicStep = 0;
    const tempoMs =
      mode === 'menu' ? 320 : mode === 'intermission' ? 280 : mode === 'boss' ? 145 : 170;

    this.musicTimer = window.setInterval(() => {
      this.tickMusic();
    }, tempoMs);
  }

  private tickMusic(): void {
    if (!this.ctx || !this.musicGain || this.ctx.state !== 'running') return;
    const s = this.musicStep++;
    const now = this.ctx.currentTime;

    if (this.musicMode === 'menu' || this.musicMode === 'intermission') {
      // Haunting dark minor apocalyptic synth arpeggio (D minor)
      const bass = [73.42, 0, 73.42, 0, 58.27, 0, 65.41, 0, 55.0, 0, 65.41, 0, 73.42, 0, 82.41, 0];
      const lead = [293.66, 0, 349.23, 0, 329.63, 0, 261.63, 0, 293.66, 0, 0, 220, 261.63, 0, 220, 0];
      const b = bass[s % bass.length];
      const l = lead[s % lead.length];
      if (b > 0) this.playMusicNote(b, 0.52, 'sawtooth', 0.22, 320);
      if (l > 0 && (this.musicMode === 'menu' || s % 32 < 16)) {
        this.playMusicNote(l, 0.35, 'triangle', 0.14, 1400);
      }
      if (s % 8 === 0) {
        this.playMusicKick(now, 0.22);
      }
      return;
    }

    if (this.musicMode === 'combat' || this.musicMode === 'boss') {
      // Driving survival-action bassline + retro percussion + tense melody
      const bassCombat = [
        82.41, 82.41, 98.0, 82.41, 110.0, 82.41, 98.0, 73.42,
        65.41, 65.41, 73.42, 82.41, 98.0, 82.41, 73.42, 65.41,
      ];
      const bassBoss = [
        73.42, 73.42, 77.78, 73.42, 87.31, 73.42, 77.78, 65.41,
        73.42, 73.42, 110.0, 98.0, 87.31, 77.78, 73.42, 55.0,
      ];
      const leadCombat = [
        329.63, 0, 392.0, 329.63, 440.0, 0, 392.0, 0,
        293.66, 0, 329.63, 0, 392.0, 329.63, 293.66, 0,
      ];
      const leadBoss = [
        293.66, 311.13, 293.66, 0, 440.0, 415.3, 392.0, 0,
        349.23, 0, 329.63, 311.13, 293.66, 0, 220.0, 0,
      ];

      const bassSeq = this.musicMode === 'boss' ? bassBoss : bassCombat;
      const leadSeq = this.musicMode === 'boss' ? leadBoss : leadCombat;

      const b = bassSeq[s % bassSeq.length];
      this.playMusicNote(b, 0.14, 'sawtooth', 0.28, 550);

      const l = leadSeq[s % leadSeq.length];
      if (l > 0) {
        this.playMusicNote(l, 0.16, this.musicMode === 'boss' ? 'sawtooth' : 'square', 0.12, 1800);
      }

      // Kick on 0, 4, 8, 12; Snare on 4, 12; Hi-hat on odd steps
      if (s % 4 === 0) this.playMusicKick(now, 0.34);
      if (s % 8 === 4) this.playMusicSnare(now, 0.17);
      if (s % 2 === 1) this.playMusicHihat(now, 0.07);
    }
  }

  private playMusicNote(
    freq: number,
    dur: number,
    type: OscillatorType,
    vol: number,
    cutoff: number
  ): void {
    if (!this.ctx || !this.musicGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    filter.type = 'lowpass';
    filter.frequency.value = cutoff;
    g.gain.setValueAtTime(vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    osc.connect(filter);
    filter.connect(g);
    g.connect(this.musicGain);
    osc.start(now);
    osc.stop(now + dur + 0.02);
  }

  private playMusicKick(now: number, vol: number): void {
    if (!this.ctx || !this.musicGain) return;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(135, now);
    osc.frequency.exponentialRampToValueAtTime(36, now + 0.12);
    g.gain.setValueAtTime(vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    osc.connect(g);
    g.connect(this.musicGain);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  private playMusicSnare(now: number, vol: number): void {
    if (!this.ctx || !this.musicGain || !this.noiseBuffer) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 1100;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.musicGain);
    src.start(now, Math.random() * 0.5, 0.1);
  }

  private playMusicHihat(now: number, vol: number): void {
    if (!this.ctx || !this.musicGain || !this.noiseBuffer) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 5200;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.035);
    src.connect(filter);
    filter.connect(g);
    g.connect(this.musicGain);
    src.start(now, Math.random() * 0.5, 0.04);
  }
}

export const soundStudio = new SoundStudio();
