import { soundStudio } from './audio';
import { CHARACTERS } from './characters';
import { ZONE_INFO } from './i18n';
import { getSpriteAtlas, SpriteAtlas } from './sprites';
import {
  ActiveRunSave,
  Building,
  CharacterId,
  HudSnapshot,
  PickupItem,
  Rect,
  SaveData,
  WeaponId,
  WeaponRuntimeAmmo,
  WorldProp,
  ZombieType,
  ZoneId,
} from './types';
import {
  getEffectiveWeaponStats,
  GRENADE_CONFIG,
  WEAPON_ORDER,
  WEAPONS,
} from './weapons';
import {
  CHUNK_SIZE,
  CHUNKS_PER_AXIS,
  generateIslandWorld,
  getSignedCoastDistance,
  IslandWorld,
  WORLD_SIZE,
} from './world';

interface Bullet {
  x: number;
  y: number;
  prevX: number;
  prevY: number;
  vx: number;
  vy: number;
  damage: number;
  rangeLeft: number;
  pierceLeft: number;
  hitIds: Set<number>;
  color: string;
  splashRadius: number;
  isFlame: boolean;
  isPlasma: boolean;
  fromEnemy: boolean;
  radius: number;
}

interface ThrownGrenade {
  x: number;
  y: number;
  vx: number;
  vy: number;
  z: number;
  vz: number;
  fuse: number;
}

interface ZombieEntity {
  id: number;
  type: ZombieType;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  hp: number;
  maxHp: number;
  speed: number;
  damage: number;
  attackRange: number;
  attackCooldown: number;
  attackAnim: number;
  hurtFlash: number;
  burnTimer: number;
  burnTick: number;
  animTime: number;
  facingLeft: boolean;
  alerted: boolean;
  isWaveZombie: boolean;
  spitCooldown: number;
  slamCooldown: number;
  slamTelegraph: number;
  coinReward: number;
  scoreReward: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  gravity?: number;
  drag?: number;
  glow?: boolean;
}

interface Decal {
  x: number;
  y: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  isToxic?: boolean;
  radius?: number;
}

interface FloatingText {
  x: number;
  y: number;
  vy: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
  scale: number;
}

interface DynamicLight {
  x: number;
  y: number;
  radius: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
}

interface ShockwaveRing {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  life: number;
  maxLife: number;
}

export interface EngineCallbacks {
  onHudUpdate: (hud: HudSnapshot) => void;
  onSaveProgress: (mutator: (prev: SaveData) => SaveData) => void;
  onGameOver: (stats: { wave: number; kills: number; score: number; timeSurvived: number }) => void;
  onToggleShop: () => void;
  onTogglePause: () => void;
}

export class IslandSurvivalEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private lightCanvas: HTMLCanvasElement;
  private lightCtx: CanvasRenderingContext2D;

  private world: IslandWorld;
  private atlas: SpriteAtlas;
  private callbacks: EngineCallbacks;
  private saveData: SaveData;

  private rafId: number | null = null;
  private lastTime = 0;
  private running = false;
  private paused = false;
  private hudEmitTimer = 0;
  private globalTime = 0;

  // Camera
  private camX = 1600;
  private camY = 2060;
  private zoom = 1.9;
  private shakeMag = 0;
  private viewW = 960;
  private viewH = 540;

  // Player state
  private player = {
    x: 1600,
    y: 2060,
    vx: 0,
    vy: 0,
    radius: 10,
    hp: 100,
    maxHp: 100,
    stamina: 100,
    maxStamina: 100,
    aimAngle: -Math.PI / 2,
    facingLeft: false,
    animTime: 0,
    hurtFlash: 0,
    invulnTimer: 0,
    isMoving: false,
    isSprinting: false,
    footstepTimer: 0,
    weaponRecoilKick: 0,
    muzzleFlashTimer: 0,
    characterId: 'marcus' as CharacterId,
    equippedWeapon: 'pistol' as WeaponId,
    grenades: 2,
    fireCooldown: 0,
    reloading: false,
    reloadTimer: 0,
    reloadDuration: 1,
    ammoByWeapon: {} as Record<WeaponId, WeaponRuntimeAmmo>,
    inToxicSludge: false,
    toxicTick: 0,
    currentZone: 'beach' as ZoneId,
  };

  // Run stats & wave director
  private wave = 1;
  private score = 0;
  private kills = 0;
  private timeSurvived = 0;
  private inIntermission = false;
  private intermissionTimer = 0;
  private waveZombiesToSpawn: ZombieType[] = [];
  private waveTotalZombies = 0;
  private waveSpawnTimer = 0;
  private bannerId = 1;
  private statusBanner: HudSnapshot['statusBanner'] = null;
  private bannerTimer = 0;
  private damagedScreenFlash = 0;

  // Entities
  private nextEntityId = 1;
  private zombies: ZombieEntity[] = [];
  private bullets: Bullet[] = [];
  private grenades: ThrownGrenade[] = [];
  private pickups: PickupItem[] = [];
  private particles: Particle[] = [];
  private decals: Decal[] = [];
  private texts: FloatingText[] = [];
  private dynamicLights: DynamicLight[] = [];
  private shockwaves: ShockwaveRing[] = [];
  private buildingRoofAlpha: Record<string, number> = {};

  // Input state
  private keys = new Set<string>();
  private mouseScreenX = 0;
  private mouseScreenY = 0;
  private mouseDown = false;
  private hasMouseMoved = false;

  // Touch inputs
  private touchMove = { x: 0, y: 0, sprint: false };
  private touchAim = { x: 0, y: 0, active: false, firing: false };
  private touchFireBtn = false;

  constructor(
    canvas: HTMLCanvasElement,
    saveData: SaveData,
    callbacks: EngineCallbacks
  ) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false })!;
    this.ctx.imageSmoothingEnabled = false;

    this.lightCanvas = document.createElement('canvas');
    this.lightCanvas.width = 480;
    this.lightCanvas.height = 270;
    this.lightCtx = this.lightCanvas.getContext('2d')!;

    this.saveData = saveData;
    this.callbacks = callbacks;
    this.atlas = getSpriteAtlas();
    this.world = generateIslandWorld();

    for (const b of this.world.buildings) {
      this.buildingRoofAlpha[b.id] = 1;
    }

    this.handleResize();
    this.bindInputEvents();
  }

  public syncSaveData(saveData: SaveData): void {
    const prevUnlocked = new Set(this.saveData.unlockedWeapons);
    this.saveData = saveData;
    soundStudio.updateSettings(saveData.settings);

    const prevLevels = this.saveData.weaponLevels;
    // Ensure newly unlocked weapons get starting ammo & upgraded weapons top off their mag!
    for (const wid of saveData.unlockedWeapons) {
      const lv = saveData.weaponLevels[wid] || 1;
      const stats = getEffectiveWeaponStats(wid, lv);
      if (!prevUnlocked.has(wid) || !this.player.ammoByWeapon[wid]) {
        this.player.ammoByWeapon[wid] = {
          mag: stats.magSize,
          reserve: WEAPONS[wid].startReserve,
        };
      } else if (lv > (prevLevels[wid] || 1)) {
        this.player.ammoByWeapon[wid].mag = stats.magSize;
      }
    }

    // Update character max HP if changed
    const ch = CHARACTERS[this.player.characterId];
    this.player.maxHp = 100 + ch.maxHpBonus;
    this.emitHud();
  }

  public startNewRun(saveData: SaveData): void {
    this.saveData = saveData;
    this.world = generateIslandWorld();
    for (const b of this.world.buildings) this.buildingRoofAlpha[b.id] = 1;

    const charDef = CHARACTERS[saveData.selectedCharacter];
    this.player.characterId = charDef.id;
    this.player.x = this.world.spawnPoint.x;
    this.player.y = this.world.spawnPoint.y;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.maxHp = 100 + charDef.maxHpBonus;
    this.player.hp = this.player.maxHp;
    this.player.stamina = 100;
    this.player.grenades = charDef.startGrenades;
    this.player.reloading = false;
    this.player.fireCooldown = 0;
    this.player.hurtFlash = 0;
    this.player.invulnTimer = 1.0;

    // Initialize weapon ammo for every unlocked weapon
    this.player.ammoByWeapon = {} as Record<WeaponId, WeaponRuntimeAmmo>;
    for (const wid of WEAPON_ORDER) {
      const stats = getEffectiveWeaponStats(wid, saveData.weaponLevels[wid] || 1);
      this.player.ammoByWeapon[wid] = {
        mag: stats.magSize,
        reserve: WEAPONS[wid].startReserve,
      };
    }

    // Equip best unlocked primary or pistol
    const unlocked = saveData.unlockedWeapons;
    this.player.equippedWeapon = unlocked.includes('rifle')
      ? 'rifle'
      : unlocked.includes('smg')
      ? 'smg'
      : unlocked.includes('shotgun')
      ? 'shotgun'
      : 'pistol';

    this.wave = 1;
    this.score = 0;
    this.kills = 0;
    this.timeSurvived = 0;
    this.zombies = [];
    this.bullets = [];
    this.grenades = [];
    this.pickups = [];
    this.particles = [];
    this.decals = [];
    this.texts = [];
    this.dynamicLights = [];
    this.shockwaves = [];

    this.camX = this.player.x;
    this.camY = this.player.y;
    this.player.currentZone = this.world.getZoneAt(this.player.x, this.player.y);

    // Populate ambient zone patrol zombies & starter pickups
    this.spawnAmbientIslandZombies();
    this.spawnStarterPickups();
    this.beginWave(1);

    this.paused = false;
    this.startLoop();
    this.emitHud();
  }

  public resumeSavedRun(saveData: SaveData): void {
    const run = saveData.activeRun;
    if (!run) {
      this.startNewRun(saveData);
      return;
    }

    this.saveData = saveData;
    this.world = generateIslandWorld();
    for (const b of this.world.buildings) this.buildingRoofAlpha[b.id] = 1;

    const charDef = CHARACTERS[run.characterId || saveData.selectedCharacter];
    this.player.characterId = charDef.id;
    this.player.x = run.x;
    this.player.y = run.y;
    this.player.vx = 0;
    this.player.vy = 0;
    this.player.maxHp = run.maxHp || 100 + charDef.maxHpBonus;
    this.player.hp = Math.max(25, Math.min(this.player.maxHp, run.hp));
    this.player.stamina = 100;
    this.player.grenades = run.grenades;
    this.player.equippedWeapon = saveData.unlockedWeapons.includes(run.equippedWeapon)
      ? run.equippedWeapon
      : 'pistol';
    this.player.reloading = false;
    this.player.fireCooldown = 0;
    this.player.invulnTimer = 1.2;

    this.player.ammoByWeapon = {} as Record<WeaponId, WeaponRuntimeAmmo>;
    for (const wid of WEAPON_ORDER) {
      const savedAmmo = run.ammoByWeapon?.[wid];
      const stats = getEffectiveWeaponStats(wid, saveData.weaponLevels[wid] || 1);
      this.player.ammoByWeapon[wid] = savedAmmo
        ? { mag: savedAmmo.mag, reserve: savedAmmo.reserve }
        : { mag: stats.magSize, reserve: WEAPONS[wid].startReserve };
    }

    this.wave = Math.max(1, run.wave);
    this.score = run.score;
    this.kills = run.kills;
    this.timeSurvived = run.timeSurvived;

    this.zombies = [];
    this.bullets = [];
    this.grenades = [];
    this.pickups = [];
    this.particles = [];
    this.decals = [];
    this.texts = [];
    this.dynamicLights = [];
    this.shockwaves = [];

    this.camX = this.player.x;
    this.camY = this.player.y;
    this.player.currentZone = this.world.getZoneAt(this.player.x, this.player.y);

    this.spawnAmbientIslandZombies();
    this.beginWave(this.wave);

    this.paused = false;
    this.startLoop();
    this.emitHud();
  }

  public getActiveRunSnapshot(): ActiveRunSave {
    const ammoCopy = {} as Record<WeaponId, WeaponRuntimeAmmo>;
    for (const wid of WEAPON_ORDER) {
      const a = this.player.ammoByWeapon[wid];
      ammoCopy[wid] = a ? { mag: a.mag, reserve: a.reserve } : { mag: 10, reserve: 30 };
    }
    return {
      wave: this.wave,
      score: this.score,
      kills: this.kills,
      hp: Math.round(this.player.hp),
      maxHp: this.player.maxHp,
      x: Math.round(this.player.x),
      y: Math.round(this.player.y),
      equippedWeapon: this.player.equippedWeapon,
      grenades: this.player.grenades,
      ammoByWeapon: ammoCopy,
      timeSurvived: Math.round(this.timeSurvived),
      zone: this.player.currentZone,
      characterId: this.player.characterId,
      savedAt: Date.now(),
    };
  }

  public setPaused(p: boolean): void {
    this.paused = p;
    if (p) {
      this.keys.clear();
      this.mouseDown = false;
      this.touchFireBtn = false;
    } else {
      this.lastTime = performance.now();
    }
  }

  public stop(): void {
    this.running = false;
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  public destroy(): void {
    this.stop();
    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('mouseup', this.handleMouseUp);
    window.removeEventListener('blur', this.handleWindowBlur);
  }

  // External shop/HUD actions
  public equipWeapon(id: WeaponId): void {
    if (!this.saveData.unlockedWeapons.includes(id)) return;
    if (this.player.equippedWeapon === id) return;
    this.player.equippedWeapon = id;
    this.player.reloading = false;
    this.player.fireCooldown = 0.12;
    soundStudio.playPickup('ammo');
    this.emitHud();
  }

  public cycleWeapon(dir: number): void {
    const owned = WEAPON_ORDER.filter((w) => this.saveData.unlockedWeapons.includes(w));
    if (owned.length <= 1) return;
    const idx = owned.indexOf(this.player.equippedWeapon);
    const next = owned[(idx + dir + owned.length) % owned.length];
    this.equipWeapon(next);
  }

  public grantShopAmmo(id: WeaponId, amount: number): void {
    const ammo = this.player.ammoByWeapon[id];
    if (!ammo) return;
    ammo.reserve = Math.min(WEAPONS[id].maxReserve, ammo.reserve + amount);
    this.emitHud();
  }

  public grantShopGrenade(count = 1): boolean {
    if (this.player.grenades >= GRENADE_CONFIG.maxCarry) return false;
    this.player.grenades = Math.min(GRENADE_CONFIG.maxCarry, this.player.grenades + count);
    this.emitHud();
    return true;
  }

  public getGrenadeCount(): number {
    return this.player.grenades;
  }

  public triggerReload(): void {
    if (this.paused || this.player.reloading) return;
    const wid = this.player.equippedWeapon;
    const wDef = WEAPONS[wid];
    const stats = this.getPlayerWeaponStats(wid);
    const ammo = this.player.ammoByWeapon[wid];
    if (!ammo) return;
    if (ammo.mag >= stats.magSize) return;
    if (!wDef.infiniteReserve && ammo.reserve <= 0) {
      soundStudio.playEmptyClick();
      return;
    }
    this.player.reloading = true;
    this.player.reloadDuration = stats.reloadTime;
    this.player.reloadTimer = stats.reloadTime;
    soundStudio.playReload();
    this.emitHud();
  }

  public triggerGrenade(): void {
    if (this.paused) return;
    if (this.player.grenades <= 0) {
      soundStudio.playEmptyClick();
      return;
    }
    this.player.grenades--;
    const angle = this.player.aimAngle;
    this.grenades.push({
      x: this.player.x + Math.cos(angle) * 14,
      y: this.player.y + Math.sin(angle) * 14,
      vx: Math.cos(angle) * GRENADE_CONFIG.throwSpeed,
      vy: Math.sin(angle) * GRENADE_CONFIG.throwSpeed,
      z: 10,
      vz: 145,
      fuse: GRENADE_CONFIG.fuseTime,
    });
    soundStudio.playPickup('ammo');
    this.emitHud();
  }

  public skipIntermission(): void {
    if (this.inIntermission) {
      this.intermissionTimer = 0.05;
    }
  }

  public openNearbyCrate(): void {
    if (!this.paused) this.interactNearbyCrate();
  }

  public setTouchMove(x: number, y: number, sprint: boolean): void {
    this.touchMove.x = x;
    this.touchMove.y = y;
    this.touchMove.sprint = sprint;
  }

  public setTouchAim(x: number, y: number, active: boolean, firing: boolean): void {
    this.touchAim.x = x;
    this.touchAim.y = y;
    this.touchAim.active = active;
    this.touchAim.firing = firing;
  }

  public setTouchFireButton(pressed: boolean): void {
    this.touchFireBtn = pressed;
  }

  // ======================================================
  // LOOP & INPUT BINDINGS
  // ======================================================
  private startLoop(): void {
    if (this.running) return;
    this.running = true;
    this.lastTime = performance.now();
    const tick = (now: number) => {
      if (!this.running) return;
      const dt = Math.min(0.05, Math.max(0.001, (now - this.lastTime) / 1000));
      this.lastTime = now;

      if (!this.paused) {
        this.update(dt);
      }
      this.render();
      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  private handleResize = (): void => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = this.canvas.parentElement?.getBoundingClientRect();
    const w = Math.max(320, Math.floor(rect ? rect.width : window.innerWidth));
    const h = Math.max(240, Math.floor(rect ? rect.height : window.innerHeight));
    this.viewW = w;
    this.viewH = h;
    this.canvas.width = Math.floor(w * dpr);
    this.canvas.height = Math.floor(h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.ctx.imageSmoothingEnabled = false;

    // Responsive zoom so landscape mobile and widescreen desktop have ideal combat visibility
    const minDim = Math.min(w, h);
    if (minDim < 440) this.zoom = 1.45;
    else if (minDim < 620) this.zoom = 1.65;
    else this.zoom = 1.95;

    this.lightCanvas.width = Math.max(240, Math.floor(w / 2));
    this.lightCanvas.height = Math.max(160, Math.floor(h / 2));
  };

  private handleKeyDown = (e: KeyboardEvent): void => {
    if (!this.running) return;
    const code = e.code;

    if (code === 'Escape' || code === 'KeyP') {
      e.preventDefault();
      this.callbacks.onTogglePause();
      return;
    }
    if (code === 'KeyB' || code === 'Tab') {
      e.preventDefault();
      this.callbacks.onToggleShop();
      return;
    }
    if (this.paused) return;

    this.keys.add(code);

    if (code === 'KeyR') this.triggerReload();
    else if (code === 'KeyG') this.triggerGrenade();
    else if (code === 'KeyQ') this.cycleWeapon(-1);
    else if (code === 'KeyE') this.cycleWeapon(1);
    else if (code === 'KeyF') this.interactNearbyCrate();
    else if (code.startsWith('Digit')) {
      const idx = parseInt(code.replace('Digit', ''), 10) - 1;
      if (idx >= 0 && idx < WEAPON_ORDER.length) {
        this.equipWeapon(WEAPON_ORDER[idx]);
      }
    }
  };

  private handleKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
  };

  private handleMouseUp = (): void => {
    this.mouseDown = false;
  };

  private handleWindowBlur = (): void => {
    this.keys.clear();
    this.mouseDown = false;
  };

  private bindInputEvents(): void {
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('mouseup', this.handleMouseUp);
    window.addEventListener('blur', this.handleWindowBlur);

    this.canvas.addEventListener('mousemove', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      this.mouseScreenX = e.clientX - rect.left;
      this.mouseScreenY = e.clientY - rect.top;
      this.hasMouseMoved = true;
    });

    this.canvas.addEventListener('mousedown', (e) => {
      if (this.paused) return;
      soundStudio.unlock();
      const rect = this.canvas.getBoundingClientRect();
      this.mouseScreenX = e.clientX - rect.left;
      this.mouseScreenY = e.clientY - rect.top;
      this.hasMouseMoved = true;
      if (e.button === 0) this.mouseDown = true;
      if (e.button === 2) this.triggerGrenade();
    });

    this.canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    this.canvas.addEventListener(
      'wheel',
      (e) => {
        if (this.paused) return;
        e.preventDefault();
        this.cycleWeapon(e.deltaY > 0 ? 1 : -1);
      },
      { passive: false }
    );
  }

  // ======================================================
  // WAVE DIRECTOR & ZONE SPAWNING
  // ======================================================
  private spawnStarterPickups(): void {
    // Give the player nearby crates & initial supplies to discover right away
    this.spawnPickup('ammo', 1645, 2015, 1);
    this.spawnPickup('coin', 1565, 2010, 15);
    // Hospital medkits
    this.spawnPickup('medkit', 1035, 935, 45);
    this.spawnPickup('medkit', 1125, 935, 45);
    // Ammo Depot supplies
    this.spawnPickup('ammo', 2260, 990, 2);
    this.spawnPickup('grenade', 2310, 995, 1);
    // Caves gold stash
    this.spawnPickup('coin', 2480, 1615, 35);
    this.spawnPickup('coin', 2430, 1670, 35);
    // Military grenades
    this.spawnPickup('grenade', 1645, 795, 1);
    this.spawnPickup('ammo', 1860, 795, 2);

    // Discoverable Island Weapons hidden in iconic zones!
    this.spawnPickup('weapon_drop', 850, 1790, 1, 'shotgun');     // Abandoned Houses
    this.spawnPickup('weapon_drop', 2270, 975, 1, 'smg');         // Ammo Depot
    this.spawnPickup('weapon_drop', 1635, 755, 1, 'rifle');       // Military Base HQ
    this.spawnPickup('weapon_drop', 2500, 1655, 1, 'sniper');     // Dark Crystal Caves
    this.spawnPickup('weapon_drop', 2265, 2145, 1, 'flamethrower'); // Virus Zone
  }

  private spawnAmbientIslandZombies(): void {
    const spots: { x: number; y: number; type: ZombieType }[] = [
      { x: 960, y: 1580, type: 'normal' },
      { x: 1030, y: 1060, type: 'normal' },
      { x: 1120, y: 980, type: 'fast' },
      { x: 1680, y: 950, type: 'heavy' },
      { x: 1750, y: 880, type: 'normal' },
      { x: 2250, y: 1080, type: 'heavy' },
      { x: 2420, y: 1620, type: 'fast' },
      { x: 2180, y: 2180, type: 'mutant' },
      { x: 2330, y: 2220, type: 'mutant' },
    ];
    for (const s of spots) {
      if (Math.hypot(s.x - this.player.x, s.y - this.player.y) > 260) {
        this.spawnZombieAt(s.type, s.x, s.y, false, false);
      }
    }
  }

  private beginWave(waveNum: number): void {
    this.wave = waveNum;
    this.inIntermission = false;
    this.intermissionTimer = 0;

    const queue: ZombieType[] = [];
    const baseCount = Math.round(7 + waveNum * 3.4);
    const isBossWave = waveNum % 5 === 0;

    for (let i = 0; i < baseCount; i++) {
      const r = Math.random();
      if (waveNum === 1) {
        queue.push('normal');
      } else if (waveNum === 2) {
        queue.push(r < 0.72 ? 'normal' : 'fast');
      } else if (waveNum === 3) {
        queue.push(r < 0.5 ? 'normal' : r < 0.8 ? 'fast' : 'heavy');
      } else if (waveNum === 4) {
        queue.push(r < 0.36 ? 'normal' : r < 0.64 ? 'fast' : r < 0.84 ? 'heavy' : 'mutant');
      } else {
        queue.push(r < 0.28 ? 'normal' : r < 0.54 ? 'fast' : r < 0.76 ? 'heavy' : 'mutant');
      }
    }

    if (isBossWave) {
      const bossCount = Math.min(3, Math.floor(waveNum / 5));
      for (let b = 0; b < bossCount; b++) {
        queue.unshift('giant');
      }
    }

    this.waveZombiesToSpawn = queue;
    this.waveTotalZombies = queue.length;
    this.waveSpawnTimer = 0.6;

    soundStudio.playWaveHorn(isBossWave);
    soundStudio.setMusicMode(isBossWave ? 'boss' : 'combat');

    if (isBossWave) {
      this.showBanner(
        `WAVE ${waveNum} — TITAN BOSS INCOMING!`,
        `موج ${waveNum} — هشدار: زامبی غول‌پیکر وارد شد!`,
        '#ef4444',
        4.2
      );
    } else {
      this.showBanner(
        `WAVE ${waveNum} STARTED`,
        `موج ${waveNum} آغاز شد! زنده بمانید`,
        '#f59e0b',
        3.0
      );
    }

    // Persist active progress at wave start
    this.saveProgressSnapshot();
  }

  private completeWave(): void {
    this.inIntermission = true;
    this.intermissionTimer = 14;
    soundStudio.setMusicMode('intermission');
    soundStudio.playPickup('buy');

    const waveBonusCoins = 25 + this.wave * 10;
    this.callbacks.onSaveProgress((prev) => ({
      ...prev,
      coins: prev.coins + waveBonusCoins,
      bestWave: Math.max(prev.bestWave, this.wave),
      bestScore: Math.max(prev.bestScore, this.score),
      activeRun: this.getActiveRunSnapshot(),
    }));

    this.addFloatingText(
      this.player.x,
      this.player.y - 26,
      `+${waveBonusCoins} COINS!`,
      '#ffd94a',
      1.2
    );

    this.showBanner(
      `WAVE ${this.wave} CLEARED! +${waveBonusCoins} COINS • SUPPLY DROP!`,
      `موج ${this.wave} پاکسازی شد! +${waveBonusCoins} سکه • بسته تجهیزات فرود آمد!`,
      '#4ade80',
      4.5
    );

    // Drop 3 fresh Supply Crates & a Medkit around the island / nearby zones!
    this.dropWaveSupplies();
  }

  private dropWaveSupplies(): void {
    // Always drop 1 supply crate reasonably near the player & 2 in iconic zones
    const targets: { x: number; y: number }[] = [];
    for (let attempt = 0; attempt < 24; attempt++) {
      const ang = Math.random() * Math.PI * 2;
      const dist = 130 + Math.random() * 190;
      const x = this.player.x + Math.cos(ang) * dist;
      const y = this.player.y + Math.sin(ang) * dist;
      if (this.isPointClearForSpawn(x, y)) {
        targets.push({ x, y });
        break;
      }
    }

    // Landmark supply spots (Hospital, Military, Ammo Depot, Caves, Houses)
    const landmarkSpots = [
      { x: 1040, y: 940 },
      { x: 1680, y: 960 },
      { x: 2265, y: 990 },
      { x: 2440, y: 1620 },
      { x: 965, y: 1620 },
      { x: 2190, y: 2150 },
    ];
    for (let i = 0; i < 2; i++) {
      const pick = landmarkSpots[Math.floor(Math.random() * landmarkSpots.length)];
      const x = pick.x + (Math.random() - 0.5) * 60;
      const y = pick.y + (Math.random() - 0.5) * 60;
      if (this.isPointClearForSpawn(x, y)) {
        targets.push({ x, y });
      }
    }

    for (const pos of targets) {
      this.world.props.push({
        id: `drop_${this.nextEntityId++}`,
        type: 'crate',
        x: pos.x,
        y: pos.y,
        radius: 12,
        solid: true,
        blocksBullets: true,
        hp: 30,
        maxHp: 30,
        variant: 0,
        zone: this.world.getZoneAt(pos.x, pos.y),
      });
      this.shockwaves.push({
        x: pos.x,
        y: pos.y,
        radius: 4,
        maxRadius: 42,
        color: '#facc15',
        life: 0.45,
        maxLife: 0.45,
      });
    }
  }

  private spawnWaveZombie(type: ZombieType): void {
    // Spawn around the player outside camera view, on valid island landmass
    const minR = Math.max(this.viewW, this.viewH) / (2 * this.zoom) + 70;
    const maxR = minR + 220;
    for (let tries = 0; tries < 28; tries++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = minR + Math.random() * (maxR - minR);
      const sx = this.player.x + Math.cos(angle) * dist;
      const sy = this.player.y + Math.sin(angle) * dist;
      if (this.isPointClearForSpawn(sx, sy)) {
        this.spawnZombieAt(type, sx, sy, true, true);
        return;
      }
    }
    // Fallback closer to island center if player is cornered on beach edge
    const angleToCenter = Math.atan2(1600 - this.player.y, 1600 - this.player.x);
    const sx = this.player.x + Math.cos(angleToCenter) * (minR + 40);
    const sy = this.player.y + Math.sin(angleToCenter) * (minR + 40);
    this.spawnZombieAt(type, sx, sy, true, true);
  }

  private spawnZombieAt(
    type: ZombieType,
    x: number,
    y: number,
    alerted: boolean,
    isWaveZombie: boolean
  ): void {
    const waveScale = 1 + (this.wave - 1) * 0.14;
    const speedScale = 1 + Math.min(0.45, (this.wave - 1) * 0.03);

    const configs: Record<
      ZombieType,
      {
        hp: number;
        speed: number;
        damage: number;
        radius: number;
        range: number;
        coins: number;
        score: number;
      }
    > = {
      normal: { hp: 56, speed: 74, damage: 11, radius: 10, range: 24, coins: 8, score: 25 },
      fast: { hp: 36, speed: 132, damage: 9, radius: 9, range: 22, coins: 11, score: 35 },
      heavy: { hp: 165, speed: 50, damage: 20, radius: 13, range: 28, coins: 18, score: 65 },
      mutant: { hp: 96, speed: 68, damage: 14, radius: 11, range: 26, coins: 22, score: 85 },
      giant: {
        hp: 680 + this.wave * 110,
        speed: 58,
        damage: 32,
        radius: 20,
        range: 42,
        coins: 120,
        score: 500,
      },
    };

    const cfg = configs[type];
    const hp = Math.round(cfg.hp * (type === 'giant' ? 1 : waveScale));
    this.zombies.push({
      id: this.nextEntityId++,
      type,
      x,
      y,
      vx: 0,
      vy: 0,
      radius: cfg.radius,
      hp,
      maxHp: hp,
      speed: cfg.speed * speedScale,
      damage: Math.round(cfg.damage * (1 + (this.wave - 1) * 0.06)),
      attackRange: cfg.range,
      attackCooldown: 0.4,
      attackAnim: 0,
      hurtFlash: 0,
      burnTimer: 0,
      burnTick: 0,
      animTime: Math.random() * 5,
      facingLeft: false,
      alerted,
      isWaveZombie,
      spitCooldown: 1.8 + Math.random(),
      slamCooldown: 4.5,
      slamTelegraph: 0,
      coinReward: cfg.coins,
      scoreReward: cfg.score,
    });
  }

  private isPointClearForSpawn(x: number, y: number): boolean {
    if (x < 220 || x > WORLD_SIZE - 220 || y < 220 || y > WORLD_SIZE - 220) return false;
    if (getSignedCoastDistance(x, y) < 28) return false;
    for (const w of this.world.staticWalls) {
      if (x > w.x - 16 && x < w.x + w.w + 16 && y > w.y - 16 && y < w.y + w.h + 16) return false;
    }
    return true;
  }

  // ======================================================
  // MAIN SIMULATION UPDATE
  // ======================================================
  private update(dt: number): void {
    this.globalTime += dt;
    this.timeSurvived += dt;

    if (this.bannerTimer > 0) {
      this.bannerTimer -= dt;
      if (this.bannerTimer <= 0) this.statusBanner = null;
    }
    if (this.damagedScreenFlash > 0) {
      this.damagedScreenFlash = Math.max(0, this.damagedScreenFlash - dt * 2.4);
    }

    this.updatePlayer(dt);
    this.updateWaveDirector(dt);
    this.updateZombies(dt);
    this.updateBullets(dt);
    this.updateGrenades(dt);
    this.updatePickups(dt);
    this.updateParticlesAndEffects(dt);
    this.updateCamera(dt);

    // Update ambient ocean/jungle sound spatialization
    const oceanDist = this.world.getDistanceToOcean(this.player.x, this.player.y);
    soundStudio.updateAmbienceSpatial(
      oceanDist,
      this.world.isInCaveArea(this.player.x, this.player.y),
      true
    );

    // Throttled HUD updates (~15Hz)
    this.hudEmitTimer += dt;
    if (this.hudEmitTimer >= 0.065) {
      this.hudEmitTimer = 0;
      this.emitHud();
    }
  }

  private getPlayerWeaponStats(wid: WeaponId) {
    const ch = CHARACTERS[this.player.characterId];
    const lv = this.saveData.weaponLevels[wid] || 1;
    return getEffectiveWeaponStats(wid, lv, ch.damageBonus, ch.reloadBonus);
  }

  private updatePlayer(dt: number): void {
    const p = this.player;
    const ch = CHARACTERS[p.characterId];

    // 1. Movement input (Keyboard + Mobile Touch Joystick)
    let ix = 0;
    let iy = 0;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) iy -= 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) iy += 1;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) ix -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) ix += 1;

    if (Math.hypot(this.touchMove.x, this.touchMove.y) > 0.1) {
      ix = this.touchMove.x;
      iy = this.touchMove.y;
    }

    const mag = Math.hypot(ix, iy);
    if (mag > 1) {
      ix /= mag;
      iy /= mag;
    }

    p.isMoving = mag > 0.08;
    const wantsSprint =
      (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || this.touchMove.sprint) &&
      p.isMoving &&
      p.stamina > 6;

    p.isSprinting = wantsSprint;
    if (p.isSprinting) {
      p.stamina = Math.max(0, p.stamina - 28 * dt);
    } else {
      p.stamina = Math.min(p.maxStamina, p.stamina + (p.isMoving ? 14 : 26) * dt);
    }

    const terrain = this.world.getTerrainKindAt(p.x, p.y);
    const waterSlow = terrain === 'shallow_water' ? 0.78 : 1.0;
    const baseSpeed = 148 * (1 + ch.speedBonus) * waterSlow;
    const speed = p.isSprinting ? baseSpeed * 1.44 : baseSpeed;

    p.vx = ix * speed;
    p.vy = iy * speed;

    this.moveCircleWithCollisions(p, p.vx * dt, p.vy * dt);

    // Footstep sound & terrain dust/water ripples
    if (p.isMoving) {
      p.animTime += dt * (p.isSprinting ? 11.5 : 7.5);
      p.footstepTimer -= dt;
      if (p.footstepTimer <= 0) {
        p.footstepTimer = p.isSprinting ? 0.24 : 0.36;
        soundStudio.playFootstep(terrain);
        if (terrain === 'shallow_water') {
          this.shockwaves.push({
            x: p.x,
            y: p.y + 6,
            radius: 2,
            maxRadius: 16,
            color: 'rgba(215, 248, 255, 0.7)',
            life: 0.35,
            maxLife: 0.35,
          });
        } else {
          this.particles.push({
            x: p.x + (Math.random() - 0.5) * 6,
            y: p.y + 8,
            vx: -p.vx * 0.12 + (Math.random() - 0.5) * 18,
            vy: -p.vy * 0.12 + (Math.random() - 0.5) * 12,
            size: p.isSprinting ? 3 : 2,
            color: terrain === 'sand' ? '#e8d09b' : terrain === 'virus' ? '#70b83e' : '#8a8275',
            alpha: 0.65,
            life: 0.32,
            maxLife: 0.32,
            drag: 4,
          });
        }
      }
    } else {
      p.animTime = 0;
    }

    // 2. Aiming (Touch aim joystick OR Mouse cursor OR auto-target assist when using fire button)
    if (this.touchAim.active && Math.hypot(this.touchAim.x, this.touchAim.y) > 0.15) {
      p.aimAngle = Math.atan2(this.touchAim.y, this.touchAim.x);
    } else if (this.touchFireBtn && !this.hasMouseMoved) {
      const nearest = this.findNearestZombie(p.x, p.y, 440);
      if (nearest) {
        p.aimAngle = Math.atan2(nearest.y - p.y, nearest.x - p.x);
      } else if (p.isMoving) {
        p.aimAngle = Math.atan2(iy, ix);
      }
    } else if (this.hasMouseMoved) {
      const worldMouseX = this.camX + (this.mouseScreenX - this.viewW / 2) / this.zoom;
      const worldMouseY = this.camY + (this.mouseScreenY - this.viewH / 2) / this.zoom;
      p.aimAngle = Math.atan2(worldMouseY - p.y, worldMouseX - p.x);
    } else if (p.isMoving) {
      p.aimAngle = Math.atan2(iy, ix);
    }
    p.facingLeft = Math.cos(p.aimAngle) < 0;

    // 3. Reloading & Shooting
    if (p.fireCooldown > 0) p.fireCooldown -= dt;
    if (p.weaponRecoilKick > 0) p.weaponRecoilKick = Math.max(0, p.weaponRecoilKick - dt * 26);
    if (p.muzzleFlashTimer > 0) p.muzzleFlashTimer = Math.max(0, p.muzzleFlashTimer - dt);
    if (p.hurtFlash > 0) p.hurtFlash = Math.max(0, p.hurtFlash - dt);
    if (p.invulnTimer > 0) p.invulnTimer = Math.max(0, p.invulnTimer - dt);

    if (p.reloading) {
      p.reloadTimer -= dt;
      if (p.reloadTimer <= 0) {
        this.finishReload();
      }
    } else {
      const wantsFire = this.mouseDown || this.touchAim.firing || this.touchFireBtn;
      if (wantsFire && p.fireCooldown <= 0) {
        this.fireCurrentWeapon();
      }
    }

    // 4. Zone change detection & Building roof transparency
    const newZone = this.world.getZoneAt(p.x, p.y);
    if (newZone !== p.currentZone) {
      p.currentZone = newZone;
      const info = ZONE_INFO[newZone];
      this.showBanner(info.nameEn, info.nameFa, info.accent, 2.6);
    }

    for (const b of this.world.buildings) {
      const inside = p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h;
      const target = inside ? 0.08 : 1.0;
      const cur = this.buildingRoofAlpha[b.id] ?? 1;
      this.buildingRoofAlpha[b.id] = cur + (target - cur) * Math.min(1, dt * 10);
    }

    // 5. Toxic Sludge Pools & Mutant Acid Puddles check
    let inToxic = false;
    for (const pool of this.world.toxicPools) {
      if (Math.hypot(p.x - pool.x, p.y - pool.y) < pool.radius - 4) {
        inToxic = true;
        break;
      }
    }
    if (!inToxic) {
      for (const d of this.decals) {
        if (d.isToxic && d.radius && Math.hypot(p.x - d.x, p.y - d.y) < d.radius) {
          inToxic = true;
          break;
        }
      }
    }
    p.inToxicSludge = inToxic;
    if (inToxic) {
      p.toxicTick -= dt;
      if (p.toxicTick <= 0) {
        p.toxicTick = 0.7;
        this.damagePlayer(5, true);
      }
    } else {
      p.toxicTick = 0.25;
    }
  }

  private finishReload(): void {
    const wid = this.player.equippedWeapon;
    const wDef = WEAPONS[wid];
    const stats = this.getPlayerWeaponStats(wid);
    const ammo = this.player.ammoByWeapon[wid];
    if (!ammo) return;

    const needed = stats.magSize - ammo.mag;
    if (wDef.infiniteReserve) {
      ammo.mag = stats.magSize;
    } else {
      const taken = Math.min(needed, ammo.reserve);
      ammo.mag += taken;
      ammo.reserve -= taken;
    }
    this.player.reloading = false;
    this.emitHud();
  }

  private fireCurrentWeapon(): void {
    const p = this.player;
    const wid = p.equippedWeapon;
    const wDef = WEAPONS[wid];
    const stats = this.getPlayerWeaponStats(wid);
    const ammo = p.ammoByWeapon[wid];
    if (!ammo) return;

    if (ammo.mag <= 0) {
      if (wDef.infiniteReserve || ammo.reserve > 0) {
        this.triggerReload();
      } else {
        soundStudio.playEmptyClick();
        p.fireCooldown = 0.35;
        // Auto-switch back to pistol if out of ammo completely
        if (wid !== 'pistol') {
          this.addFloatingText(p.x, p.y - 20, 'NO AMMO!', '#f87171', 1);
        }
      }
      return;
    }

    ammo.mag--;
    p.fireCooldown = 1 / stats.fireRate;
    p.weaponRecoilKick = Math.min(7, stats.recoil * 0.75);
    p.muzzleFlashTimer = 0.065;

    const muzzleDist = 16;
    const mx = p.x + Math.cos(p.aimAngle) * muzzleDist;
    const my = p.y - 2 + Math.sin(p.aimAngle) * muzzleDist;

    for (let i = 0; i < wDef.pellets; i++) {
      const angle = p.aimAngle + (Math.random() - 0.5) * stats.spread * 2;
      const spdVar = wDef.isFlame ? 0.8 + Math.random() * 0.35 : 0.96 + Math.random() * 0.08;
      this.bullets.push({
        x: mx,
        y: my,
        prevX: mx,
        prevY: my,
        vx: Math.cos(angle) * wDef.bulletSpeed * spdVar,
        vy: Math.sin(angle) * wDef.bulletSpeed * spdVar,
        damage: stats.damage,
        rangeLeft: stats.range * (wDef.isFlame ? 0.75 + Math.random() * 0.35 : 1),
        pierceLeft: wDef.pierce,
        hitIds: new Set<number>(),
        color: wDef.bulletColor,
        splashRadius: wDef.splashRadius,
        isFlame: Boolean(wDef.isFlame),
        isPlasma: Boolean(wDef.isPlasma),
        fromEnemy: false,
        radius: wDef.isFlame ? 7 : wDef.isPlasma ? 5 : 2.5,
      });
    }

    // Dynamic muzzle flash light & sparks
    this.dynamicLights.push({
      x: mx,
      y: my,
      radius: wDef.isPlasma ? 105 : wDef.id === 'sniper' || wDef.id === 'shotgun' ? 115 : 80,
      color: wDef.muzzleColor,
      alpha: 0.9,
      life: 0.075,
      maxLife: 0.075,
    });

    // Brass shell casing ejection (for ballistic guns)
    if (!wDef.isFlame && !wDef.isPlasma) {
      const ejectAngle = p.aimAngle + (p.facingLeft ? -1.4 : 1.4) + (Math.random() - 0.5) * 0.4;
      this.particles.push({
        x: p.x + Math.cos(p.aimAngle) * 6,
        y: p.y - 2 + Math.sin(p.aimAngle) * 6,
        vx: Math.cos(ejectAngle) * (42 + Math.random() * 28),
        vy: Math.sin(ejectAngle) * (42 + Math.random() * 28) - 20,
        size: 2,
        color: wid === 'shotgun' ? '#d93829' : '#f2c94c',
        alpha: 1,
        life: 0.55,
        maxLife: 0.55,
        gravity: 130,
        drag: 2.5,
      });
    }

    // Gunsmoke puff
    for (let s = 0; s < (wid === 'shotgun' ? 4 : 2); s++) {
      this.particles.push({
        x: mx,
        y: my,
        vx: Math.cos(p.aimAngle + (Math.random() - 0.5) * 0.6) * (35 + Math.random() * 45),
        vy: Math.sin(p.aimAngle + (Math.random() - 0.5) * 0.6) * (35 + Math.random() * 45),
        size: wDef.isFlame ? 5 : 3,
        color: wDef.isFlame ? '#ff9f2e' : wDef.isPlasma ? '#6bf8ff' : '#cbd5e1',
        alpha: 0.65,
        life: 0.22,
        maxLife: 0.22,
        drag: 5,
      });
    }

    // Camera recoil shake
    if (this.saveData.settings.screenShake) {
      this.shakeMag = Math.max(this.shakeMag, Math.min(8, stats.recoil * 0.55));
    }

    soundStudio.playShoot(wid);

    // Alert nearby ambient zombies to gunfire
    for (const z of this.zombies) {
      if (!z.alerted && Math.hypot(z.x - p.x, z.y - p.y) < 380) {
        z.alerted = true;
      }
    }

    // Auto-reload when magazine hits 0
    if (ammo.mag === 0 && (wDef.infiniteReserve || ammo.reserve > 0)) {
      this.triggerReload();
    }
  }

  private interactNearbyCrate(): void {
    for (const prop of this.world.props) {
      if (prop.type === 'crate' && !prop.destroyed) {
        if (Math.hypot(prop.x - this.player.x, prop.y - this.player.y) < 42) {
          this.breakCrate(prop);
          return;
        }
      }
    }
  }

  private updateWaveDirector(dt: number): void {
    if (this.inIntermission) {
      this.intermissionTimer -= dt;
      if (this.intermissionTimer <= 0) {
        this.beginWave(this.wave + 1);
      }
      return;
    }

    // Spawn queued wave zombies smoothly without overwhelming frame budget
    if (this.waveZombiesToSpawn.length > 0) {
      this.waveSpawnTimer -= dt;
      const activeWaveCount = this.zombies.filter((z) => z.isWaveZombie).length;
      if (this.waveSpawnTimer <= 0 && activeWaveCount < 38) {
        const nextType = this.waveZombiesToSpawn.shift()!;
        this.spawnWaveZombie(nextType);
        this.waveSpawnTimer = Math.max(0.32, 1.35 - this.wave * 0.07);
      }
    } else {
      // Check if all wave zombies have been eliminated
      const remaining = this.zombies.filter((z) => z.isWaveZombie).length;
      if (remaining === 0) {
        this.completeWave();
      }
    }
  }

  private updateZombies(dt: number): void {
    const p = this.player;

    for (let i = this.zombies.length - 1; i >= 0; i--) {
      const z = this.zombies[i];
      if (z.hurtFlash > 0) z.hurtFlash = Math.max(0, z.hurtFlash - dt);
      if (z.attackCooldown > 0) z.attackCooldown -= dt;
      if (z.attackAnim > 0) z.attackAnim = Math.max(0, z.attackAnim - dt);

      // Fire burn DoT from Flamethrower
      if (z.burnTimer > 0) {
        z.burnTimer -= dt;
        z.burnTick -= dt;
        if (Math.random() < 0.35) {
          this.particles.push({
            x: z.x + (Math.random() - 0.5) * 12,
            y: z.y - 4 + (Math.random() - 0.5) * 10,
            vx: (Math.random() - 0.5) * 16,
            vy: -24 - Math.random() * 20,
            size: 3,
            color: Math.random() < 0.5 ? '#ff7b1c' : '#ffd43b',
            alpha: 0.9,
            life: 0.25,
            maxLife: 0.25,
          });
        }
        if (z.burnTick <= 0) {
          z.burnTick = 0.35;
          this.damageZombie(z, 9, 0, 0, true);
          if (z.hp <= 0) {
            this.zombies.splice(i, 1);
            continue;
          }
        }
      }

      const dx = p.x - z.x;
      const dy = p.y - z.y;
      const dist = Math.hypot(dx, dy);

      if (!z.alerted && dist < 245) {
        z.alerted = true;
        soundStudio.playZombieSound(z.type, false);
      }
      if (!z.alerted) continue;

      // Occasional atmospheric zombie groan
      if (dist < 280 && Math.random() < 0.002) {
        soundStudio.playZombieSound(z.type, false);
      }

      const dirX = dist > 0.01 ? dx / dist : 0;
      const dirY = dist > 0.01 ? dy / dist : 0;
      z.facingLeft = dirX < 0;

      // Giant Boss special shockwave slam mechanic!
      if (z.type === 'giant') {
        if (z.slamTelegraph > 0) {
          z.slamTelegraph -= dt;
          if (z.slamTelegraph <= 0) {
            this.triggerBossSlam(z);
          }
          continue;
        }
        z.slamCooldown -= dt;
        if (z.slamCooldown <= 0 && dist < 130) {
          z.slamTelegraph = 0.65;
          z.slamCooldown = z.hp < z.maxHp * 0.5 ? 3.8 : 5.5;
          soundStudio.playZombieSound('giant', false);
          continue;
        }
      }

      // Mutant Spitter ranged acid attack!
      if (z.type === 'mutant') {
        z.spitCooldown -= dt;
        if (z.spitCooldown <= 0 && dist < 270 && dist > 65) {
          z.spitCooldown = 2.6 + Math.random() * 0.8;
          z.attackAnim = 0.25;
          const aim = Math.atan2(dy, dx);
          this.bullets.push({
            x: z.x + Math.cos(aim) * 12,
            y: z.y + Math.sin(aim) * 12,
            prevX: z.x,
            prevY: z.y,
            vx: Math.cos(aim) * 245,
            vy: Math.sin(aim) * 245,
            damage: z.damage,
            rangeLeft: 320,
            pierceLeft: 0,
            hitIds: new Set<number>(),
            color: '#9eff3d',
            splashRadius: 20,
            isFlame: false,
            isPlasma: false,
            fromEnemy: true,
            radius: 4.5,
          });
          soundStudio.playZombieSound('mutant', false);
        }
      }

      // Separation force so zombies fan out naturally around the player
      let sepX = 0;
      let sepY = 0;
      for (let j = 0; j < this.zombies.length; j++) {
        if (i === j) continue;
        const other = this.zombies[j];
        const ox = z.x - other.x;
        const oy = z.y - other.y;
        const od = Math.hypot(ox, oy);
        const minGap = z.radius + other.radius + 4;
        if (od > 0.01 && od < minGap) {
          const push = (minGap - od) / minGap;
          sepX += (ox / od) * push * 85;
          sepY += (oy / od) * push * 85;
        }
      }

      // Mutants hover around medium range; Boss speeds up when enraged (<50% HP)
      let moveFactor = 1;
      if (z.type === 'mutant' && dist < 155) moveFactor = -0.35;
      if (z.type === 'giant' && z.hp < z.maxHp * 0.5) moveFactor = 1.32;

      const targetVx = dirX * z.speed * moveFactor + sepX;
      const targetVy = dirY * z.speed * moveFactor + sepY;
      z.vx += (targetVx - z.vx) * Math.min(1, dt * 8);
      z.vy += (targetVy - z.vy) * Math.min(1, dt * 8);

      const prevX = z.x;
      const prevY = z.y;
      this.moveCircleWithCollisions(z, z.vx * dt, z.vy * dt);

      // Gentle obstacle detour nudge if blocked by wall corner
      if (Math.hypot(z.x - prevX, z.y - prevY) < z.speed * dt * 0.25 && dist > z.attackRange + 8) {
        const perpX = -dirY * z.speed * 0.9;
        const perpY = dirX * z.speed * 0.9;
        this.moveCircleWithCollisions(z, perpX * dt, perpY * dt);
      }

      z.animTime += dt * (z.type === 'fast' ? 11 : z.type === 'heavy' || z.type === 'giant' ? 5 : 7);

      // Melee bite / smash check
      if (dist <= z.attackRange + p.radius && z.attackCooldown <= 0) {
        z.attackCooldown = z.type === 'fast' ? 0.72 : z.type === 'giant' ? 1.25 : 0.98;
        z.attackAnim = 0.28;
        this.damagePlayer(z.damage, false);
        soundStudio.playZombieSound(z.type, false);
      }
    }
  }

  private triggerBossSlam(boss: ZombieEntity): void {
    const slamRadius = 115;
    soundStudio.playExplosion();
    if (this.saveData.settings.screenShake) {
      this.shakeMag = Math.max(this.shakeMag, 12);
    }
    this.shockwaves.push({
      x: boss.x,
      y: boss.y,
      radius: 14,
      maxRadius: slamRadius,
      color: '#ff4d4d',
      life: 0.45,
      maxLife: 0.45,
    });
    for (let k = 0; k < 22; k++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 70 + Math.random() * 140;
      this.particles.push({
        x: boss.x,
        y: boss.y,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        size: 4,
        color: k % 2 === 0 ? '#a89f91' : '#ef4444',
        alpha: 0.9,
        life: 0.45,
        maxLife: 0.45,
        drag: 3,
      });
    }
    const dist = Math.hypot(this.player.x - boss.x, this.player.y - boss.y);
    if (dist < slamRadius) {
      this.damagePlayer(Math.round(boss.damage * 1.15), false);
    }
  }

  private updateBullets(dt: number): void {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.prevX = b.x;
      b.prevY = b.y;
      const stepX = b.vx * dt;
      const stepY = b.vy * dt;
      b.x += stepX;
      b.y += stepY;
      b.rangeLeft -= Math.hypot(stepX, stepY);

      if (b.isFlame && Math.random() < 0.65) {
        this.particles.push({
          x: b.x + (Math.random() - 0.5) * 6,
          y: b.y + (Math.random() - 0.5) * 6,
          vx: b.vx * 0.15,
          vy: b.vy * 0.15 - 12,
          size: 4 + Math.random() * 3,
          color: Math.random() < 0.4 ? '#ffef6b' : Math.random() < 0.75 ? '#ff7b1c' : '#d9381e',
          alpha: 0.85,
          life: 0.18,
          maxLife: 0.18,
        });
      }

      if (b.rangeLeft <= 0 || b.x < 0 || b.y < 0 || b.x > WORLD_SIZE || b.y > WORLD_SIZE) {
        if (b.isPlasma) this.triggerPlasmaSplash(b.x, b.y, b.damage * 0.75, b.splashRadius);
        this.bullets.splice(i, 1);
        continue;
      }

      // Check solid wall collisions
      let wallHit = false;
      for (const w of this.world.staticWalls) {
        if (b.x >= w.x && b.x <= w.x + w.w && b.y >= w.y && b.y <= w.y + w.h) {
          wallHit = true;
          break;
        }
      }
      if (wallHit) {
        this.spawnImpactSparks(b.x, b.y, b.isPlasma ? '#48f5ff' : '#e2e8f0', 5);
        if (b.isPlasma) this.triggerPlasmaSplash(b.x, b.y, b.damage * 0.75, b.splashRadius);
        this.bullets.splice(i, 1);
        continue;
      }

      // Enemy acid spit hitting player
      if (b.fromEnemy) {
        if (Math.hypot(b.x - this.player.x, b.y - this.player.y) < this.player.radius + b.radius) {
          this.damagePlayer(b.damage, false);
          this.spawnImpactSparks(b.x, b.y, '#9eff3d', 8);
          this.bullets.splice(i, 1);
        }
        continue;
      }

      // Player bullet hitting shootable props (crates, explosive barrels, trees/rocks)
      let propStopped = false;
      for (const prop of this.world.props) {
        if (prop.destroyed || !prop.blocksBullets) continue;
        if (Math.hypot(b.x - prop.x, b.y - prop.y) < prop.radius + b.radius) {
          if (prop.type === 'barrel' && prop.hp !== undefined) {
            prop.hp -= b.damage;
            this.spawnImpactSparks(b.x, b.y, '#ff9f2e', 5);
            if (prop.hp <= 0) {
              this.explodeBarrel(prop);
            }
            propStopped = true;
            break;
          } else if (prop.type === 'crate' && prop.hp !== undefined) {
            prop.hp -= b.damage;
            this.spawnImpactSparks(b.x, b.y, '#c2945f', 5);
            if (prop.hp <= 0) {
              this.breakCrate(prop);
            }
            propStopped = true;
            break;
          } else if (prop.type === 'rock' || prop.type === 'stalagmite' || prop.type === 'jeep') {
            this.spawnImpactSparks(b.x, b.y, '#cbd5e1', 4);
            propStopped = true;
            break;
          }
        }
      }
      if (propStopped) {
        if (b.isPlasma) this.triggerPlasmaSplash(b.x, b.y, b.damage * 0.75, b.splashRadius);
        this.bullets.splice(i, 1);
        continue;
      }

      // Player bullet hitting zombies
      let removeBullet = false;
      for (let zi = this.zombies.length - 1; zi >= 0; zi--) {
        const z = this.zombies[zi];
        if (b.hitIds.has(z.id)) continue;
        if (Math.hypot(b.x - z.x, b.y - z.y) <= z.radius + b.radius + 2) {
          b.hitIds.add(z.id);
          const kbDirX = b.vx / Math.max(1, Math.hypot(b.vx, b.vy));
          const kbDirY = b.vy / Math.max(1, Math.hypot(b.vx, b.vy));

          // 14% critical hit chance!
          const isCrit = !b.isFlame && Math.random() < 0.14;
          const finalDmg = isCrit ? Math.round(b.damage * 1.5) : b.damage;

          if (b.isFlame) {
            z.burnTimer = Math.max(z.burnTimer, 2.4);
          }

          this.damageZombie(z, finalDmg, kbDirX * 14, kbDirY * 14, false, isCrit);
          if (z.hp <= 0) {
            this.zombies.splice(zi, 1);
          }

          if (b.isPlasma) {
            this.triggerPlasmaSplash(b.x, b.y, b.damage * 0.65, b.splashRadius);
          }

          if (b.pierceLeft > 0) {
            b.pierceLeft--;
          } else {
            removeBullet = true;
            break;
          }
        }
      }

      if (removeBullet) {
        this.bullets.splice(i, 1);
      }
    }
  }

  private triggerPlasmaSplash(x: number, y: number, dmg: number, radius: number): void {
    this.shockwaves.push({
      x,
      y,
      radius: 6,
      maxRadius: radius,
      color: '#48f5ff',
      life: 0.25,
      maxLife: 0.25,
    });
    this.dynamicLights.push({
      x,
      y,
      radius: radius * 1.8,
      color: '#38e8ff',
      alpha: 0.95,
      life: 0.18,
      maxLife: 0.18,
    });
    for (let k = 0; k < 12; k++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 40 + Math.random() * 110;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        size: 3,
        color: k % 2 === 0 ? '#48f5ff' : '#ffffff',
        alpha: 1,
        life: 0.28,
        maxLife: 0.28,
        drag: 4,
      });
    }
    for (let zi = this.zombies.length - 1; zi >= 0; zi--) {
      const z = this.zombies[zi];
      const d = Math.hypot(z.x - x, z.y - y);
      if (d <= radius + z.radius) {
        this.damageZombie(z, Math.round(dmg * (1 - d / (radius + 45))), 0, 0, true);
        if (z.hp <= 0) this.zombies.splice(zi, 1);
      }
    }
  }

  private updateGrenades(dt: number): void {
    for (let i = this.grenades.length - 1; i >= 0; i--) {
      const g = this.grenades[i];
      g.fuse -= dt;

      const nx = g.x + g.vx * dt;
      const ny = g.y + g.vy * dt;

      // Bounce gently off walls
      let hitX = false;
      let hitY = false;
      for (const w of this.world.staticWalls) {
        if (nx > w.x - 4 && nx < w.x + w.w + 4 && g.y > w.y - 4 && g.y < w.y + w.h + 4) hitX = true;
        if (g.x > w.x - 4 && g.x < w.x + w.w + 4 && ny > w.y - 4 && ny < w.y + w.h + 4) hitY = true;
      }
      if (hitX) g.vx *= -0.5;
      else g.x = nx;
      if (hitY) g.vy *= -0.5;
      else g.y = ny;

      g.vz -= 420 * dt;
      g.z += g.vz * dt;
      if (g.z < 0) {
        g.z = 0;
        g.vz = -g.vz * 0.42;
        g.vx *= 0.65;
        g.vy *= 0.65;
      }

      if (g.fuse <= 0) {
        this.createExplosion(g.x, g.y, GRENADE_CONFIG.radius, GRENADE_CONFIG.damage);
        this.grenades.splice(i, 1);
      }
    }
  }

  private createExplosion(x: number, y: number, radius: number, damage: number): void {
    soundStudio.playExplosion();
    if (this.saveData.settings.screenShake) {
      this.shakeMag = Math.max(this.shakeMag, 14);
    }

    this.shockwaves.push({
      x,
      y,
      radius: 10,
      maxRadius: radius,
      color: '#ff922b',
      life: 0.38,
      maxLife: 0.38,
    });

    this.dynamicLights.push({
      x,
      y,
      radius: radius * 2.1,
      color: '#ff8a24',
      alpha: 1,
      life: 0.32,
      maxLife: 0.32,
    });

    // Pixel crater scorch mark
    this.decals.push({
      x,
      y,
      size: 26,
      color: '#1b1817',
      alpha: 0.65,
      life: 24,
    });

    // Multi-layer pixel explosion fire + dark smoke
    const pCount = this.saveData.settings.quality === 'high' ? 36 : 20;
    for (let k = 0; k < pCount; k++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 30 + Math.random() * 195;
      const isSmoke = k > pCount * 0.65;
      this.particles.push({
        x: x + (Math.random() - 0.5) * 14,
        y: y + (Math.random() - 0.5) * 14,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd - (isSmoke ? 25 : 0),
        size: isSmoke ? 6 + Math.random() * 4 : 4 + Math.random() * 4,
        color: isSmoke
          ? '#33363b'
          : k % 3 === 0
          ? '#fff3a1'
          : k % 3 === 1
          ? '#ff922b'
          : '#e03131',
        alpha: 1,
        life: isSmoke ? 0.7 : 0.38,
        maxLife: isSmoke ? 0.7 : 0.38,
        drag: isSmoke ? 2.5 : 4.5,
      });
    }

    // Damage zombies in blast radius
    for (let zi = this.zombies.length - 1; zi >= 0; zi--) {
      const z = this.zombies[zi];
      const d = Math.hypot(z.x - x, z.y - y);
      if (d <= radius + z.radius) {
        const falloff = Math.max(0.35, 1 - d / (radius + 30));
        const nx = (z.x - x) / Math.max(1, d);
        const ny = (z.y - y) / Math.max(1, d);
        this.damageZombie(z, Math.round(damage * falloff), nx * 36, ny * 36, false);
        if (z.hp <= 0) this.zombies.splice(zi, 1);
      }
    }

    // Chain-detonate nearby red barrels & smash crates!
    for (const prop of this.world.props) {
      if (prop.destroyed) continue;
      const d = Math.hypot(prop.x - x, prop.y - y);
      if (d < radius * 0.95) {
        if (prop.type === 'barrel') {
          prop.hp = 0;
          setTimeout(() => {
            if (!prop.destroyed) this.explodeBarrel(prop);
          }, 90);
        } else if (prop.type === 'crate') {
          this.breakCrate(prop);
        }
      }
    }

    // Light self-damage if player stands right on top of blast
    const pDist = Math.hypot(this.player.x - x, this.player.y - y);
    if (pDist < radius * 0.55) {
      this.damagePlayer(18, false);
    }
  }

  private explodeBarrel(barrel: WorldProp): void {
    if (barrel.destroyed) return;
    barrel.destroyed = true;
    barrel.solid = false;
    barrel.blocksBullets = false;
    this.createExplosion(barrel.x, barrel.y, 136, 225);
  }

  private breakCrate(crate: WorldProp): void {
    if (crate.destroyed) return;
    crate.destroyed = true;
    crate.solid = false;
    crate.blocksBullets = false;
    soundStudio.playPickup('crate');

    // Wood splinters
    for (let i = 0; i < 14; i++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 40 + Math.random() * 90;
      this.particles.push({
        x: crate.x,
        y: crate.y,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        size: 3,
        color: i % 2 === 0 ? '#9c7143' : '#6e4c2a',
        alpha: 1,
        life: 0.45,
        maxLife: 0.45,
        drag: 4,
      });
    }

    // Zone-themed rich crate loot!
    const z = crate.zone;
    this.spawnPickup('coin', crate.x, crate.y, z === 'caves' || z === 'virus_zone' ? 35 : 18);
    if (z === 'hospital') {
      this.spawnPickup('medkit', crate.x + 8, crate.y, 50);
    } else if (z === 'ammo_depot') {
      this.spawnPickup('ammo', crate.x + 8, crate.y, 2);
      if (Math.random() < 0.45) this.spawnPickup('grenade', crate.x - 8, crate.y, 1);
    } else if (z === 'military') {
      this.spawnPickup('ammo', crate.x + 8, crate.y, 1);
      this.spawnPickup('grenade', crate.x - 8, crate.y, 1);
    } else {
      const r = Math.random();
      if (r < 0.35) this.spawnPickup('medkit', crate.x + 8, crate.y, 40);
      else if (r < 0.75) this.spawnPickup('ammo', crate.x + 8, crate.y, 1);
      else this.spawnPickup('grenade', crate.x + 8, crate.y, 1);
    }

    if (Math.random() < 0.5) {
      this.spawnPickup('scrap', crate.x - 6, crate.y + 6, 5);
    }
  }

  private damageZombie(
    z: ZombieEntity,
    dmg: number,
    kbX: number,
    kbY: number,
    silent = false,
    isCrit = false
  ): void {
    z.hp -= dmg;
    z.hurtFlash = 0.1;
    z.alerted = true;

    // Heavy & Boss zombies resist knockback
    const kbResist = z.type === 'giant' ? 0.1 : z.type === 'heavy' ? 0.35 : 1.0;
    if (kbX !== 0 || kbY !== 0) {
      this.moveCircleWithCollisions(z, kbX * kbResist * 0.25, kbY * kbResist * 0.25);
    }

    // Stylized pixel blood/ichor droplets
    const dropletColor = z.type === 'mutant' ? '#7dff3b' : '#a81c22';
    const count = silent ? 2 : 5;
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 30 + Math.random() * 85;
      this.particles.push({
        x: z.x,
        y: z.y,
        vx: Math.cos(a) * spd + kbX * 1.4,
        vy: Math.sin(a) * spd + kbY * 1.4,
        size: 2 + Math.floor(Math.random() * 2),
        color: i % 2 === 0 ? dropletColor : '#6e1116',
        alpha: 0.9,
        life: 0.28,
        maxLife: 0.28,
        drag: 5,
      });
    }

    // Floating pixel damage number
    this.addFloatingText(
      z.x + (Math.random() - 0.5) * 10,
      z.y - z.radius - 8,
      isCrit ? `${dmg}!` : `${dmg}`,
      isCrit ? '#ffd94a' : '#f8fafc',
      isCrit ? 1.15 : 0.9
    );

    if (z.hp <= 0) {
      this.onZombieKilled(z);
    }
  }

  private onZombieKilled(z: ZombieEntity): void {
    this.kills++;
    this.score += z.scoreReward;
    soundStudio.playZombieSound(z.type, true);

    // Non-graphic stylized pixel splatter decal
    this.decals.push({
      x: z.x,
      y: z.y + 4,
      size: z.type === 'giant' ? 24 : 11,
      color: z.type === 'mutant' ? '#499e22' : '#63151a',
      alpha: 0.55,
      life: 16,
    });

    // Mutant leaves temporary glowing toxic puddle on death!
    if (z.type === 'mutant') {
      this.decals.push({
        x: z.x,
        y: z.y + 4,
        size: 32,
        color: '#6df533',
        alpha: 0.48,
        life: 6.5,
        isToxic: true,
        radius: 26,
      });
    }

    // Spawn reward pickups
    if (z.type === 'giant') {
      // Boss loot explosion!
      for (let c = 0; c < 6; c++) {
        this.spawnPickup('coin', z.x, z.y, Math.round(z.coinReward / 6));
      }
      this.spawnPickup('medkit', z.x, z.y, 60);
      this.spawnPickup('ammo', z.x, z.y, 2);
      this.spawnPickup('grenade', z.x, z.y, 2);
      this.showBanner(
        'TITAN BOSS DEFEATED! MASSIVE REWARD!',
        'زامبی غول‌پیکر نابود شد! پاداش ویژه دریافت کنید!',
        '#facc15',
        3.5
      );
    } else {
      if (Math.random() < 0.72) {
        this.spawnPickup('coin', z.x, z.y, z.coinReward);
      }
      const dropRoll = Math.random();
      if (dropRoll < 0.14) this.spawnPickup('ammo', z.x, z.y, 1);
      else if (dropRoll < 0.23) this.spawnPickup('medkit', z.x, z.y, 32);
      else if (dropRoll < 0.28) this.spawnPickup('scrap', z.x, z.y, 3);
      else if (dropRoll < 0.31) this.spawnPickup('grenade', z.x, z.y, 1);
    }

    // Persist total kill stat smoothly
    this.callbacks.onSaveProgress((prev) => ({
      ...prev,
      totalKills: prev.totalKills + 1,
      bestScore: Math.max(prev.bestScore, this.score),
    }));
  }

  private damagePlayer(dmg: number, fromToxic: boolean): void {
    const p = this.player;
    if (p.invulnTimer > 0 && !fromToxic) return;
    p.hp = Math.max(0, p.hp - dmg);
    p.hurtFlash = 0.22;
    if (!fromToxic) p.invulnTimer = 0.45;
    this.damagedScreenFlash = Math.min(0.85, this.damagedScreenFlash + 0.55);

    if (this.saveData.settings.screenShake && !fromToxic) {
      this.shakeMag = Math.max(this.shakeMag, 7);
    }

    soundStudio.playPlayerHurt();
    this.addFloatingText(p.x, p.y - 20, `-${dmg}`, '#f87171', 1.1);

    if (p.hp <= 0) {
      this.handleGameOver();
    }
  }

  private handleGameOver(): void {
    this.paused = true;
    soundStudio.setMusicMode('menu');
    this.callbacks.onSaveProgress((prev) => ({
      ...prev,
      bestWave: Math.max(prev.bestWave, this.wave),
      bestScore: Math.max(prev.bestScore, this.score),
      activeRun: null,
    }));
    this.callbacks.onGameOver({
      wave: this.wave,
      kills: this.kills,
      score: this.score,
      timeSurvived: Math.round(this.timeSurvived),
    });
  }

  private spawnPickup(
    type: PickupItem['type'],
    x: number,
    y: number,
    value: number,
    weaponId?: WeaponId
  ): void {
    const isWeaponDrop = type === 'weapon_drop';
    const angle = Math.random() * Math.PI * 2;
    const spd = isWeaponDrop ? 0 : 32 + Math.random() * 48;
    this.pickups.push({
      id: `pk_${this.nextEntityId++}`,
      type,
      x,
      y,
      vx: Math.cos(angle) * spd,
      vy: Math.sin(angle) * spd,
      value,
      weaponId,
      life: isWeaponDrop ? 99999 : 55,
      bobOffset: Math.random() * Math.PI * 2,
    });
  }

  private updatePickups(dt: number): void {
    const p = this.player;
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const item = this.pickups[i];
      item.life -= dt;
      if (item.life <= 0) {
        this.pickups.splice(i, 1);
        continue;
      }

      item.x += item.vx * dt;
      item.y += item.vy * dt;
      item.vx *= Math.max(0, 1 - dt * 6);
      item.vy *= Math.max(0, 1 - dt * 6);

      const dx = p.x - item.x;
      const dy = p.y - item.y;
      const dist = Math.hypot(dx, dy);

      // Gentle magnetic pull when close
      if (dist < 62 && dist > 1) {
        item.x += (dx / dist) * 190 * dt;
        item.y += (dy / dist) * 190 * dt;
      }

      if (dist < p.radius + 14) {
        this.collectPickup(item);
        this.pickups.splice(i, 1);
      }
    }
  }

  private collectPickup(item: PickupItem): void {
    const p = this.player;
    if (item.type === 'coin') {
      this.callbacks.onSaveProgress((prev) => ({ ...prev, coins: prev.coins + item.value }));
      soundStudio.playPickup('coin');
      this.addFloatingText(p.x, p.y - 18, `+${item.value} 🪙`, '#ffd94a', 0.95);
    } else if (item.type === 'scrap') {
      this.callbacks.onSaveProgress((prev) => ({ ...prev, scrap: prev.scrap + item.value }));
      soundStudio.playPickup('coin');
      this.addFloatingText(p.x, p.y - 18, `+${item.value} SCRAP`, '#93c5fd', 0.9);
    } else if (item.type === 'medkit') {
      const healed = Math.min(p.maxHp - p.hp, item.value);
      p.hp = Math.min(p.maxHp, p.hp + item.value);
      soundStudio.playPickup('medkit');
      this.addFloatingText(
        p.x,
        p.y - 20,
        healed > 0 ? `+${Math.round(healed)} HP` : 'MAX HP',
        '#4ade80',
        1.05
      );
    } else if (item.type === 'grenade') {
      p.grenades = Math.min(GRENADE_CONFIG.maxCarry, p.grenades + item.value);
      soundStudio.playPickup('ammo');
      this.addFloatingText(p.x, p.y - 20, `+${item.value} FRAG`, '#fbbf24', 1.0);
    } else if (item.type === 'ammo') {
      // Refill reserve for currently equipped gun (or all owned non-infinite guns!)
      let granted = 0;
      for (const wid of this.saveData.unlockedWeapons) {
        const w = WEAPONS[wid];
        if (w.infiniteReserve) continue;
        const a = p.ammoByWeapon[wid];
        if (!a) continue;
        const add = Math.round(w.magSize * (wid === p.equippedWeapon ? 1.5 : 0.75) * item.value);
        a.reserve = Math.min(w.maxReserve, a.reserve + add);
        if (wid === p.equippedWeapon) granted = add;
      }
      soundStudio.playPickup('ammo');
      this.addFloatingText(
        p.x,
        p.y - 20,
        granted > 0 ? `+${granted} AMMO` : '+AMMO',
        '#fcd34d',
        1.0
      );
    } else if (item.type === 'weapon_drop' && item.weaponId) {
      const wid = item.weaponId;
      const wDef = WEAPONS[wid];
      const alreadyOwned = this.saveData.unlockedWeapons.includes(wid);
      soundStudio.playPickup('buy');
      if (!alreadyOwned) {
        const stats = this.getPlayerWeaponStats(wid);
        this.player.ammoByWeapon[wid] = {
          mag: stats.magSize,
          reserve: wDef.startReserve,
        };
        this.player.equippedWeapon = wid;
        this.player.reloading = false;
        this.callbacks.onSaveProgress((prev) => ({
          ...prev,
          unlockedWeapons: prev.unlockedWeapons.includes(wid)
            ? prev.unlockedWeapons
            : [...prev.unlockedWeapons, wid],
        }));
        this.showBanner(
          `WEAPON DISCOVERED: ${wDef.nameEn.toUpperCase()}!`,
          `سلاح جدید کشف شد: ${wDef.nameFa}!`,
          '#38e8ff',
          4.0
        );
        this.addFloatingText(p.x, p.y - 24, `+${wDef.nameEn.toUpperCase()}`, '#38e8ff', 1.15);
      } else {
        const a = p.ammoByWeapon[wid];
        if (a && !wDef.infiniteReserve) {
          a.reserve = Math.min(wDef.maxReserve, a.reserve + wDef.magSize * 2);
        }
        this.callbacks.onSaveProgress((prev) => ({ ...prev, coins: prev.coins + 35 }));
        this.addFloatingText(p.x, p.y - 22, '+AMMO & +35 COINS', '#38e8ff', 1.05);
      }
    }
    this.emitHud();
  }

  private updateParticlesAndEffects(dt: number): void {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const pt = this.particles[i];
      pt.life -= dt;
      if (pt.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      if (pt.gravity) pt.vy += pt.gravity * dt;
      if (pt.drag) {
        pt.vx *= Math.max(0, 1 - pt.drag * dt);
        pt.vy *= Math.max(0, 1 - pt.drag * dt);
      }
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.alpha = Math.max(0, pt.life / pt.maxLife);
    }

    for (let i = this.decals.length - 1; i >= 0; i--) {
      this.decals[i].life -= dt;
      if (this.decals[i].life <= 0) this.decals.splice(i, 1);
    }

    for (let i = this.texts.length - 1; i >= 0; i--) {
      const ft = this.texts[i];
      ft.life -= dt;
      ft.y += ft.vy * dt;
      if (ft.life <= 0) this.texts.splice(i, 1);
    }

    for (let i = this.dynamicLights.length - 1; i >= 0; i--) {
      const dl = this.dynamicLights[i];
      dl.life -= dt;
      if (dl.life <= 0) this.dynamicLights.splice(i, 1);
    }

    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.life -= dt;
      const prog = 1 - sw.life / sw.maxLife;
      sw.radius = sw.maxRadius * prog;
      if (sw.life <= 0) this.shockwaves.splice(i, 1);
    }
  }

  private updateCamera(dt: number): void {
    const p = this.player;
    const lookAhead = 28;
    const targetX = p.x + Math.cos(p.aimAngle) * lookAhead;
    const targetY = p.y + Math.sin(p.aimAngle) * lookAhead;

    this.camX += (targetX - this.camX) * Math.min(1, dt * 8);
    this.camY += (targetY - this.camY) * Math.min(1, dt * 8);

    const halfW = this.viewW / (2 * this.zoom);
    const halfH = this.viewH / (2 * this.zoom);
    this.camX = Math.max(halfW, Math.min(WORLD_SIZE - halfW, this.camX));
    this.camY = Math.max(halfH, Math.min(WORLD_SIZE - halfH, this.camY));

    if (this.shakeMag > 0) {
      this.shakeMag = Math.max(0, this.shakeMag - dt * 36);
    }
  }

  private moveCircleWithCollisions(
    ent: { x: number; y: number; radius: number },
    dx: number,
    dy: number
  ): void {
    // Separate X and Y axis resolution for butter-smooth wall sliding
    const tryMove = (nx: number, ny: number): boolean => {
      if (nx < 100 || nx > WORLD_SIZE - 100 || ny < 100 || ny > WORLD_SIZE - 100) return false;
      if (!this.world.isWalkable(nx, ny)) return false;

      for (const w of this.world.staticWalls) {
        if (circleIntersectsRect(nx, ny, ent.radius, w)) return false;
      }
      for (const prop of this.world.props) {
        if (!prop.solid || prop.destroyed) continue;
        const minD = ent.radius + prop.radius;
        const pdx = nx - prop.x;
        const pdy = ny - prop.y;
        if (pdx * pdx + pdy * pdy < minD * minD) return false;
      }
      return true;
    };

    if (dx !== 0 && tryMove(ent.x + dx, ent.y)) {
      ent.x += dx;
    }
    if (dy !== 0 && tryMove(ent.x, ent.y + dy)) {
      ent.y += dy;
    }
  }

  private findNearestZombie(x: number, y: number, maxRange: number): ZombieEntity | null {
    let best: ZombieEntity | null = null;
    let bestD = maxRange;
    for (const z of this.zombies) {
      const d = Math.hypot(z.x - x, z.y - y);
      if (d < bestD) {
        bestD = d;
        best = z;
      }
    }
    return best;
  }

  private spawnImpactSparks(x: number, y: number, color: string, count: number): void {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const spd = 40 + Math.random() * 90;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * spd,
        vy: Math.sin(a) * spd,
        size: 2,
        color,
        alpha: 1,
        life: 0.2,
        maxLife: 0.2,
        drag: 6,
      });
    }
  }

  private addFloatingText(x: number, y: number, text: string, color: string, scale = 1): void {
    this.texts.push({
      x,
      y,
      vy: -28,
      text,
      color,
      life: 0.78,
      maxLife: 0.78,
      scale,
    });
  }

  private showBanner(textEn: string, textFa: string, color: string, dur: number): void {
    this.statusBanner = { textEn, textFa, color, id: this.bannerId++ };
    this.bannerTimer = dur;
    this.emitHud();
  }

  private saveProgressSnapshot(): void {
    this.callbacks.onSaveProgress((prev) => ({
      ...prev,
      bestWave: Math.max(prev.bestWave, this.wave),
      bestScore: Math.max(prev.bestScore, this.score),
      activeRun: this.getActiveRunSnapshot(),
    }));
  }

  private emitHud(): void {
    const p = this.player;
    const wid = p.equippedWeapon;
    const wDef = WEAPONS[wid];
    const stats = this.getPlayerWeaponStats(wid);
    const ammo = p.ammoByWeapon[wid] || { mag: 0, reserve: 0 };

    const bossEntity = this.zombies.find((z) => z.type === 'giant') || null;
    const activeWaveZombies =
      this.waveZombiesToSpawn.length + this.zombies.filter((z) => z.isWaveZombie).length;

    let nearbyCrate = false;
    for (const prop of this.world.props) {
      if (prop.type === 'crate' && !prop.destroyed) {
        if (Math.hypot(prop.x - p.x, prop.y - p.y) < 42) {
          nearbyCrate = true;
          break;
        }
      }
    }

    this.callbacks.onHudUpdate({
      hp: Math.round(p.hp),
      maxHp: p.maxHp,
      stamina: Math.round(p.stamina),
      maxStamina: p.maxStamina,
      coins: this.saveData.coins,
      scrap: this.saveData.scrap,
      kills: this.kills,
      score: this.score,
      wave: this.wave,
      waveZombiesRemaining: activeWaveZombies,
      waveTotalZombies: this.waveTotalZombies,
      intermissionSeconds: Math.ceil(Math.max(0, this.intermissionTimer)),
      inIntermission: this.inIntermission,
      zone: p.currentZone,
      equippedWeapon: wid,
      unlockedWeapons: this.saveData.unlockedWeapons,
      mag: ammo.mag,
      magSize: stats.magSize,
      reserve: ammo.reserve,
      infiniteReserve: Boolean(wDef.infiniteReserve),
      reloading: p.reloading,
      reloadProgress: p.reloading
        ? Math.max(0, Math.min(1, 1 - p.reloadTimer / Math.max(0.1, p.reloadDuration)))
        : 0,
      grenades: p.grenades,
      boss: bossEntity
        ? {
            nameEn: 'ISLAND TITAN BOSS',
            nameFa: 'زامبی غول‌پیکر جزیره',
            hp: Math.max(0, Math.round(bossEntity.hp)),
            maxHp: bossEntity.maxHp,
          }
        : null,
      timeSurvived: Math.round(this.timeSurvived),
      statusBanner: this.statusBanner,
      damagedFlash: this.damagedScreenFlash,
      inToxicSludge: p.inToxicSludge,
      isSprinting: p.isSprinting,
      nearbyCrate,
    });
  }

  // ======================================================
  // HIGH-CRAFT PIXEL ART CANVAS RENDERER
  // ======================================================
  private render(): void {
    const ctx = this.ctx;
    ctx.imageSmoothingEnabled = false;

    const shakeX = this.shakeMag > 0.1 ? (Math.random() - 0.5) * this.shakeMag : 0;
    const shakeY = this.shakeMag > 0.1 ? (Math.random() - 0.5) * this.shakeMag : 0;

    // Clear with deep ocean navy
    ctx.fillStyle = '#0e3552';
    ctx.fillRect(0, 0, this.viewW, this.viewH);

    ctx.save();
    ctx.translate(
      Math.round(this.viewW / 2 + shakeX),
      Math.round(this.viewH / 2 + shakeY)
    );
    ctx.scale(this.zoom, this.zoom);
    ctx.translate(-Math.round(this.camX), -Math.round(this.camY));

    const viewLeft = this.camX - this.viewW / (2 * this.zoom) - 80;
    const viewRight = this.camX + this.viewW / (2 * this.zoom) + 80;
    const viewTop = this.camY - this.viewH / (2 * this.zoom) - 80;
    const viewBottom = this.camY + this.viewH / (2 * this.zoom) + 80;

    // 1. Pre-baked Pixel Terrain Chunks
    const cMinX = Math.max(0, Math.floor(viewLeft / CHUNK_SIZE));
    const cMaxX = Math.min(CHUNKS_PER_AXIS - 1, Math.floor(viewRight / CHUNK_SIZE));
    const cMinY = Math.max(0, Math.floor(viewTop / CHUNK_SIZE));
    const cMaxY = Math.min(CHUNKS_PER_AXIS - 1, Math.floor(viewBottom / CHUNK_SIZE));
    for (let cy = cMinY; cy <= cMaxY; cy++) {
      for (let cx = cMinX; cx <= cMaxX; cx++) {
        ctx.drawImage(this.world.terrainChunks[cy][cx], cx * CHUNK_SIZE, cy * CHUNK_SIZE);
      }
    }

    // 2. Animated Shoreline Foam & Ocean Sparkles
    this.renderAnimatedWater(ctx, viewLeft, viewRight, viewTop, viewBottom);

    // 3. Animated Toxic Pool Bubbles
    for (const tp of this.world.toxicPools) {
      if (tp.x + tp.radius < viewLeft || tp.x - tp.radius > viewRight || tp.y + tp.radius < viewTop || tp.y - tp.radius > viewBottom) {
        continue;
      }
      for (let b = 0; b < 3; b++) {
        const phase = (this.globalTime * 1.4 + b * 2.1 + tp.x * 0.03) % 1;
        const bx = tp.x + Math.cos(b * 2.2 + tp.y) * tp.radius * 0.48;
        const by = tp.y + Math.sin(b * 2.2 + tp.x) * tp.radius * 0.48;
        ctx.fillStyle = `rgba(210, 255, 130, ${1 - phase})`;
        const sz = 2 + Math.floor(phase * 4);
        ctx.fillRect(Math.round(bx - sz / 2), Math.round(by - sz / 2), sz, sz);
      }
    }

    // 4. Ground Decals (blood splatters, scorch craters, mutant acid)
    for (const d of this.decals) {
      if (d.x < viewLeft || d.x > viewRight || d.y < viewTop || d.y > viewBottom) continue;
      ctx.globalAlpha = Math.min(d.alpha, d.life * 0.4);
      ctx.fillStyle = d.color;
      if (d.isToxic) {
        const r = d.radius || 22;
        ctx.beginPath();
        ctx.arc(d.x, d.y, r, 0, Math.PI * 2);
        ctx.fill();
      } else {
        const s = d.size;
        ctx.fillRect(Math.round(d.x - s / 2), Math.round(d.y - s / 3), s, Math.round(s * 0.65));
        ctx.fillRect(Math.round(d.x - s / 3), Math.round(d.y - s / 2), Math.round(s * 0.65), s);
      }
    }
    ctx.globalAlpha = 1;

    // 5. Building Walls (3/4 extruded walls with front facade shading)
    for (const b of this.world.buildings) {
      if (b.x + b.w < viewLeft || b.x > viewRight || b.y + b.h < viewTop || b.y > viewBottom) continue;
      this.renderBuildingWalls(ctx, b);
    }

    // 6. Pickups (with bob animation + golden glow)
    this.renderPickups(ctx, viewLeft, viewRight, viewTop, viewBottom);

    // 7. Y-Sorted Entities & Props (Authentic 3/4 pixel depth!)
    interface Renderable {
      sortY: number;
      draw: () => void;
    }
    const renderables: Renderable[] = [];

    for (const prop of this.world.props) {
      if (prop.destroyed) continue;
      if (prop.x < viewLeft || prop.x > viewRight || prop.y < viewTop || prop.y > viewBottom) continue;
      renderables.push({
        sortY: prop.y,
        draw: () => this.renderProp(ctx, prop),
      });
    }

    for (const z of this.zombies) {
      if (z.x < viewLeft || z.x > viewRight || z.y < viewTop || z.y > viewBottom) continue;
      renderables.push({
        sortY: z.y,
        draw: () => this.renderZombie(ctx, z),
      });
    }

    renderables.push({
      sortY: this.player.y,
      draw: () => this.renderPlayer(ctx),
    });

    renderables.sort((a, b) => a.sortY - b.sortY);
    for (const item of renderables) {
      item.draw();
    }

    // 8. Building Roofs (fade smoothly when player enters!)
    for (const b of this.world.buildings) {
      if (b.x + b.w < viewLeft || b.x > viewRight || b.y + b.h < viewTop || b.y > viewBottom) continue;
      const alpha = this.buildingRoofAlpha[b.id] ?? 1;
      if (alpha > 0.05) {
        this.renderBuildingRoof(ctx, b, alpha);
      }
    }

    // 9. Bullets, Tracers, Grenades, Shockwaves & Particles
    this.renderProjectilesAndVfx(ctx);

    // 10. Floating Damage & Pickup Numbers
    ctx.textAlign = 'center';
    for (const ft of this.texts) {
      const alpha = Math.max(0, ft.life / ft.maxLife);
      ctx.globalAlpha = alpha;
      ctx.font = `bold ${Math.round(9 * ft.scale)}px "Silkscreen", monospace`;
      ctx.fillStyle = '#090d11';
      ctx.fillText(ft.text, Math.round(ft.x) + 1, Math.round(ft.y) + 1);
      ctx.fillStyle = ft.color;
      ctx.fillText(ft.text, Math.round(ft.x), Math.round(ft.y));
    }
    ctx.globalAlpha = 1;

    ctx.restore();

    // 11. Dynamic Lighting, Shadows & Tactical Flashlight Overlay
    this.renderDynamicLighting();

    // 12. Red Damage Vignette Flash
    if (this.damagedScreenFlash > 0.02) {
      const grad = ctx.createRadialGradient(
        this.viewW / 2,
        this.viewH / 2,
        this.viewH * 0.25,
        this.viewW / 2,
        this.viewH / 2,
        Math.max(this.viewW, this.viewH) * 0.65
      );
      grad.addColorStop(0, 'rgba(220, 38, 38, 0)');
      grad.addColorStop(1, `rgba(200, 20, 20, ${this.damagedScreenFlash * 0.65})`);
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, this.viewW, this.viewH);
    }

    // 13. Tactical Minimap (top-right corner)
    if (this.saveData.settings.showMinimap) {
      this.renderMinimap(ctx);
    }

    // 14. Crisp Pixel Crosshair (Desktop)
    if (this.hasMouseMoved && !this.paused) {
      this.renderCrosshair(ctx);
    }
  }

  private renderAnimatedWater(
    ctx: CanvasRenderingContext2D,
    left: number,
    right: number,
    top: number,
    bottom: number
  ): void {
    const waveT = this.globalTime * 2.2;
    const step = 36;
    const startX = Math.floor(left / step) * step;
    const startY = Math.floor(top / step) * step;
    for (let y = startY; y < bottom; y += step) {
      for (let x = startX; x < right; x += step) {
        const cd = getSignedCoastDistance(x, y);
        if (cd < 20 && cd > -10) {
          // Animated shoreline surf foam
          const foam = Math.sin(waveT + x * 0.04 + y * 0.04);
          if (foam > 0.15) {
            ctx.fillStyle = 'rgba(235, 252, 255, 0.75)';
            ctx.fillRect(Math.round(x + foam * 4), Math.round(y), 10, 3);
          }
        } else if (cd <= -10) {
          // Ocean shimmer crest
          const ripple = Math.sin(waveT * 0.8 + x * 0.03 - y * 0.02);
          if (ripple > 0.72) {
            ctx.fillStyle = 'rgba(130, 210, 240, 0.38)';
            ctx.fillRect(Math.round(x), Math.round(y), 12, 2);
          }
        }
      }
    }
  }

  private renderBuildingWalls(ctx: CanvasRenderingContext2D, b: Building): void {
    const wallTop =
      b.floorType === 'hospital'
        ? '#9aa8a6'
        : b.floorType === 'wood'
        ? '#5c3b24'
        : b.floorType === 'stone'
        ? '#393f4f'
        : '#4c5450';
    const wallSide =
      b.floorType === 'hospital'
        ? '#687876'
        : b.floorType === 'wood'
        ? '#3b2415'
        : b.floorType === 'stone'
        ? '#212530'
        : '#2d3330';

    for (const w of b.walls) {
      // Shadow drop
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.fillRect(w.x + 3, w.y + 4, w.w, w.h);
      // Dark outline
      ctx.fillStyle = '#111518';
      ctx.fillRect(w.x - 1, w.y - 1, w.w + 2, w.h + 2);
      // Wall facade
      ctx.fillStyle = wallSide;
      ctx.fillRect(w.x, w.y, w.w, w.h);
      // Top bevel
      ctx.fillStyle = wallTop;
      ctx.fillRect(w.x + 1, w.y + 1, Math.max(1, w.w - 2), Math.max(1, w.h - 5));
    }
  }

  private renderBuildingRoof(ctx: CanvasRenderingContext2D, b: Building, alpha: number): void {
    ctx.save();
    ctx.globalAlpha = alpha;
    // Roof shadow
    ctx.fillStyle = 'rgba(0,0,0,0.32)';
    ctx.fillRect(b.x + 6, b.y + 8, b.w, b.h);
    // Outer trim
    ctx.fillStyle = '#12161a';
    ctx.fillRect(b.x - 2, b.y - 2, b.w + 4, b.h + 4);
    ctx.fillStyle = b.roofTrim;
    ctx.fillRect(b.x, b.y, b.w, b.h);
    // Main roof plating / shingles
    ctx.fillStyle = b.roofColor;
    ctx.fillRect(b.x + 6, b.y + 6, b.w - 12, b.h - 12);

    // Corrugated / plank lines
    ctx.fillStyle = 'rgba(0,0,0,0.16)';
    for (let y = b.y + 14; y < b.y + b.h - 8; y += 12) {
      ctx.fillRect(b.x + 6, y, b.w - 12, 2);
    }

    // Center ridge highlight
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    ctx.fillRect(b.x + 6, b.y + Math.floor(b.h / 2) - 2, b.w - 12, 4);

    // Landmark roof insignia
    if (b.hasCross) {
      const cx = b.x + Math.floor(b.w / 2);
      const cy = b.y + Math.floor(b.h / 2);
      ctx.fillStyle = '#eef5f5';
      ctx.fillRect(cx - 22, cy - 22, 44, 44);
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(cx - 6, cy - 16, 12, 32);
      ctx.fillRect(cx - 16, cy - 6, 32, 12);
    } else if (b.hasHazard) {
      for (let x = b.x + 12; x < b.x + b.w - 20; x += 20) {
        ctx.fillStyle = '#eab308';
        ctx.fillRect(x, b.y + b.h - 16, 10, 6);
      }
    }

    if (b.labelEn) {
      ctx.font = 'bold 8px "Silkscreen", monospace';
      ctx.textAlign = 'center';
      ctx.fillStyle = 'rgba(10,14,18,0.85)';
      ctx.fillText(b.labelEn, b.x + b.w / 2 + 1, b.y + 22 + 1);
      ctx.fillStyle = '#f8fafc';
      ctx.fillText(b.labelEn, b.x + b.w / 2, b.y + 22);
    }

    ctx.restore();
  }

  private renderProp(ctx: CanvasRenderingContext2D, prop: WorldProp): void {
    let spr: HTMLCanvasElement | null = null;
    let anchorY = 0.85;
    let shadowW = prop.radius * 1.9;
    let shadowH = prop.radius * 0.9;

    switch (prop.type) {
      case 'palm':
        spr = this.atlas.props.palm[prop.variant % 2];
        anchorY = 0.88;
        shadowW = 30;
        shadowH = 14;
        break;
      case 'jungle_tree':
        spr = this.atlas.props.jungle_tree[prop.variant % 2];
        anchorY = 0.88;
        shadowW = 34;
        shadowH = 16;
        break;
      case 'dead_tree':
        spr = this.atlas.props.dead_tree;
        anchorY = 0.88;
        shadowW = 24;
        shadowH = 11;
        break;
      case 'rock':
        spr = this.atlas.props.rock[prop.variant % 2];
        anchorY = 0.78;
        break;
      case 'stalagmite':
        spr = this.atlas.props.stalagmite;
        anchorY = 0.85;
        break;
      case 'crystal':
        spr = this.atlas.props.crystal;
        anchorY = 0.82;
        break;
      case 'bush':
        spr = this.atlas.props.bush[prop.variant % 2];
        anchorY = 0.76;
        break;
      case 'fern':
        spr = this.atlas.props.fern;
        anchorY = 0.7;
        shadowW = 0;
        break;
      case 'sandbag':
        spr = this.atlas.props.sandbag;
        anchorY = 0.78;
        shadowW = 26;
        shadowH = 8;
        break;
      case 'jeep':
        spr = this.atlas.props.jeep;
        anchorY = 0.65;
        shadowW = 54;
        shadowH = 22;
        break;
      case 'bed':
        spr = this.atlas.props.bed;
        anchorY = 0.65;
        shadowW = 28;
        shadowH = 12;
        break;
      case 'barrel':
        spr = this.atlas.props.barrel;
        anchorY = 0.82;
        break;
      case 'crate':
        spr = this.atlas.props.crate[prop.hp && prop.maxHp && prop.hp < prop.maxHp * 0.6 ? 1 : 0];
        anchorY = 0.78;
        break;
      case 'lantern':
        spr = this.atlas.props.lantern;
        anchorY = 0.88;
        break;
      case 'bio_sign':
        spr = this.atlas.props.bio_sign;
        anchorY = 0.88;
        break;
      case 'boat_wreck':
        spr = this.atlas.props.boat_wreck;
        anchorY = 0.7;
        shadowW = 42;
        shadowH = 16;
        break;
    }

    if (!spr) return;

    // Grounded soft pixel shadow
    if (shadowW > 0) {
      ctx.fillStyle = 'rgba(6, 12, 14, 0.34)';
      ctx.beginPath();
      ctx.ellipse(prop.x + 2, prop.y + 3, shadowW * 0.5, shadowH * 0.5, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Subtle tropical palm breeze sway
    const sway =
      prop.type === 'palm' || prop.type === 'jungle_tree'
        ? Math.sin(this.globalTime * 1.8 + prop.x * 0.02) * 1.2
        : 0;

    ctx.drawImage(
      spr,
      Math.round(prop.x - spr.width / 2 + sway),
      Math.round(prop.y - spr.height * anchorY)
    );

    // Glowing highlight beacon on crates so players spot loot intuitively
    if (prop.type === 'crate') {
      const pulse = 0.4 + Math.sin(this.globalTime * 4 + prop.x) * 0.35;
      ctx.fillStyle = `rgba(250, 204, 21, ${pulse})`;
      ctx.fillRect(Math.round(prop.x - 1), Math.round(prop.y - 20), 2, 4);
    }
  }

  private renderPickups(
    ctx: CanvasRenderingContext2D,
    left: number,
    right: number,
    top: number,
    bottom: number
  ): void {
    const coinFrame = Math.floor(this.globalTime * 8) % 4;
    for (const item of this.pickups) {
      if (item.x < left || item.x > right || item.y < top || item.y > bottom) continue;
      const bob = Math.sin(this.globalTime * 5 + item.bobOffset) * 2.5;
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.beginPath();
      ctx.ellipse(item.x, item.y + 5, 6, 3, 0, 0, Math.PI * 2);
      ctx.fill();

      if (item.type === 'weapon_drop' && item.weaponId) {
        const pulse = 0.5 + Math.sin(this.globalTime * 5) * 0.35;
        ctx.strokeStyle = `rgba(56, 232, 255, ${pulse})`;
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(item.x, item.y + 4, 15, 7, 0, 0, Math.PI * 2);
        ctx.stroke();

        const wSpr = this.atlas.weapons[item.weaponId];
        ctx.drawImage(
          wSpr,
          Math.round(item.x - wSpr.width / 2),
          Math.round(item.y - wSpr.height / 2 - 5 + bob)
        );
        ctx.font = 'bold 6px "Silkscreen", monospace';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#090f14';
        ctx.fillText(item.weaponId.toUpperCase(), Math.round(item.x) + 1, Math.round(item.y - 12 + bob) + 1);
        ctx.fillStyle = '#38e8ff';
        ctx.fillText(item.weaponId.toUpperCase(), Math.round(item.x), Math.round(item.y - 12 + bob));
        continue;
      }

      let spr: HTMLCanvasElement = this.atlas.pickups.coin[coinFrame];
      if (item.type === 'medkit') spr = this.atlas.pickups.medkit;
      else if (item.type === 'ammo') spr = this.atlas.pickups.ammo;
      else if (item.type === 'grenade') spr = this.atlas.pickups.grenade;
      else if (item.type === 'scrap') spr = this.atlas.pickups.scrap;

      ctx.drawImage(spr, Math.round(item.x - spr.width / 2), Math.round(item.y - spr.height / 2 - 2 + bob));
    }
  }

  private renderZombie(ctx: CanvasRenderingContext2D, z: ZombieEntity): void {
    const set = this.atlas.zombies[z.type];
    let spr: HTMLCanvasElement;
    if (z.hurtFlash > 0) spr = set.hurt;
    else if (z.attackAnim > 0) spr = set.attack;
    else spr = set.walk[Math.floor(z.animTime) % 4];

    const scale = z.type === 'giant' ? 1.45 : 1.15;
    const drawW = Math.round(spr.width * scale);
    const drawH = Math.round(spr.height * scale);

    // Boss slam warning telegraph circle on ground
    if (z.type === 'giant' && z.slamTelegraph > 0) {
      const prog = 1 - z.slamTelegraph / 0.65;
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.9)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(z.x, z.y, 115, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = `rgba(239, 68, 68, ${0.12 + prog * 0.28})`;
      ctx.beginPath();
      ctx.arc(z.x, z.y, 115 * prog, 0, Math.PI * 2);
      ctx.fill();
    }

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.38)';
    ctx.beginPath();
    ctx.ellipse(z.x, z.y + 4, z.radius * 0.95, z.radius * 0.48, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.save();
    ctx.translate(Math.round(z.x), Math.round(z.y));
    if (z.facingLeft) ctx.scale(-1, 1);
    ctx.drawImage(spr, Math.round(-drawW / 2), Math.round(-drawH + 6), drawW, drawH);
    ctx.restore();

    // Compact pixel HP bar above damaged zombies
    if (z.hp < z.maxHp) {
      const bw = z.type === 'giant' ? 40 : z.type === 'heavy' ? 24 : 18;
      const bh = z.type === 'giant' ? 4 : 3;
      const bx = Math.round(z.x - bw / 2);
      const by = Math.round(z.y - drawH + 1);
      ctx.fillStyle = '#0d1117';
      ctx.fillRect(bx - 1, by - 1, bw + 2, bh + 2);
      ctx.fillStyle = z.type === 'giant' ? '#ef4444' : z.type === 'mutant' ? '#84cc16' : '#dc2626';
      ctx.fillRect(bx, by, Math.max(1, Math.round((bw * z.hp) / z.maxHp)), bh);
    }
  }

  private renderPlayer(ctx: CanvasRenderingContext2D): void {
    const p = this.player;
    const set = this.atlas.characters[p.characterId];
    let spr: HTMLCanvasElement;
    if (p.hurtFlash > 0) spr = set.hurt;
    else if (!p.isMoving) spr = set.walk[0];
    else if (p.isSprinting) spr = set.run[Math.floor(p.animTime) % 4];
    else spr = set.walk[Math.floor(p.animTime) % 4];

    const scale = 1.2;
    const drawW = Math.round(spr.width * scale);
    const drawH = Math.round(spr.height * scale);

    // Shadow
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath();
    ctx.ellipse(p.x, p.y + 4, 9, 4.5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Sniper subtle laser sight line
    if (p.equippedWeapon === 'sniper' && !p.reloading) {
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.35)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y - 3);
      ctx.lineTo(p.x + Math.cos(p.aimAngle) * 280, p.y - 3 + Math.sin(p.aimAngle) * 280);
      ctx.stroke();
    }

    // Survivor pixel body
    ctx.save();
    ctx.translate(Math.round(p.x), Math.round(p.y));
    if (p.facingLeft) ctx.scale(-1, 1);
    ctx.drawImage(spr, Math.round(-drawW / 2), Math.round(-drawH + 6), drawW, drawH);
    ctx.restore();

    // Equipped Pixel Weapon held at shoulder & rotated smoothly toward aim!
    const wSpr = this.atlas.weapons[p.equippedWeapon];
    ctx.save();
    ctx.translate(Math.round(p.x), Math.round(p.y - 4));
    ctx.rotate(p.aimAngle);
    if (p.facingLeft) ctx.scale(1, -1);
    const kick = p.weaponRecoilKick;
    ctx.drawImage(wSpr, Math.round(-4 - kick), -5, 22, 9);

    // Crisp pixel muzzle flash star!
    if (p.muzzleFlashTimer > 0) {
      const wDef = WEAPONS[p.equippedWeapon];
      ctx.fillStyle = wDef.muzzleColor;
      ctx.fillRect(17 - kick, -3, 6, 5);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(18 - kick, -2, 3, 3);
    }
    ctx.restore();

    // In-world reload progress bar right above survivor's head
    if (p.reloading) {
      const prog = Math.max(0, Math.min(1, 1 - p.reloadTimer / Math.max(0.1, p.reloadDuration)));
      const bw = 24;
      const bx = Math.round(p.x - bw / 2);
      const by = Math.round(p.y - drawH - 3);
      ctx.fillStyle = '#0d1117';
      ctx.fillRect(bx - 1, by - 1, bw + 2, 5);
      ctx.fillStyle = '#facc15';
      ctx.fillRect(bx, by, Math.round(bw * prog), 3);
    }
  }

  private renderProjectilesAndVfx(ctx: CanvasRenderingContext2D): void {
    // Shockwave rings
    for (const sw of this.shockwaves) {
      ctx.globalAlpha = Math.max(0, sw.life / sw.maxLife);
      ctx.strokeStyle = sw.color;
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(sw.x, sw.y, sw.radius, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // Bullets & trails
    for (const b of this.bullets) {
      if (b.isFlame) {
        ctx.fillStyle = '#ff922b';
        ctx.fillRect(Math.round(b.x - 3), Math.round(b.y - 3), 6, 6);
        ctx.fillStyle = '#fff3a1';
        ctx.fillRect(Math.round(b.x - 1), Math.round(b.y - 1), 3, 3);
      } else if (b.isPlasma) {
        ctx.strokeStyle = '#38e8ff';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(b.prevX, b.prevY);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(Math.round(b.x - 2), Math.round(b.y - 2), 4, 4);
      } else if (b.fromEnemy) {
        ctx.fillStyle = '#3f8a1d';
        ctx.fillRect(Math.round(b.x - 4), Math.round(b.y - 4), 8, 8);
        ctx.fillStyle = '#b4ff4d';
        ctx.fillRect(Math.round(b.x - 2), Math.round(b.y - 2), 4, 4);
      } else {
        ctx.strokeStyle = b.color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(b.prevX, b.prevY);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(Math.round(b.x - 1), Math.round(b.y - 1), 2, 2);
      }
    }

    // Thrown Frag Grenades
    for (const g of this.grenades) {
      ctx.fillStyle = 'rgba(0,0,0,0.4)';
      ctx.beginPath();
      ctx.ellipse(g.x, g.y + 3, 5, 2.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.drawImage(this.atlas.grenade, Math.round(g.x - 5), Math.round(g.y - 6 - g.z));
      // Blinking danger indicator
      if (Math.floor(g.fuse * 14) % 2 === 0) {
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(Math.round(g.x - 1), Math.round(g.y - 9 - g.z), 3, 3);
      }
    }

    // Pixel Particles
    for (const pt of this.particles) {
      ctx.globalAlpha = pt.alpha;
      ctx.fillStyle = pt.color;
      ctx.fillRect(Math.round(pt.x - pt.size / 2), Math.round(pt.y - pt.size / 2), pt.size, pt.size);
    }
    ctx.globalAlpha = 1;
  }

  private renderDynamicLighting(): void {
    const lctx = this.lightCtx;
    const lw = this.lightCanvas.width;
    const lh = this.lightCanvas.height;
    const scaleX = lw / this.viewW;
    const scaleY = lh / this.viewH;

    // Atmospheric wave darkness cycle + Cave / Virus Zone mood
    const waveMood = [0.22, 0.34, 0.52, 0.44, 0.58][(this.wave - 1) % 5];
    const inCave = this.world.isInCaveArea(this.player.x, this.player.y);
    const inVirus = this.player.currentZone === 'virus_zone';
    const darkness = inCave ? 0.72 : inVirus ? Math.max(waveMood, 0.48) : waveMood;

    if (darkness < 0.08 && this.saveData.settings.quality === 'medium') return;

    lctx.globalCompositeOperation = 'source-over';
    lctx.clearRect(0, 0, lw, lh);
    lctx.fillStyle = inCave
      ? `rgba(8, 12, 22, ${darkness})`
      : inVirus
      ? `rgba(12, 24, 14, ${darkness})`
      : `rgba(8, 15, 24, ${darkness})`;
    lctx.fillRect(0, 0, lw, lh);

    const worldToLight = (wx: number, wy: number) => ({
      x: ((wx - this.camX) * this.zoom + this.viewW / 2) * scaleX,
      y: ((wy - this.camY) * this.zoom + this.viewH / 2) * scaleY,
    });

    const punchRadial = (wx: number, wy: number, worldRadius: number, strength = 1) => {
      const pos = worldToLight(wx, wy);
      const r = worldRadius * this.zoom * scaleX;
      if (pos.x + r < 0 || pos.x - r > lw || pos.y + r < 0 || pos.y - r > lh) return;
      const g = lctx.createRadialGradient(pos.x, pos.y, r * 0.1, pos.x, pos.y, r);
      g.addColorStop(0, `rgba(0,0,0,${strength})`);
      g.addColorStop(1, 'rgba(0,0,0,0)');
      lctx.fillStyle = g;
      lctx.beginPath();
      lctx.arc(pos.x, pos.y, r, 0, Math.PI * 2);
      lctx.fill();
    };

    // Punch light cutouts out of ambient darkness
    lctx.globalCompositeOperation = 'destination-out';

    // 1. Player ambient personal aura
    punchRadial(this.player.x, this.player.y, 125, 0.92);

    // 2. Player Directional Tactical Flashlight Cone!
    const pPos = worldToLight(this.player.x, this.player.y - 3);
    const coneLen = 250 * this.zoom * scaleX;
    const coneSpread = 0.42;
    const a = this.player.aimAngle;
    const coneGrad = lctx.createRadialGradient(pPos.x, pPos.y, 4, pPos.x, pPos.y, coneLen);
    coneGrad.addColorStop(0, 'rgba(0,0,0,0.95)');
    coneGrad.addColorStop(0.75, 'rgba(0,0,0,0.55)');
    coneGrad.addColorStop(1, 'rgba(0,0,0,0)');
    lctx.fillStyle = coneGrad;
    lctx.beginPath();
    lctx.moveTo(pPos.x, pPos.y);
    lctx.arc(pPos.x, pPos.y, coneLen, a - coneSpread, a + coneSpread);
    lctx.closePath();
    lctx.fill();

    // 3. Environmental Lights (Lanterns, Glowing Cave Crystals, Toxic Pools)
    const flicker = 0.92 + Math.sin(this.globalTime * 11) * 0.08;
    for (const prop of this.world.props) {
      if (prop.destroyed) continue;
      if (prop.type === 'lantern') {
        punchRadial(prop.x, prop.y - 8, 95 * flicker, 0.9);
      } else if (prop.type === 'crystal') {
        punchRadial(prop.x, prop.y - 4, 72 * flicker, 0.85);
      }
    }
    for (const tp of this.world.toxicPools) {
      punchRadial(tp.x, tp.y, tp.radius * 1.45, 0.65);
    }

    // 4. Dynamic gunshot & explosion light punches
    for (const dl of this.dynamicLights) {
      const k = dl.life / dl.maxLife;
      punchRadial(dl.x, dl.y, dl.radius, k);
    }

    // Composite lighting map over gameplay canvas
    this.ctx.save();
    this.ctx.imageSmoothingEnabled = true;
    this.ctx.drawImage(this.lightCanvas, 0, 0, this.viewW, this.viewH);

    // Subtle colored additive glow for muzzle flashes, explosions & cave crystals
    if (this.saveData.settings.quality === 'high') {
      this.ctx.globalCompositeOperation = 'lighter';
      for (const dl of this.dynamicLights) {
        const sx = (dl.x - this.camX) * this.zoom + this.viewW / 2;
        const sy = (dl.y - this.camY) * this.zoom + this.viewH / 2;
        const r = dl.radius * this.zoom * 0.65;
        const g = this.ctx.createRadialGradient(sx, sy, 2, sx, sy, r);
        g.addColorStop(0, dl.color);
        g.addColorStop(1, 'rgba(0,0,0,0)');
        this.ctx.globalAlpha = (dl.life / dl.maxLife) * 0.32;
        this.ctx.fillStyle = g;
        this.ctx.beginPath();
        this.ctx.arc(sx, sy, r, 0, Math.PI * 2);
        this.ctx.fill();
      }
    }
    this.ctx.restore();
    this.ctx.imageSmoothingEnabled = false;
  }

  private renderMinimap(ctx: CanvasRenderingContext2D): void {
    const size = this.viewW < 640 ? 96 : 126;
    const pad = 12;
    const mx = this.viewW - size - pad;
    const my = this.viewW < 640 ? 52 : 62;
    const scale = size / WORLD_SIZE;

    ctx.save();
    // Tactical pixel frame
    ctx.fillStyle = 'rgba(8, 13, 17, 0.85)';
    ctx.fillRect(mx - 4, my - 4, size + 8, size + 8);
    ctx.strokeStyle = '#3d5a4b';
    ctx.lineWidth = 2;
    ctx.strokeRect(mx - 3, my - 3, size + 6, size + 6);

    ctx.drawImage(this.world.minimapCanvas, mx, my, size, size);

    // Crates (gold dots)
    ctx.fillStyle = '#facc15';
    for (const prop of this.world.props) {
      if (prop.type === 'crate' && !prop.destroyed) {
        ctx.fillRect(mx + Math.round(prop.x * scale) - 1, my + Math.round(prop.y * scale) - 1, 2, 2);
      }
    }

    // Discoverable Island Weapon Drops (cyan diamond dots)
    ctx.fillStyle = '#38e8ff';
    for (const pk of this.pickups) {
      if (pk.type === 'weapon_drop') {
        ctx.fillRect(mx + Math.round(pk.x * scale) - 1, my + Math.round(pk.y * scale) - 1, 3, 3);
      }
    }

    // Zombies (red dots, giant boss larger pulsing marker)
    for (const z of this.zombies) {
      if (!z.alerted && Math.hypot(z.x - this.player.x, z.y - this.player.y) > 700) continue;
      const zx = mx + Math.round(z.x * scale);
      const zy = my + Math.round(z.y * scale);
      if (z.type === 'giant') {
        ctx.fillStyle = '#ff2b2b';
        ctx.fillRect(zx - 3, zy - 3, 6, 6);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;
        ctx.strokeRect(zx - 3, zy - 3, 6, 6);
      } else {
        ctx.fillStyle = z.type === 'mutant' ? '#a3e635' : '#ef4444';
        ctx.fillRect(zx - 1, zy - 1, 2, 2);
      }
    }

    // Player marker & aim tick
    const px = mx + this.player.x * scale;
    const py = my + this.player.y * scale;
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px + Math.cos(this.player.aimAngle) * 7, py + Math.sin(this.player.aimAngle) * 7);
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(Math.round(px - 2), Math.round(py - 2), 4, 4);
    ctx.restore();
  }

  private renderCrosshair(ctx: CanvasRenderingContext2D): void {
    const x = Math.round(this.mouseScreenX);
    const y = Math.round(this.mouseScreenY);
    const spreadGap = Math.round(5 + this.player.weaponRecoilKick * 1.4);

    ctx.save();
    ctx.fillStyle = '#090d11';
    ctx.fillRect(x - spreadGap - 7, y - 2, 7, 4);
    ctx.fillRect(x + spreadGap, y - 2, 7, 4);
    ctx.fillRect(x - 2, y - spreadGap - 7, 4, 7);
    ctx.fillRect(x - 2, y + spreadGap, 4, 7);

    ctx.fillStyle = this.player.reloading ? '#facc15' : '#4ade80';
    ctx.fillRect(x - spreadGap - 6, y - 1, 5, 2);
    ctx.fillRect(x + spreadGap + 1, y - 1, 5, 2);
    ctx.fillRect(x - 1, y - spreadGap - 6, 2, 5);
    ctx.fillRect(x - 1, y + spreadGap + 1, 2, 5);
    ctx.fillRect(x - 1, y - 1, 2, 2);
    ctx.restore();
  }
}

function circleIntersectsRect(cx: number, cy: number, r: number, rect: Rect): boolean {
  const closestX = Math.max(rect.x, Math.min(cx, rect.x + rect.w));
  const closestY = Math.max(rect.y, Math.min(cy, rect.y + rect.h));
  const dx = cx - closestX;
  const dy = cy - closestY;
  return dx * dx + dy * dy < r * r;
}
