import { CHARACTERS, CHARACTER_ORDER } from './characters';
import { CharacterId, WeaponId, ZombieType } from './types';
import { WEAPON_ORDER } from './weapons';

export interface CharacterSpriteSet {
  walk: HTMLCanvasElement[]; // 4 frames
  run: HTMLCanvasElement[]; // 4 frames
  hurt: HTMLCanvasElement;
}

export interface ZombieSpriteSet {
  walk: HTMLCanvasElement[]; // 4 frames
  attack: HTMLCanvasElement;
  hurt: HTMLCanvasElement;
}

export interface SpriteAtlas {
  characters: Record<CharacterId, CharacterSpriteSet>;
  zombies: Record<ZombieType, ZombieSpriteSet>;
  weapons: Record<WeaponId, HTMLCanvasElement>;
  grenade: HTMLCanvasElement;
  pickups: {
    coin: HTMLCanvasElement[];
    medkit: HTMLCanvasElement;
    ammo: HTMLCanvasElement;
    grenade: HTMLCanvasElement;
    scrap: HTMLCanvasElement;
  };
  props: {
    palm: HTMLCanvasElement[];
    jungle_tree: HTMLCanvasElement[];
    dead_tree: HTMLCanvasElement;
    rock: HTMLCanvasElement[];
    stalagmite: HTMLCanvasElement;
    crystal: HTMLCanvasElement;
    bush: HTMLCanvasElement[];
    fern: HTMLCanvasElement;
    sandbag: HTMLCanvasElement;
    jeep: HTMLCanvasElement;
    bed: HTMLCanvasElement;
    barrel: HTMLCanvasElement;
    crate: HTMLCanvasElement[];
    lantern: HTMLCanvasElement;
    bio_sign: HTMLCanvasElement;
    boat_wreck: HTMLCanvasElement;
  };
}

function makeCanvas(w: number, h: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;
  return [c, ctx];
}

function drawMatrix(
  ctx: CanvasRenderingContext2D,
  rows: string[],
  palette: Record<string, string>,
  ox = 0,
  oy = 0
) {
  for (let y = 0; y < rows.length; y++) {
    const row = rows[y];
    for (let x = 0; x < row.length; x++) {
      const ch = row[x];
      if (ch === '.' || ch === ' ') continue;
      const color = palette[ch];
      if (!color) continue;
      ctx.fillStyle = color;
      ctx.fillRect(ox + x, oy + y, 1, 1);
    }
  }
}

function makeWhiteFlash(src: HTMLCanvasElement, tint = '#ffffff'): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(src.width, src.height);
  ctx.drawImage(src, 0, 0);
  ctx.globalCompositeOperation = 'source-atop';
  ctx.fillStyle = tint;
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.globalCompositeOperation = 'source-over';
  return c;
}

// ======================================================
// CHARACTER SPRITE GENERATOR (16 x 20 px crisp pixel art)
// ======================================================
function buildCharacterFrame(
  charId: CharacterId,
  step: number,
  isRun: boolean
): HTMLCanvasElement {
  const p = CHARACTERS[charId].palette;
  const [c, ctx] = makeCanvas(16, 20);
  const pal: Record<string, string> = {
    o: '#12161c', // outline
    s: p.skin,
    S: p.skinShade,
    h: p.hair,
    g: p.headgear,
    c: p.shirt,
    C: p.shirtShade,
    v: p.vest,
    p: p.pants,
    b: p.boots,
    a: p.accent,
    e: '#161a20', // eyes
    w: '#f2f7f5', // eye/highlight
    k: '#362d26', // backpack strap
  };

  // Vertical bobbing on stride
  const bob = step === 1 || step === 3 ? -1 : 0;
  const lean = isRun ? 1 : 0;

  // Head + headgear (rows 0..8)
  const headRows = [
    '....oooooo......',
    '...oggggggo.....',
    '..ogggaggggo....',
    '..ohhsssssho....',
    '..ohseseesSo....',
    '..ohssssssSo....',
    '...oSssssSo.....',
    '....oooooo......',
  ];

  // Torso with tactical vest + backpack (rows 8..14)
  const torsoRows = [
    '..okocvvvco.....',
    '..okocvavco.....',
    '..okCCvvvCCo....',
    '...ooCvavCoo....',
    '....opppppoo....',
  ];

  // 4-frame legs animation
  const legFramesWalk = [
    ['....ooppooo.....', '....oppo.po.....', '....obbo.bo.....', '....oooo.oo.....'],
    ['...ooppoooo.....', '...oppo..ppo....', '...obbo..bbo....', '...oooo..ooo....'],
    ['....oooppo......', '....op.oppo.....', '....ob.obbo.....', '....oo.oooo.....'],
    ['....ooooppo.....', '...oppo..ppo....', '...obbo..bbo....', '...oooo..ooo....'],
  ];

  const legFramesRun = [
    ['...oopppooo.....', '..oppo...ppo....', '..obbo...bbo....', '..oooo...ooo....'],
    ['....oopppo......', '...oppo.ppo.....', '...obbo.bbo.....', '...oooo.ooo.....'],
    ['...ooopppoo.....', '..ppo...oppo....', '..bbo...obbo....', '..ooo...oooo....'],
    ['....oopppo......', '....ppooppo.....', '....bbobbo......', '....oooooo......'],
  ];

  const legs = isRun ? legFramesRun[step % 4] : legFramesWalk[step % 4];

  drawMatrix(ctx, headRows, pal, lean, 1 + bob);
  drawMatrix(ctx, torsoRows, pal, 0, 8 + bob);
  drawMatrix(ctx, legs, pal, 0, 13);

  // Subtle boot highlight
  ctx.fillStyle = 'rgba(255,255,255,0.18)';
  ctx.fillRect(5 + lean, 2 + bob, 4, 1);

  return c;
}

// ======================================================
// ZOMBIE SPRITE GENERATOR (5 DISTINCT ARCHETYPES)
// ======================================================
function buildNormalZombie(step: number, attack: boolean): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(16, 20);
  const pal: Record<string, string> = {
    o: '#11161a',
    z: '#7da870', // skin
    Z: '#56784d', // skin shade
    d: '#3e5438', // deep rot
    r: '#9e2622', // bloodstain
    e: '#e83b3b', // red eyes
    s: '#4c5f73', // torn blue shirt
    S: '#344252',
    p: '#3b3730', // tattered pants
    b: '#211e1a',
    h: '#2c3029', // matted hair
  };

  const bob = step % 2 === 1 ? -1 : 0;
  const head = [
    '....oooooo......',
    '...ohhhhhho.....',
    '..ohzzzzzzho....',
    '..ozzezzzeZo....',
    '..ozzZddZzzo....',
    '...ozZrrZzo.....',
    '....oooooo......',
  ];

  const torso = attack
    ? [
        '...oossssooo....',
        '..oSssrssszzzo..',
        '..oSssSsssZZzo..',
        '...ooSSrSSooo...',
        '....opppppo.....',
      ]
    : [
        '...oossssoo.....',
        '..oSssrssszo....',
        '..oSSsSssZZo....',
        '...ooSSrSSo.....',
        '....opppppo.....',
      ];

  const legs = [
    ['....ooppooo.....', '....oppo.po.....', '....obbo.bo.....', '....oooo.oo.....'],
    ['...ooppoooo.....', '...oppo..ppo....', '...obbo..bbo....', '...oooo..ooo....'],
    ['....oooppo......', '....op.oppo.....', '....ob.obbo.....', '....oo.oooo.....'],
    ['....ooooppo.....', '...oppo..ppo....', '...obbo..bbo....', '...oooo..ooo....'],
  ][step % 4];

  drawMatrix(ctx, head, pal, attack ? 1 : 0, 2 + bob);
  drawMatrix(ctx, torso, pal, 0, 8 + bob);
  drawMatrix(ctx, legs, pal, 0, 13);
  return c;
}

function buildFastZombie(step: number, attack: boolean): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(16, 19);
  const pal: Record<string, string> = {
    o: '#130e12',
    z: '#a3897a', // pale reddish-gray skin
    Z: '#755c50',
    r: '#c92a2a', // crimson blood
    R: '#7d1919',
    e: '#ffdd33', // glowing yellow hunter eyes
    s: '#8a3726', // torn crimson rags
    S: '#572015',
    p: '#2d2429',
    b: '#1a1317',
    h: '#241819',
  };

  const bob = step % 2 === 0 ? 0 : -1;
  const head = [
    '.....ooooo......',
    '...oohhhhho.....',
    '..ohzzzzzzho....',
    '..oZzezzzeZo....',
    '...oZrrrrZo.....',
    '....oooooo......',
  ];
  const torso = attack
    ? [
        '..ooossssooo....',
        '.oSrsrsssszzzo..',
        '..ooSRssSSZZzo..',
        '....opppppo.....',
      ]
    : [
        '..ooossssoo.....',
        '.oSrsrsssSzo....',
        '..ooSRssSSZo....',
        '....opppppo.....',
      ];

  const legs = [
    ['..oopppooo......', '.oppo...ppo.....', '.obbo...bbo.....', '.oooo...ooo.....'],
    ['...oopppoo......', '..oppo.ppo......', '..obbo.bbo......', '..oooo.ooo......'],
    ['..ooopppoo......', '.ppo...oppo.....', '.bbo...obbo.....', '.ooo...oooo.....'],
    ['...oopppoo......', '...ppooppo......', '...bbobbo.......', '...oooooo.......'],
  ][step % 4];

  drawMatrix(ctx, head, pal, 1, 2 + bob);
  drawMatrix(ctx, torso, pal, 0, 8 + bob);
  drawMatrix(ctx, legs, pal, 0, 12);
  return c;
}

function buildHeavyZombie(step: number, attack: boolean): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(20, 22);
  const pal: Record<string, string> = {
    o: '#101418',
    z: '#6e8c68',
    Z: '#4c6348',
    m: '#4a575e', // riot armor steel
    M: '#2f393e',
    a: '#697a54', // helmet olive
    A: '#434f36',
    r: '#9e2824',
    e: '#ff5252',
    p: '#2c3338',
    b: '#191d21',
  };

  const bob = step % 2 === 1 ? -1 : 0;
  const head = [
    '......oooooooo......',
    '.....oaaaaaaaao.....',
    '....oaAAaaaaAAao....',
    '....ozzezzzzzezo....',
    '....ozZZZrrZZZzo....',
    '.....oooooooooo.....',
  ];
  const torso = attack
    ? [
        '..oooommmmmmmmooo...',
        '.oMmmmMmmmmmmMzzzo..',
        '.oMmrMMmmmmmmMZZzo..',
        '.oMmmmMmmmmmmMzzzo..',
        '..oMMMmmmmmmmMMoo...',
        '...ooopppppppoo.....',
      ]
    : [
        '..oooommmmmmmmoo....',
        '.oMmmmMmmmmmmMmo....',
        '.oMmrMMmmmmmmMzo....',
        '.oMmmmMmmmmmmMZo....',
        '..oMMMmmmmmmmMMo....',
        '...ooopppppppoo.....',
      ];

  const legs = [
    ['...ooopppoopppo.....', '...opppoo.opppo.....', '...obbboo.obbbo.....', '...oooooo.ooooo.....'],
    ['..ooopppooopppo.....', '..opppoo...pppo.....', '..obbboo...bbbo.....', '..oooooo...oooo.....'],
    ['...ooopppoopppo.....', '...opppo.oopppo.....', '...obbbo.oobbbo.....', '...ooooo.oooooo.....'],
    ['...ooopppooopppo....', '..opppoo...pppo.....', '..obbboo...bbbo.....', '..oooooo...oooo.....'],
  ][step % 4];

  drawMatrix(ctx, head, pal, 0, 1 + bob);
  drawMatrix(ctx, torso, pal, 0, 7 + bob);
  drawMatrix(ctx, legs, pal, 0, 13);
  return c;
}

function buildMutantZombie(step: number, attack: boolean): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(18, 21);
  const pal: Record<string, string> = {
    o: '#0e1410',
    z: '#5a7852', // mutated skin
    Z: '#3a5235',
    g: '#9eff3d', // glowing bio-pustule bright
    G: '#5bc724', // bio mid
    v: '#6d3b8c', // purple mutated tissue
    V: '#47245e',
    e: '#c4ff3d', // glowing acid eyes
    p: '#2d362d',
    b: '#181f18',
  };

  const bob = step % 2 === 1 ? -1 : 0;
  const head = [
    '....ooooooo.......',
    '...ovvgggvvo......',
    '..ovgGzzzzzvo.....',
    '..ozzezzzzeZo.....',
    '..ozzZgggZZzo.....',
    '...oZZGggZZo......',
    '....ooooooo.......',
  ];

  const torso = attack
    ? [
        '..oovvvzzzzggoo...',
        '.ovgGvvzzgGzzggo..',
        '.ovVVvzzzGGzzGgo..',
        '..oVVzzzzzzzzoo...',
        '...ooopppppooo....',
      ]
    : [
        '..oovvvzzzzgoo....',
        '.ovgGvvzzgGzGo....',
        '.ovVVvzzzGGzZo....',
        '..oVVzzzzzzzZo....',
        '...ooopppppooo....',
      ];

  const legs = [
    ['...ooopppooppo....', '...oppo..oppo.....', '...obbo..obbo.....', '...oooo..oooo.....'],
    ['..ooopppoooppo....', '..oppo....pppo....', '..obbo....bbbo....', '..oooo....oooo....'],
    ['...ooopppooppo....', '...oppo.ooppo.....', '...obbo.oobbo.....', '...oooo.ooooo.....'],
    ['...ooopppoooppo...', '..oppo....pppo....', '..obbo....bbbo....', '..oooo....oooo....'],
  ][step % 4];

  drawMatrix(ctx, head, pal, 0, 1 + bob);
  drawMatrix(ctx, torso, pal, 0, 8 + bob);
  drawMatrix(ctx, legs, pal, 0, 13);
  return c;
}

function buildGiantBossZombie(step: number, attack: boolean): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(28, 32);
  const pal: Record<string, string> = {
    o: '#0d0c10',
    z: '#6a7d5d', // titan hide
    Z: '#46543d',
    d: '#2f3829',
    r: '#b82525', // exposed muscle/blood
    R: '#781515',
    e: '#ff2b2b', // glowing boss eyes
    w: '#ffe8a3', // bone/ribs
    m: '#6b727a', // iron chains & rebar weapon
    M: '#3d4247',
    p: '#302b28',
    b: '#1a1715',
  };

  const bob = step % 2 === 1 ? -1 : 0;

  // Massive hunched head & spiked shoulders
  const head = [
    '........oooooooooo..........',
    '.......ozzzzzzzzzzo.........',
    '......ozZzzzzzzzzZzo........',
    '......ozzZeezzeeZzzo........',
    '......ozZZZrrrrZZZzo........',
    '......ozZrwrrrrwrZzo........',
    '.......ooZZrrrrZZoo.........',
  ];

  const torso = attack
    ? [
        '...ooooozzzzzzzzzzoooo......',
        '..ozZZzzmMzzzzzzMmzzZZoo....',
        '.ozZzzZzmMrrwwrrMmzzzzZZmm..',
        '.ozZzzZzzmRwwwwRmzzzzzZZmMm.',
        '.ozZZzZzzzRrrrrRzzzzzzZZmMm.',
        '..oZZZzzzzzRrrRzzzzzZZZoMMm.',
        '...ooZZZzzzzzzzzzzZZZoo..m..',
        '....ooopppppppppppooo.......',
      ]
    : [
        '...ooooozzzzzzzzzzoooo......',
        '..ozZZzzmMzzzzzzMmzzZZoo....',
        '.ozZzzZzmMrrwwrrMmzzzzZZo...',
        '.ozZzzZzzmRwwwwRmzzzzzZZmo..',
        '.ozZZzZzzzRrrrrRzzzzzzZZmo..',
        '..oZZZzzzzzRrrRzzzzzZZZoMo..',
        '...ooZZZzzzzzzzzzzZZZoo.....',
        '....ooopppppppppppooo.......',
      ];

  const legOffsetL = step === 1 ? -2 : step === 3 ? 1 : 0;
  const legOffsetR = step === 3 ? -2 : step === 1 ? 1 : 0;

  drawMatrix(ctx, head, pal, 0, 1 + bob);
  drawMatrix(ctx, torso, pal, 0, 8 + bob);

  // Draw massive pillar legs manually for chunky animation
  const drawLeg = (x: number, y: number) => {
    ctx.fillStyle = pal.o;
    ctx.fillRect(x, y, 7, 11);
    ctx.fillStyle = pal.p;
    ctx.fillRect(x + 1, y, 5, 7);
    ctx.fillStyle = pal.Z;
    ctx.fillRect(x + 2, y + 3, 2, 2);
    ctx.fillStyle = pal.b;
    ctx.fillRect(x + 1, y + 7, 5, 3);
    ctx.fillStyle = pal.m;
    ctx.fillRect(x + 1, y + 7, 5, 1);
  };

  drawLeg(6, 17 + legOffsetL);
  drawLeg(15, 17 + legOffsetR);

  return c;
}

// ======================================================
// WEAPON SPRITE GENERATOR (SIDE PROFILE PIXEL ART)
// ======================================================
function buildWeaponSprite(id: WeaponId): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(24, 10);
  const pal: Record<string, string> = {
    o: '#0e1216',
    g: '#6d7782', // steel light
    G: '#444c54', // steel dark
    d: '#282d33', // black metal
    w: '#8c5a32', // wood stock
    W: '#5e391d', // wood dark
    a: '#d99e32', // brass/ammo accent
    r: '#c73a28', // red tank/accent
    c: '#3beeff', // plasma glow
    C: '#1a8da3',
    k: '#4a5e3d', // military olive
  };

  const matrices: Record<WeaponId, string[]> = {
    pistol: [
      '........................',
      '........................',
      '......oooooooo..........',
      '.....oggggggggo.........',
      '.....oGGGGGGddo.........',
      '.....oooddoo............',
      '.....oGdo...............',
      '.....ooo................',
      '........................',
      '........................',
    ],
    shotgun: [
      '........................',
      '........................',
      '........oooooooooooooo..',
      '..oooooogggggggggggggo..',
      '.oWWWWooGGGGGGwwwGGooo..',
      '.oWwoo..ooooddWWooo.....',
      '..oo......oGdo..........',
      '..........ooo...........',
      '........................',
      '........................',
    ],
    smg: [
      '........................',
      '.......oooo.............',
      '....oooggggooooo........',
      '...oGGgGGGGgggggo.......',
      '...oGGdGGGGddoooo.......',
      '....oooodo.odo..........',
      '.......odo.odo..........',
      '.......ooo..oo..........',
      '........................',
      '........................',
    ],
    rifle: [
      '........................',
      '.........ooo............',
      '......ooogggoooooooooo..',
      '.ooooogGGGGGGwwwwggggo..',
      '.oWWooGGGGGGGWWWWoooo...',
      '.oWwo..oodo..odo........',
      '..oo....odo...odo.......',
      '........ooo....oo.......',
      '........................',
      '........................',
    ],
    sniper: [
      '........oooooo..........',
      '.......oGggggGo.........',
      '.......ooooooooooooooo..',
      '.oooooogGGGGGGGGggggggo.',
      '.okkkkoGGGGGGddoooooooo.',
      '.okko...oodo............',
      '..oo....odo.............',
      '........ooo.............',
      '........................',
      '........................',
    ],
    lmg: [
      '........................',
      '......oooooooo..........',
      '..oooogGGGGGGgoooooooo..',
      '.oGGGogGGGGGGgggggggggo.',
      '.oGGooGaaGGGGddooooooo..',
      '..oo..oaaaooo...........',
      '......oaaao.............',
      '......ooooo.............',
      '........................',
      '........................',
    ],
    flamethrower: [
      '........................',
      '....oooooo..............',
      '...orrrrrroooooooooooo..',
      '..orrrarrrGGGGggggggao..',
      '..oRRRRRRRGGGGddddddao..',
      '...ooooooooodo...oooo...',
      '..........odo...........',
      '..........ooo...........',
      '........................',
      '........................',
    ],
    plasma: [
      '........................',
      '.....ooooooooooo........',
      '..ooogGGcccGGgggoooooo..',
      '.oGGogGcccccGggccggggo..',
      '.oGGoGGGCcCGGggccoooo...',
      '..oo..oooodo..ooo.......',
      '.........odo............',
      '.........ooo............',
      '........................',
      '........................',
    ],
  };

  drawMatrix(ctx, matrices[id], pal, 0, 0);
  return c;
}

function buildGrenadeSprite(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(10, 12);
  const pal: Record<string, string> = {
    o: '#0e1314',
    g: '#4c6e3b',
    G: '#324a26',
    l: '#7da35d',
    m: '#8f99a3',
    y: '#e8c443',
  };
  drawMatrix(ctx, [
    '....ooo...',
    '...omymo..',
    '....omo...',
    '..oooloo..',
    '.olglggGo.',
    '.ogGggGGo.',
    '.olglggGo.',
    '.ogGggGGo.',
    '..oGGGGoo.',
    '...oooo...',
  ], pal, 0, 1);
  return c;
}

// ======================================================
// PICKUP SPRITES
// ======================================================
function buildCoinFrames(): HTMLCanvasElement[] {
  const pal: Record<string, string> = {
    o: '#3b2407',
    y: '#ffd94a',
    Y: '#d9961e',
    w: '#fff8c2',
  };
  const shapes = [
    [
      '..oooo..',
      '.oywwyo.',
      'oywyyYyo',
      'oyyYyyYo',
      'oyyYyyYo',
      'oyYyyYyo',
      '.oYyyYo.',
      '..oooo..',
    ],
    [
      '...oo...',
      '..oyyo..',
      '.oywYyo.',
      '.oyyYyo.',
      '.oyyYyo.',
      '.oYyYyo.',
      '..oYYo..',
      '...oo...',
    ],
    [
      '...oo...',
      '...oyo..',
      '...owo..',
      '...oyo..',
      '...oyo..',
      '...oYo..',
      '...oYo..',
      '...oo...',
    ],
    [
      '...oo...',
      '..oyyo..',
      '.oywYyo.',
      '.oyyYyo.',
      '.oyyYyo.',
      '.oYyYyo.',
      '..oYYo..',
      '...oo...',
    ],
  ];
  return shapes.map((rows) => {
    const [c, ctx] = makeCanvas(8, 8);
    drawMatrix(ctx, rows, pal);
    return c;
  });
}

function buildMedkitSprite(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(14, 12);
  const pal: Record<string, string> = {
    o: '#161b20',
    w: '#eef5f7',
    s: '#c3d2d9',
    r: '#e63946',
    R: '#a81d29',
    g: '#63717a',
  };
  drawMatrix(ctx, [
    '....oooooo....',
    '...oggggggo...',
    '.ooowwwwwwooo.',
    'owwwwwrwwwwwwO'.replace('O', 'o'),
    'owwwwrrrwwwwso',
    'owwwrrrrrwwwso',
    'owwwwrrrwwwwso',
    'owwwwwRwwwwwso',
    'osssssssssssso',
    '.oooooooooooo.',
  ], pal, 0, 1);
  return c;
}

function buildAmmoSprite(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(14, 12);
  const pal: Record<string, string> = {
    o: '#121712',
    g: '#4f6b40',
    G: '#354a2a',
    l: '#71915b',
    y: '#f2c14e',
    Y: '#b88323',
  };
  drawMatrix(ctx, [
    '..oooooooooo..',
    '.ollllllllllo.',
    'oggggggggggggo',
    'oggyygyygyyggo',
    'oggYYgYYgYYggo',
    'oGGGGGGGGGGGG0'.replace('0', 'o'),
    'oGGggggggggGGo',
    'oGGGGGGGGGGGG0'.replace('0', 'o'),
    '.oooooooooooo.',
  ], pal, 0, 1);
  return c;
}

function buildScrapSprite(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(12, 12);
  const pal: Record<string, string> = {
    o: '#14171c',
    m: '#8f9ba6',
    M: '#5c6670',
    l: '#c4d0db',
    a: '#d98a2b',
  };
  drawMatrix(ctx, [
    '....oooo....',
    '...olmlo....',
    '.ooMmmmmMoo.',
    '.omMooooMmo.',
    'oomMoaaoMmoo',
    'omMMoaaoMMmo',
    'oomMooooMmoo',
    '.omMmmmmMmo.',
    '.ooMMMMMMoo.',
    '...oMMMMo...',
    '....oooo....',
  ], pal, 0, 0);
  return c;
}

// ======================================================
// ENVIRONMENT PROP PIXEL ART GENERATORS
// ======================================================
function buildPalmTree(variant: number): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(44, 52);

  // Curved bark trunk
  const bend = variant === 0 ? 1 : -1;
  for (let i = 0; i < 24; i++) {
    const y = 46 - i;
    const x = Math.round(21 + Math.sin(i * 0.13) * 3.5 * bend);
    const w = i < 5 ? 6 : i < 14 ? 5 : 4;
    ctx.fillStyle = '#1b1410';
    ctx.fillRect(x - 1, y, w + 2, 1);
    ctx.fillStyle = i % 3 === 0 ? '#69472c' : '#855c39';
    ctx.fillRect(x, y, w, 1);
    ctx.fillStyle = '#a3754a';
    ctx.fillRect(x, y, 1, 1);
  }

  const topX = Math.round(22 + Math.sin(24 * 0.13) * 3.5 * bend);
  const topY = 20;

  // Coconuts under crown
  const cocoPos = [
    [topX - 2, topY + 2],
    [topX + 2, topY + 2],
    [topX, topY + 4],
  ];
  for (const [cx, cy] of cocoPos) {
    ctx.fillStyle = '#24160e';
    ctx.fillRect(cx - 1, cy - 1, 4, 4);
    ctx.fillStyle = '#5c381f';
    ctx.fillRect(cx, cy, 2, 2);
  }

  // Lush pixel palm fronds (6 radiating arched fronds)
  const fronds = [
    { dx: -1, dy: -0.45, len: 18 },
    { dx: 1, dy: -0.45, len: 18 },
    { dx: -0.95, dy: 0.2, len: 17 },
    { dx: 0.95, dy: 0.2, len: 17 },
    { dx: -0.4, dy: -0.95, len: 15 },
    { dx: 0.4, dy: -0.95, len: 15 },
    { dx: 0, dy: 0.75, len: 13 },
  ];

  for (const f of fronds) {
    for (let t = 0; t <= f.len; t++) {
      const frac = t / f.len;
      const fx = Math.round(topX + f.dx * t);
      const fy = Math.round(topY + f.dy * t + frac * frac * 7);
      const leafW = Math.max(1, Math.round((1 - Math.abs(frac - 0.45) * 1.4) * 5));
      // Outline
      ctx.fillStyle = '#112618';
      ctx.fillRect(fx - 1, fy - 1, 3, leafW + 2);
      // Deep green base
      ctx.fillStyle = '#265c33';
      ctx.fillRect(fx, fy, 2, leafW);
      // Sunlit upper ridge
      ctx.fillStyle = frac < 0.65 ? '#55a646' : '#3d823b';
      ctx.fillRect(fx, fy, 2, Math.max(1, Math.floor(leafW * 0.5)));
      if (frac > 0.2 && frac < 0.55) {
        ctx.fillStyle = '#84cf55';
        ctx.fillRect(fx, fy, 1, 1);
      }
    }
  }

  return c;
}

function buildJungleTree(variant: number): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(44, 48);
  // Thick gnarled jungle trunk
  ctx.fillStyle = '#17110d';
  ctx.fillRect(17, 24, 10, 20);
  ctx.fillRect(15, 40, 14, 5);
  ctx.fillStyle = '#5c3c24';
  ctx.fillRect(18, 25, 8, 19);
  ctx.fillRect(16, 41, 12, 3);
  ctx.fillStyle = '#785234';
  ctx.fillRect(19, 26, 3, 17);

  // Layered pixel foliage clusters (not simple flat circles — textured bumpy pixel leaves!)
  const clusters =
    variant === 0
      ? [
          { x: 22, y: 18, r: 14 },
          { x: 13, y: 22, r: 10 },
          { x: 31, y: 22, r: 10 },
          { x: 22, y: 11, r: 10 },
        ]
      : [
          { x: 22, y: 19, r: 13 },
          { x: 12, y: 18, r: 9 },
          { x: 32, y: 20, r: 10 },
          { x: 24, y: 10, r: 9 },
        ];

  const drawLeafBlob = (cx: number, cy: number, r: number, color: string, pad = 0) => {
    ctx.fillStyle = color;
    for (let y = -r - pad; y <= r + pad; y++) {
      for (let x = -r - pad; x <= r + pad; x++) {
        const wobble = ((x * 7 + y * 13) & 3) === 0 ? 1 : 0;
        if (x * x + y * y <= (r + pad) * (r + pad) - wobble * 4) {
          ctx.fillRect(cx + x, cy + y, 1, 1);
        }
      }
    }
  };

  for (const cl of clusters) drawLeafBlob(cl.x, cl.y, cl.r, '#0f2115', 1);
  for (const cl of clusters) drawLeafBlob(cl.x, cl.y, cl.r, '#1f4a2a', 0);
  for (const cl of clusters) drawLeafBlob(cl.x - 1, cl.y - 2, cl.r - 2, '#347338', 0);
  for (const cl of clusters) drawLeafBlob(cl.x - 2, cl.y - 4, cl.r - 5, '#5ca343', 0);
  // Specular leaf pixel highlights
  ctx.fillStyle = '#8fd45b';
  for (const cl of clusters) {
    ctx.fillRect(cl.x - 4, cl.y - 5, 2, 1);
    ctx.fillRect(cl.x - 1, cl.y - 7, 2, 1);
    ctx.fillRect(cl.x + 2, cl.y - 4, 1, 2);
  }
  return c;
}

function buildDeadTree(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(36, 44);
  const drawBranch = (x0: number, y0: number, x1: number, y1: number, thick: number) => {
    const steps = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
    for (let i = 0; i <= steps; i++) {
      const t = steps === 0 ? 0 : i / steps;
      const x = Math.round(x0 + (x1 - x0) * t);
      const y = Math.round(y0 + (y1 - y0) * t);
      const w = Math.max(1, Math.round(thick * (1 - t * 0.55)));
      ctx.fillStyle = '#141714';
      ctx.fillRect(x - 1, y - 1, w + 2, w + 2);
      ctx.fillStyle = '#47434a';
      ctx.fillRect(x, y, w, w);
      ctx.fillStyle = '#67616b';
      ctx.fillRect(x, y, 1, 1);
    }
  };
  drawBranch(18, 40, 17, 16, 5);
  drawBranch(17, 24, 7, 12, 3);
  drawBranch(18, 22, 29, 10, 3);
  drawBranch(17, 16, 12, 5, 2);
  drawBranch(23, 16, 30, 18, 2);
  // Toxic moss spots
  ctx.fillStyle = '#7dff45';
  ctx.fillRect(16, 26, 2, 1);
  ctx.fillRect(11, 16, 2, 1);
  ctx.fillRect(25, 13, 2, 1);
  return c;
}

function buildRock(variant: number): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(24, 20);
  const pal: Record<string, string> = {
    o: '#15181f',
    l: '#8b949e',
    m: '#626b75',
    d: '#3f4750',
    g: '#4b7a44', // moss
  };
  const m0 = [
    '.......oooooooo.........',
    '.....oolllllllloo.......',
    '....olllgggglllllo......',
    '...olllggmmmmmllllo.....',
    '..olmmmmmmmmmmmmmllo....',
    '.oommmmmmddddmmmmmmo....',
    '.ommmmmddddddddmmmmdo...',
    '.ommmddddddddddddmddo...',
    '.oddddddddddddddddddo...',
    '..ooddddddddddddddoo....',
    '....oooooooooooooo......',
  ];
  const m1 = [
    '........oooooo..........',
    '......oolllllloo........',
    '....oolllmmmmlllo.......',
    '...olllmmmmmmmmllo......',
    '..olmmmmmmmdddmmmdo.....',
    '.ommmmmmmdddddddmdo.....',
    '.ommmmddddddddddddo.....',
    '..oddddddddddddddo......',
    '...oooooooooooooo.......',
  ];
  drawMatrix(ctx, variant === 0 ? m0 : m1, pal, 0, 6);
  return c;
}

function buildStalagmite(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(20, 26);
  const pal: Record<string, string> = {
    o: '#0f1218',
    l: '#7a8396',
    m: '#505766',
    d: '#2f3440',
  };
  drawMatrix(ctx, [
    '.........oo.........',
    '........olmo........',
    '........olmo........',
    '.......ollmmo.......',
    '.......olmmmo.......',
    '......ollmmmdo......',
    '......olmmmddo......',
    '.....ollmmmddo......',
    '.....olmmmdddo......',
    '....ollmmmddddo.....',
    '....olmmmdddddo.....',
    '...ollmmmddddmdo....',
    '...olmmmdddddddo....',
    '..olmmmmddddddddo...',
    '..odddddddddddddo...',
    '...ooooooooooooo....',
  ], pal, 0, 8);
  return c;
}

function buildCrystal(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(18, 22);
  const pal: Record<string, string> = {
    o: '#0c1c24',
    w: '#d6ffff',
    c: '#4df5ff',
    C: '#1ba3bf',
    d: '#125a70',
  };
  drawMatrix(ctx, [
    '........oo........',
    '.......owco.......',
    '......owcCco......',
    '....ooowcCco......',
    '...owcowcCcoo.....',
    '...ocCowcCcwco....',
    '..owcCocCdocCo....',
    '..ocCCocCdocCdo...',
    '..ocCdodCdocCdo...',
    '..odCdodddodddo...',
    '...oodddddddoo....',
    '.....ooooooo......',
  ], pal, 0, 8);
  return c;
}

function buildBush(variant: number): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(20, 16);
  const pal: Record<string, string> = {
    o: '#112416',
    d: '#1d4526',
    m: '#326e37',
    l: '#5aa646',
    b: variant === 0 ? '#e64949' : '#f2c94c', // tropical berries/flowers
  };
  drawMatrix(ctx, [
    '.....oooooooo.......',
    '...oolllmmllloo.....',
    '..ollmlmbbmllmlo....',
    '.olmmlmmmmmmmmlmo...',
    '.ommbmmmmmmmbmmmdo..',
    '.ommmmddddddmmmmddo.',
    '..oddddddddddddddo..',
    '...oooooooooooooo...',
  ], pal, 0, 6);
  return c;
}

function buildFern(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(16, 12);
  const pal: Record<string, string> = {
    d: '#1d4a27',
    m: '#397d3b',
    l: '#63b54c',
  };
  drawMatrix(ctx, [
    '..l....ll....l..',
    '...m..lm.l..m...',
    '.l..mm.mm.mm..l.',
    '..mm.ddmmdd.mm..',
    '....dddmmddd....',
    '..dd..dddd..dd..',
  ], pal, 0, 4);
  return c;
}

function buildSandbag(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(28, 16);
  const pal: Record<string, string> = {
    o: '#1f1b15',
    l: '#c4b087',
    m: '#9e8b65',
    d: '#706144',
  };
  drawMatrix(ctx, [
    '....oooooooo....oooooooo....',
    '...ollllllllo..ollllllllo...',
    '..olmmmmmmmmmo.ommmmmmmmmo..',
    '.oooommddddmmmooommddddmmmoo',
    'ollllllloollllllloollllllllo',
    'ommmmmmmmommmmmmmmommmmmmmmo',
    'omdddddddomdddddddomdddddddo',
    '.oooooooooooooooooooooooooo.',
  ], pal, 0, 6);
  return c;
}

function buildBarrel(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(16, 20);
  const pal: Record<string, string> = {
    o: '#171112',
    r: '#d63329',
    R: '#941f19',
    h: '#ff6d59',
    m: '#6e7680',
    y: '#ffd43b',
  };
  drawMatrix(ctx, [
    '...oooooooooo...',
    '..ommmmmmmmmmo..',
    '..oRRRRRRRRRRo..',
    '..ohrrrrrrrrRo..',
    '..ohrrryyrrrRo..',
    '..ommmmmmmmmmo..',
    '..ohrryyyyrrRo..',
    '..ohrrryyrrrRo..',
    '..ohrrrrrrrrRo..',
    '..ommmmmmmmmmo..',
    '..ohrrrrrrrrRo..',
    '..oRRRRRRRRRRo..',
    '...oooooooooo...',
  ], pal, 0, 5);
  return c;
}

function buildCrate(damaged: boolean): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(20, 20);
  const pal: Record<string, string> = {
    o: '#17120d',
    w: '#9c7143',
    W: '#6e4c2a',
    l: '#c2945f',
    m: '#545f66',
    y: '#e8b93c',
  };
  drawMatrix(ctx, [
    '.oooooooooooooooooo.',
    'ommlwwwwwwwwwwwwlmmo',
    'omWllllllllllllllWmo',
    'owWwwwwwwwwwwwwwwWwo',
    'owWwwWwwwwwwwwWwwWwo',
    'owWwwwWwwyywwWwwwWwo',
    'owWwwwwWyyyyWwwwwWwo',
    'owWwwwwwWyyWwwwwwWwo',
    'owWwwwwWwwwwWwwwwWwo',
    'owWwwwWwwwwwwWwwwWwo',
    'owWwwWwwwwwwwwWwwWwo',
    'owWWWWWWWWWWWWWWWWwo',
    'omWWWWWWWWWWWWWWWWmo',
    'ommWWWWWWWWWWWWWWmmo',
    '.oooooooooooooooooo.',
  ], pal, 0, 4);
  if (damaged) {
    ctx.fillStyle = '#17120d';
    ctx.fillRect(6, 7, 2, 6);
    ctx.fillRect(8, 10, 5, 2);
    ctx.fillRect(12, 12, 2, 4);
  }
  return c;
}

function buildJeep(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(56, 32);
  // Rusted military jeep top-3/4 view
  ctx.fillStyle = '#121614';
  ctx.fillRect(4, 4, 48, 24);
  // Tires
  ctx.fillStyle = '#1e2024';
  ctx.fillRect(9, 2, 11, 5);
  ctx.fillRect(35, 2, 11, 5);
  ctx.fillRect(9, 25, 11, 5);
  ctx.fillRect(35, 25, 11, 5);
  // Olive hull
  ctx.fillStyle = '#47573f';
  ctx.fillRect(6, 6, 44, 20);
  ctx.fillStyle = '#5c6e50';
  ctx.fillRect(8, 7, 40, 8);
  // Rust streaks
  ctx.fillStyle = '#7d4427';
  ctx.fillRect(10, 14, 7, 4);
  ctx.fillRect(40, 10, 6, 6);
  // Windshield & cabin
  ctx.fillStyle = '#243038';
  ctx.fillRect(16, 8, 16, 16);
  ctx.fillStyle = '#6da3b5';
  ctx.fillRect(31, 9, 4, 14);
  ctx.fillStyle = '#2e382b';
  ctx.fillRect(17, 9, 13, 14);
  // Star decal on hood
  ctx.fillStyle = '#d4d9c7';
  ctx.fillRect(40, 14, 4, 4);
  // Headlights
  ctx.fillStyle = '#f2d98d';
  ctx.fillRect(49, 8, 2, 4);
  ctx.fillRect(49, 20, 2, 4);
  return c;
}

function buildHospitalBed(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(28, 18);
  ctx.fillStyle = '#161b20';
  ctx.fillRect(1, 2, 26, 14);
  ctx.fillStyle = '#8b9ba6'; // metal frame
  ctx.fillRect(2, 3, 24, 12);
  ctx.fillStyle = '#e8f1f2'; // mattress
  ctx.fillRect(4, 4, 20, 10);
  ctx.fillStyle = '#ffffff'; // pillow
  ctx.fillRect(5, 5, 5, 8);
  ctx.fillStyle = '#62a1ad'; // blanket
  ctx.fillRect(12, 4, 12, 10);
  ctx.fillStyle = '#4c808a';
  ctx.fillRect(12, 11, 12, 3);
  return c;
}

function buildLantern(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(12, 24);
  ctx.fillStyle = '#14171a';
  ctx.fillRect(4, 3, 4, 20);
  ctx.fillRect(2, 20, 8, 3);
  ctx.fillStyle = '#4d555e';
  ctx.fillRect(5, 4, 2, 17);
  // Glowing lantern head
  ctx.fillStyle = '#1b1d21';
  ctx.fillRect(2, 2, 8, 8);
  ctx.fillStyle = '#ffbe42';
  ctx.fillRect(3, 4, 6, 4);
  ctx.fillStyle = '#fff5b8';
  ctx.fillRect(4, 5, 4, 2);
  return c;
}

function buildBioSign(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(16, 22);
  ctx.fillStyle = '#14171a';
  ctx.fillRect(6, 10, 4, 11);
  ctx.fillStyle = '#5c636b';
  ctx.fillRect(7, 11, 2, 9);
  // Yellow hazard diamond/board
  ctx.fillStyle = '#14171a';
  ctx.fillRect(1, 1, 14, 11);
  ctx.fillStyle = '#f2c738';
  ctx.fillRect(2, 2, 12, 9);
  // Biohazard black icon pixels
  ctx.fillStyle = '#191d14';
  ctx.fillRect(7, 4, 2, 2);
  ctx.fillRect(5, 7, 2, 2);
  ctx.fillRect(9, 7, 2, 2);
  ctx.fillRect(7, 6, 2, 1);
  return c;
}

function buildBoatWreck(): HTMLCanvasElement {
  const [c, ctx] = makeCanvas(44, 24);
  const pal: Record<string, string> = {
    o: '#1a130d',
    w: '#875c38',
    W: '#5c3c22',
    d: '#3d2716',
    s: '#c9b38c', // sand drifting over hull
  };
  drawMatrix(ctx, [
    '........ooooooooooooooooo...................',
    '.....ooowwwwwwwwwwwwwwwwwooo................',
    '...oowwwWWWWWWWWWWWWWWWWwwwwwo..............',
    '..owwWWWdddddddddddddddddWWwwwo.............',
    '.owWWddddwwwwddddwwwwddddWWWwwwo............',
    '.owWWdddwwWWdddddwwWWdddddWWWwwwo...........',
    '..owWddddddddddddddddddddddWWwwso...........',
    '...owWWdddddddddddddssddddddWwsso...........',
    '....ooWWWWWWWWWWWWsssssWWWWsssso............',
    '......oooooooooooooooooooooooo..............',
  ], pal, 0, 7);
  return c;
}

let cachedAtlas: SpriteAtlas | null = null;

export function getSpriteAtlas(): SpriteAtlas {
  if (cachedAtlas) return cachedAtlas;

  const characters = {} as Record<CharacterId, CharacterSpriteSet>;
  for (const id of CHARACTER_ORDER) {
    const walk = [0, 1, 2, 3].map((f) => buildCharacterFrame(id, f, false));
    const run = [0, 1, 2, 3].map((f) => buildCharacterFrame(id, f, true));
    const hurt = makeWhiteFlash(walk[0], 'rgba(255, 75, 75, 0.85)');
    characters[id] = { walk, run, hurt };
  }

  const builders: Record<ZombieType, (s: number, a: boolean) => HTMLCanvasElement> = {
    normal: buildNormalZombie,
    fast: buildFastZombie,
    heavy: buildHeavyZombie,
    giant: buildGiantBossZombie,
    mutant: buildMutantZombie,
  };

  const zombies = {} as Record<ZombieType, ZombieSpriteSet>;
  (Object.keys(builders) as ZombieType[]).forEach((zt) => {
    const fn = builders[zt];
    const walk = [0, 1, 2, 3].map((s) => fn(s, false));
    const attack = fn(1, true);
    const hurt = makeWhiteFlash(walk[0], '#ffffff');
    zombies[zt] = { walk, attack, hurt };
  });

  const weapons = {} as Record<WeaponId, HTMLCanvasElement>;
  for (const wid of WEAPON_ORDER) {
    weapons[wid] = buildWeaponSprite(wid);
  }

  const grenade = buildGrenadeSprite();

  cachedAtlas = {
    characters,
    zombies,
    weapons,
    grenade,
    pickups: {
      coin: buildCoinFrames(),
      medkit: buildMedkitSprite(),
      ammo: buildAmmoSprite(),
      grenade,
      scrap: buildScrapSprite(),
    },
    props: {
      palm: [buildPalmTree(0), buildPalmTree(1)],
      jungle_tree: [buildJungleTree(0), buildJungleTree(1)],
      dead_tree: buildDeadTree(),
      rock: [buildRock(0), buildRock(1)],
      stalagmite: buildStalagmite(),
      crystal: buildCrystal(),
      bush: [buildBush(0), buildBush(1)],
      fern: buildFern(),
      sandbag: buildSandbag(),
      jeep: buildJeep(),
      bed: buildHospitalBed(),
      barrel: buildBarrel(),
      crate: [buildCrate(false), buildCrate(true)],
      lantern: buildLantern(),
      bio_sign: buildBioSign(),
      boat_wreck: buildBoatWreck(),
    },
  };

  return cachedAtlas;
}
