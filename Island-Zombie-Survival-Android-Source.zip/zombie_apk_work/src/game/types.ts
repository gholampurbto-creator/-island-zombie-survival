export type Language = 'fa' | 'en';

export type ScreenState =
  | 'menu'
  | 'playing'
  | 'paused'
  | 'shop'
  | 'character'
  | 'settings'
  | 'howtoplay'
  | 'gameover'
  | 'exit';

export type WeaponId =
  | 'pistol'
  | 'shotgun'
  | 'smg'
  | 'rifle'
  | 'sniper'
  | 'lmg'
  | 'flamethrower'
  | 'plasma';

export type ZombieType = 'normal' | 'fast' | 'heavy' | 'giant' | 'mutant';

export type ZoneId =
  | 'beach'
  | 'jungle'
  | 'houses'
  | 'hospital'
  | 'military'
  | 'ammo_depot'
  | 'caves'
  | 'virus_zone';

export type CharacterId = 'marcus' | 'sara' | 'viktor' | 'elena';

export type TouchMode = 'auto' | 'on' | 'off';
export type GraphicsQuality = 'high' | 'medium';

export interface WeaponDefinition {
  id: WeaponId;
  nameEn: string;
  nameFa: string;
  descEn: string;
  descFa: string;
  category: 'sidearm' | 'shotgun' | 'auto' | 'precision' | 'heavy' | 'special';
  cost: number;
  ammoPackCost: number;
  ammoPackAmount: number;
  damage: number;
  fireRate: number; // shots per second
  magSize: number;
  startReserve: number;
  maxReserve: number;
  reloadTime: number; // seconds
  recoil: number; // camera kick & spread bloom
  spread: number; // radians
  range: number; // pixels
  bulletSpeed: number;
  pellets: number;
  pierce: number; // enemies penetrated
  splashRadius: number;
  isFlame?: boolean;
  isPlasma?: boolean;
  bulletColor: string;
  muzzleColor: string;
  infiniteReserve?: boolean;
  upgradeCostBase: number;
}

export interface CharacterDefinition {
  id: CharacterId;
  nameEn: string;
  nameFa: string;
  roleEn: string;
  roleFa: string;
  perkEn: string;
  perkFa: string;
  cost: number;
  maxHpBonus: number;
  speedBonus: number; // multiplier e.g. 0.12 = +12%
  reloadBonus: number; // reduction multiplier e.g. 0.15 = 15% faster
  damageBonus: number; // multiplier e.g. 0.12 = +12%
  startGrenades: number;
  palette: {
    skin: string;
    skinShade: string;
    hair: string;
    headgear: string;
    shirt: string;
    shirtShade: string;
    vest: string;
    pants: string;
    boots: string;
    accent: string;
  };
}

export interface GameSettings {
  language: Language;
  masterVolume: number;
  sfxVolume: number;
  musicVolume: number;
  ambienceVolume: number;
  touchMode: TouchMode;
  quality: GraphicsQuality;
  screenShake: boolean;
  showMinimap: boolean;
}

export interface WeaponRuntimeAmmo {
  mag: number;
  reserve: number;
}

export interface ActiveRunSave {
  wave: number;
  score: number;
  kills: number;
  hp: number;
  maxHp: number;
  x: number;
  y: number;
  equippedWeapon: WeaponId;
  grenades: number;
  ammoByWeapon: Record<WeaponId, WeaponRuntimeAmmo>;
  timeSurvived: number;
  zone: ZoneId;
  characterId: CharacterId;
  savedAt: number;
}

export interface SaveData {
  version: number;
  coins: number;
  scrap: number;
  unlockedWeapons: WeaponId[];
  weaponLevels: Record<WeaponId, number>; // 1..5
  unlockedCharacters: CharacterId[];
  selectedCharacter: CharacterId;
  bestWave: number;
  bestScore: number;
  totalKills: number;
  settings: GameSettings;
  activeRun: ActiveRunSave | null;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Building {
  id: string;
  zone: ZoneId;
  x: number;
  y: number;
  w: number;
  h: number;
  wallThickness: number;
  doorSide: 'south' | 'north' | 'east' | 'west';
  doorWidth: number;
  roofColor: string;
  roofTrim: string;
  floorType: 'wood' | 'hospital' | 'concrete' | 'bunker' | 'stone';
  labelEn?: string;
  labelFa?: string;
  hasCross?: boolean;
  hasHazard?: boolean;
  walls: Rect[];
}

export type PropType =
  | 'palm'
  | 'jungle_tree'
  | 'dead_tree'
  | 'rock'
  | 'stalagmite'
  | 'crystal'
  | 'bush'
  | 'fern'
  | 'sandbag'
  | 'jeep'
  | 'bed'
  | 'barrel'
  | 'crate'
  | 'lantern'
  | 'bio_sign'
  | 'boat_wreck'
  | 'helipad'
  | 'sludge_pool';

export interface WorldProp {
  id: string;
  type: PropType;
  x: number;
  y: number;
  radius: number;
  solid: boolean;
  blocksBullets: boolean;
  hp?: number;
  maxHp?: number;
  destroyed?: boolean;
  variant: number;
  zone: ZoneId;
}

export interface PickupItem {
  id: string;
  type: 'coin' | 'medkit' | 'ammo' | 'grenade' | 'scrap' | 'weapon_drop';
  x: number;
  y: number;
  vx: number;
  vy: number;
  value: number;
  weaponId?: WeaponId;
  life: number;
  bobOffset: number;
}

export interface BossHudInfo {
  nameEn: string;
  nameFa: string;
  hp: number;
  maxHp: number;
}

export interface HudSnapshot {
  hp: number;
  maxHp: number;
  stamina: number;
  maxStamina: number;
  coins: number;
  scrap: number;
  kills: number;
  score: number;
  wave: number;
  waveZombiesRemaining: number;
  waveTotalZombies: number;
  intermissionSeconds: number;
  inIntermission: boolean;
  zone: ZoneId;
  equippedWeapon: WeaponId;
  unlockedWeapons: WeaponId[];
  mag: number;
  magSize: number;
  reserve: number;
  infiniteReserve: boolean;
  reloading: boolean;
  reloadProgress: number; // 0..1
  grenades: number;
  boss: BossHudInfo | null;
  timeSurvived: number;
  statusBanner: {
    textEn: string;
    textFa: string;
    color: string;
    id: number;
  } | null;
  damagedFlash: number;
  inToxicSludge: boolean;
  isSprinting: boolean;
  nearbyCrate: boolean;
}
