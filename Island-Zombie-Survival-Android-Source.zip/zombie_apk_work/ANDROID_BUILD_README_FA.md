# آماده‌سازی نسخه اندروید — Island Zombie Survival

این پروژه در اصل React + Vite است. فایل APK در این محیط ساخته نشد، چون Android SDK، ابزارهای Build اندروید و Gradle نصب نیستند و دریافت وابستگی‌های npm نیز در این نشست به پایان نرسید.

## ساخت APK روی ویندوز با Android Studio

1. Node.js نسخه LTS و Android Studio را نصب کنید.
2. این پوشه را استخراج کنید و در ترمینال همان پوشه اجرا کنید:
   ```bash
   npm install
   npm run build
   npm install -D @capacitor/cli
   npm install @capacitor/core
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. در Android Studio صبر کنید Gradle Sync تمام شود.
4. از منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** خروجی APK را بسازید.
5. APK آزمایشی معمولاً در مسیر `android/app/build/outputs/apk/debug/app-debug.apk` قرار می‌گیرد.

## مشخصات بسته
- نام برنامه: Island Zombie Survival
- شناسه برنامه: `com.islandzombiesurvival.game`
- جهت نمایش و کنترل‌ها مطابق تنظیمات فعلی خود بازی است.

توجه: این پوشه پروژه آماده‌سازی‌شده برای بسته‌بندی با Capacitor است؛ APK نهایی نیست.
